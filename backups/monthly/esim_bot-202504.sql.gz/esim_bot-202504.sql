--
-- PostgreSQL database dump
--

-- Dumped from database version 15.12 (Debian 15.12-1.pgdg120+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(255) NOT NULL,
    flag_emoji character varying(10),
    is_available boolean,
    name_ru character varying(255)
);


ALTER TABLE public.countries OWNER TO postgres;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.countries_id_seq OWNER TO postgres;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: esims; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.esims (
    id integer NOT NULL,
    order_id integer NOT NULL,
    esim_tran_no character varying(255),
    iccid character varying(255),
    imsi character varying(255),
    msisdn character varying(255),
    activation_code character varying(1024),
    qr_code_url character varying(1024),
    short_url character varying(512),
    smdp_status character varying(50),
    esim_status character varying(50),
    active_type integer,
    expired_time timestamp without time zone,
    total_volume bigint,
    total_duration integer,
    duration_unit character varying(20),
    order_usage bigint,
    pin character varying(50),
    puk character varying(50),
    apn character varying(255),
    raw_data json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.esims OWNER TO postgres;

--
-- Name: esims_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.esims_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.esims_id_seq OWNER TO postgres;

--
-- Name: esims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.esims_id_seq OWNED BY public.esims.id;


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faqs (
    id integer NOT NULL,
    question_en text NOT NULL,
    answer_en text NOT NULL,
    question_ru text,
    answer_ru text,
    "order" integer,
    is_active boolean
);


ALTER TABLE public.faqs OWNER TO postgres;

--
-- Name: faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faqs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faqs_id_seq OWNER TO postgres;

--
-- Name: faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faqs_id_seq OWNED BY public.faqs.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    user_id integer NOT NULL,
    package_id integer NOT NULL,
    transaction_id character varying(255) NOT NULL,
    order_no character varying(255),
    status character varying(50),
    order_type character varying(50),
    payment_method character varying(50),
    payment_id character varying(255),
    invoice_id character varying(255),
    payment_details text,
    paid_at timestamp without time zone,
    amount double precision NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: packages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packages (
    id integer NOT NULL,
    country_id integer NOT NULL,
    package_code character varying(255) NOT NULL,
    slug character varying(255),
    name character varying(255) NOT NULL,
    data_amount double precision NOT NULL,
    duration integer NOT NULL,
    price double precision NOT NULL,
    description text,
    is_available boolean,
    retail_price double precision,
    last_synced_at timestamp without time zone
);


ALTER TABLE public.packages OWNER TO postgres;

--
-- Name: packages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.packages_id_seq OWNER TO postgres;

--
-- Name: packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packages_id_seq OWNED BY public.packages.id;


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_messages (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    sender_type character varying(20) NOT NULL,
    text text NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.support_messages OWNER TO postgres;

--
-- Name: support_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_messages_id_seq OWNER TO postgres;

--
-- Name: support_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_messages_id_seq OWNED BY public.support_messages.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    status character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_id bigint NOT NULL,
    username character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    language_code character varying(10),
    is_admin boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: esims id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.esims ALTER COLUMN id SET DEFAULT nextval('public.esims_id_seq'::regclass);


--
-- Name: faqs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs ALTER COLUMN id SET DEFAULT nextval('public.faqs_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: packages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages ALTER COLUMN id SET DEFAULT nextval('public.packages_id_seq'::regclass);


--
-- Name: support_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_messages ALTER COLUMN id SET DEFAULT nextval('public.support_messages_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.countries (id, code, name, flag_emoji, is_available, name_ru) FROM stdin;
3	MO	Macao	🇲🇴	t	Макао
2	HK	Hong Kong	🇭🇰	t	Гонконг
4	TH	Thailand	🇹🇭	t	Таиланд
5	NL	Netherlands	🇳🇱	t	Нидерланды
6	IL	Israel	🇮🇱	t	Израиль
7	TR	Türkiye	🇹🇷	t	Турция
8	JO	Jordan	🇯🇴	t	Иордания
9	KW	Kuwait	🇰🇼	t	Кувейт
10	OM	Oman	🇴🇲	t	Оман
11	QA	Qatar	🇶🇦	t	Катар
12	AM	Armenia	🇦🇲	t	Армения
13	AE	United Arab Emirates	🇦🇪	t	ОАЭ
14	AZ	Azerbaijan	🇦🇿	t	Азербайджан
15	GE	Georgia	🇬🇪	t	Грузия
16	BH	Bahrain	🇧🇭	t	Бахрейн
17	SA	Saudi Arabia	🇸🇦	t	Саудовская Аравия
18	AT	Austria	🇦🇹	t	Австрия
19	BE	Belgium	🇧🇪	t	Бельгия
20	BG	Bulgaria	🇧🇬	t	Болгария
21	HR	Croatia	🇭🇷	t	Хорватия
22	CY	Cyprus	🇨🇾	t	Кипр
23	CZ	Czechia	🇨🇿	t	Чехия
24	DK	Denmark	🇩🇰	t	Дания
25	EE	Estonia	🇪🇪	t	Эстония
26	FI	Finland	🇫🇮	t	Финляндия
29	GR	Greece	🇬🇷	t	Греция
30	HU	Hungary	🇭🇺	t	Венгрия
31	IS	Iceland	🇮🇸	t	Исландия
32	IE	Ireland	🇮🇪	t	Ирландия
34	LV	Latvia	🇱🇻	t	Латвия
35	LT	Lithuania	🇱🇹	t	Литва
36	LU	Luxembourg	🇱🇺	t	Люксембург
37	MT	Malta	🇲🇹	t	Мальта
38	PL	Poland	🇵🇱	t	Польша
39	PT	Portugal	🇵🇹	t	Португалия
40	RO	Romania	🇷🇴	t	Румыния
41	SK	Slovakia	🇸🇰	t	Словакия
42	SI	Slovenia	🇸🇮	t	Словения
43	SE	Sweden	🇸🇪	t	Швеция
44	CH	Switzerland	🇨🇭	t	Швейцария
53	NO	Norway	🇳🇴	t	Норвегия
54	RS	Serbia	🇷🇸	t	Сербия
56	AU	Australia	🇦🇺	t	Австралия
57	MY	Malaysia	🇲🇾	t	Малайзия
58	NZ	New Zealand	🇳🇿	t	Новая Зеландия
59	PH	Philippines	🇵🇭	t	Филиппины
60	SG	Singapore	🇸🇬	t	Сингапур
62	VN	Viet Nam	🇻🇳	t	Вьетнам
64	ID	Indonesia	🇮🇩	t	Индонезия
65	IN	India	🇮🇳	t	Индия
67	KR	Korea, Republic of	🇰🇷	t	Южная Корея
69	AR	Argentina	🇦🇷	t	Аргентина
71	BR	Brazil	🇧🇷	t	Бразилия
72	CL	Chile	🇨🇱	t	Чили
73	CO	Colombia	🇨🇴	t	Колумбия
74	CR	Costa Rica	🇨🇷	t	Коста-Рика
75	EC	Ecuador	🇪🇨	t	Эквадор
80	PA	Panama	🇵🇦	t	Панама
82	PE	Peru	🇵🇪	t	Перу
84	UY	Uruguay	🇺🇾	t	Уругвай
93	EG	Egypt	🇪🇬	t	Египет
95	KE	Kenya	🇰🇪	t	Кения
98	MA	Morocco	🇲🇦	t	Марокко
103	ZA	South Africa	🇿🇦	t	ЮАР
107	TN	Tunisia	🇹🇳	t	Тунис
113	CA	Canada	🇨🇦	t	Канада
114	MK	North Macedonia	🇲🇰	t	Северная Македония
115	MX	Mexico	🇲🇽	t	Мексика
119	MD	Moldova, Republic of	🇲🇩	t	Молдова
47	AX	Åland Islands	🇦🇽	t	Аландские острова
48	IM	Isle of Man	🇮🇲	t	Остров Мэн
49	JE	Jersey	🇯🇪	t	Джерси
1	ES	Spain	🇪🇸	t	Испания
51	GG	Guernsey	🇬🇬	t	Гернси
52	LI	Liechtenstein	🇱🇮	t	Лихтенштейн
55	GI	Gibraltar	🇬🇮	t	Гибралтар
61	LK	Sri Lanka	🇱🇰	t	Шри-Ланка
68	YE	Yemen	🇾🇪	t	Йемен
70	BO	Bolivia, Plurinational State of	🇧🇴	t	Боливия
76	SV	El Salvador	🇸🇻	t	Сальвадор
77	GT	Guatemala	🇬🇹	t	Гватемала
78	HN	Honduras	🇭🇳	t	Гондурас
79	NI	Nicaragua	🇳🇮	t	Никарагуа
81	PY	Paraguay	🇵🇾	t	Парагвай
83	PR	Puerto Rico	🇵🇷	t	Пуэрто-Рико
85	RE	Réunion	🇷🇪	t	Реюньон
86	MG	Madagascar	🇲🇬	t	Мадагаскар
87	MW	Malawi	🇲🇼	t	Малави
88	BW	Botswana	🇧🇼	t	Ботсвана
89	CF	Central African Republic	🇨🇫	t	Центральноафриканская Республика
90	TD	Chad	🇹🇩	t	Чад
91	CG	Congo	🇨🇬	t	Конго
92	CI	Côte d'Ivoire	🇨🇮	t	Кот-д'Ивуар
94	GA	Gabon	🇬🇦	t	Габон
96	LR	Liberia	🇱🇷	t	Либерия
97	ML	Mali	🇲🇱	t	Мали
99	NE	Niger	🇳🇪	t	Нигер
27	FR	France	🇫🇷	t	Франция
28	DE	Germany	🇩🇪	t	Германия
100	NG	Nigeria	🇳🇬	t	Нигерия
101	SN	Senegal	🇸🇳	t	Сенегал
102	SC	Seychelles	🇸🇨	t	Сейшельские острова
104	SD	Sudan	🇸🇩	t	Судан
33	IT	Italy	🇮🇹	t	Италия
105	SZ	Eswatini	🇸🇿	t	Эсватини
106	TZ	Tanzania, United Republic of	🇹🇿	t	Танзания
108	UG	Uganda	🇺🇬	t	Уганда
109	ZM	Zambia	🇿🇲	t	Замбия
110	KH	Cambodia	🇰🇭	t	Камбоджа
111	DZ	Algeria	🇩🇿	t	Алжир
112	BD	Bangladesh	🇧🇩	t	Бангладеш
116	MZ	Mozambique	🇲🇿	t	Мозамбик
117	PK	Pakistan	🇵🇰	t	Пакистан
118	BF	Burkina Faso	🇧🇫	t	Буркина-Фасо
45	UA	Ukraine	🇺🇦	t	Украина
46	GB	United Kingdom	🇬🇧	t	Великобритания
50	RU	Russian Federation	🇷🇺	t	Россия
63	CN	China	🇨🇳	t	Китай
66	JP	Japan	🇯🇵	t	Япония
129	KZ	Kazakhstan	🇰🇿	t	Казахстан
134	BY	Belarus	🇧🇾	t	Беларусь
135	US	United States	🇺🇸	t	США
139	JM	Jamaica	🇯🇲	t	Ямайка
120	MC	Monaco	🇲🇨	t	Монако
121	AL	Albania	🇦🇱	t	Албания
127	BA	Bosnia and Herzegovina	🇧🇦	t	Босния и Герцеговина
128	ME	Montenegro	🇲🇪	t	Черногория
131	DO	Dominican Republic	🇩🇴	t	Доминиканская Республика
138	MU	Mauritius	🇲🇺	t	Маврикий
122	CM	Cameroon	🇨🇲	t	Камерун
123	UZ	Uzbekistan	🇺🇿	t	Узбекистан
124	NP	Nepal	🇳🇵	t	Непал
125	XK	XK	🇽🇰	t	Косово
126	MN	Mongolia	🇲🇳	t	Монголия
130	KG	Kyrgyzstan	🇰🇬	t	Киргизия
132	GP	Guadeloupe	🇬🇵	t	Гваделупа
133	BN	Brunei Darussalam	🇧🇳	t	Бруней
136	IQ	Iraq	🇮🇶	t	Ирак
137	GU	Guam	🇬🇺	t	Гуам
\.


--
-- Data for Name: esims; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.esims (id, order_id, esim_tran_no, iccid, imsi, msisdn, activation_code, qr_code_url, short_url, smdp_status, esim_status, active_type, expired_time, total_volume, total_duration, duration_unit, order_usage, pin, puk, apn, raw_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faqs (id, question_en, answer_en, question_ru, answer_ru, "order", is_active) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, user_id, package_id, transaction_id, order_no, status, order_type, payment_method, payment_id, invoice_id, payment_details, paid_at, amount, created_at, updated_at) FROM stdin;
1	1	389	f10b534e-da30-4544-8f73-42fca50c64b7	\N	awaiting_payment	new	crypto_ton	\N	24517534	\N	\N	0.4	2025-04-23 21:48:24.378656	2025-04-23 21:48:43.894903
\.


--
-- Data for Name: packages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.packages (id, country_id, package_code, slug, name, data_amount, duration, price, description, is_available, retail_price, last_synced_at) FROM stdin;
646	76	SV_P5LC2VD5D	\N	El Salvador 100MB 7Days	0.1	7	0.57		t	1.14	2025-04-23 16:04:14.737996
649	77	GT_PAQGBYCEU	\N	Guatemala 100MB 7Days	0.1	7	0.57		t	1.14	2025-04-23 16:04:29.841658
655	79	NI_PUHSFBY6P	\N	Nicaragua 100MB 7Days	0.1	7	0.57		t	1.14	2025-04-23 16:04:59.987495
661	81	PY_P0112XJDY	\N	Paraguay 100MB 7Days	0.1	7	0.53		t	1.06	2025-04-23 16:05:31.128122
665	82	PE_PZ5R7GI4K	\N	Peru 100MB 7Days	0.1	7	0.65		t	1.3	2025-04-23 16:05:46.866456
669	83	PR_PK5O2KUQT	\N	Puerto Rico 100MB 7Days	0.1	7	0.38		t	0.76	2025-04-23 16:06:02.433502
676	85	RE_PQD094RUX	\N	Reunion 500MB/Day	0.49	1	1.45	Reunion 500MB/Day	t	2.9	2025-04-23 16:06:28.543742
677	85	RE_PHMS8J01F	\N	Reunion 1GB/Day	1	1	2.9	Reunion 1GB/Day	t	5.8	2025-04-23 16:06:28.54375
678	85	RE_P1X3N5XFT	\N	Reunion 2GB/Day	2	1	5.5	Reunion 2GB/Day	t	11	2025-04-23 16:06:28.543775
679	85	RE_P530XLLHQ	\N	Reunion 3GB/Day	3	1	7.1	Reunion 3GB/Day	t	14.2	2025-04-23 16:06:28.543785
680	85	RE_PN1JR359K	\N	Reunion 100MB 7Days	0.1	7	0.28		t	0.56	2025-04-23 16:06:28.543794
699	92	CI_CKH432	\N	Cote d'Ivoire 5GB 30Days	5	30	26	Cote d'Ivoire 5GB 30Days	t	52	2025-04-23 16:08:08.429495
701	93	EG_MB029	\N	Egypt 3GB 15Days	3	15	4.6	Egypt 3GB 15Days	t	9.2	2025-04-23 16:08:23.316206
702	93	EG_MB034	\N	Egypt 5GB 30Days	5	30	8.8	Egypt 5GB 30Days	t	17.6	2025-04-23 16:08:23.316213
703	93	EG_MB039	\N	Egypt 10GB 30Days	10	30	12.2	Egypt 10GB 30Days	t	24.4	2025-04-23 16:08:23.316219
704	93	EG_PNLOUKFKT	\N	Egypt 3GB 30Days	3	30	4.7		t	9.4	2025-04-23 16:08:23.316225
705	93	EG_PIXA8CXUL	\N	Egypt 20GB 30Days	20	30	25		t	50	2025-04-23 16:08:23.316231
706	93	EG_PZ23T9OT0	\N	Egypt 2GB/Day	2	1	2.8		t	5.6	2025-04-23 16:08:23.316237
707	93	EG_PK564ELYK	\N	Egypt 1GB/Day	1	1	1.7	Egypt 1GB/Day	t	3.4	2025-04-23 16:08:23.316244
11	2	HK_JC004	\N	Hong Kong 3GB 30Days	3	30	1.8	Hong Kong 3GB 30Days	t	3.6	2025-04-23 15:45:48.021196
12	2	HK_JC005	\N	Hong Kong 5GB 30Days	5	30	2.7	Hong Kong 5GB 30Days	t	5.4	2025-04-23 15:45:48.021215
13	2	HK_JC021	\N	Hong Kong 1GB 7Days	1	7	0.7	Hong Kong 1GB 7Days	t	1.4	2025-04-23 15:45:48.021221
14	2	HK_JC022	\N	Hong Kong 3GB 15Days	3	15	1.7	Hong Kong 3GB 15Days	t	3.4	2025-04-23 15:45:48.021229
15	2	HK_JC023	\N	Hong Kong 10GB 30Days	10	30	4.7	Hong Kong 10GB 30Days	t	9.4	2025-04-23 15:45:48.021235
16	2	HK_JC104	\N	Hong Kong 20GB 30Days	20	30	8.2	Hong Kong 20GB 30Days	t	16.4	2025-04-23 15:45:48.021241
17	2	HK_P4MCCLBKV	\N	Hong Kong 50GB 180Days	50	180	32	Hong Kong 50GB 180Days	t	64	2025-04-23 15:45:48.021246
18	2	HK_PPGUJ3XIX	\N	Hong Kong 1GB/Day	1	1	0.85	Hong Kong 1GB/Day	t	1.7	2025-04-23 15:45:48.021252
24	3	MO_JC010	\N	Macao 3GB 30Days	3	30	1.8	Macao 3GB 30Days	t	3.6	2025-04-23 15:46:01.735171
25	3	MO_JC011	\N	Macao 5GB 30Days	5	30	2.7	Macao 5GB 30Days	t	5.4	2025-04-23 15:46:01.735193
26	3	MO_JC024	\N	Macao 1GB 7Days	1	7	0.7	Macao 1GB 7Days	t	1.4	2025-04-23 15:46:01.7352
27	3	MO_JC025	\N	Macao 3GB 15Days	3	15	1.7	Macao 3GB 15Days	t	3.4	2025-04-23 15:46:01.735206
28	3	MO_JC026	\N	Macao 10GB 30Days	10	30	4.7	Macao 10GB 30Days	t	9.4	2025-04-23 15:46:01.735212
29	3	MO_JC106	\N	Macao 20GB 30Days	20	30	8.2	Macao 20GB 30Days	t	16.4	2025-04-23 15:46:01.735218
30	3	MO_PDRBEISAJ	\N	Macao 50GB 180Days	50	180	32	Macao 50GB 180Days	t	64	2025-04-23 15:46:01.735224
31	3	MO_PNLL0N5F4	\N	Macao 1GB 7Days (nonhkip)	1	7	1.1	Macao 1GB 7Days (nonhkip)	t	2.2	2025-04-23 15:46:01.735231
32	3	MO_PTJM6R2V5	\N	Macao 3GB 15Days (nonhkip)	3	15	2.8	Macao 3GB 15Days (nonhkip)	t	5.6	2025-04-23 15:46:01.735247
33	3	MO_PBR7AJ6V0	\N	Macao 5GB 30Days (nonhkip)	5	30	4	Macao 5GB 30Days (nonhkip)	t	8	2025-04-23 15:46:01.735265
34	3	MO_PEM0EL2D9	\N	Macao 10GB 30Days (nonhkip)	10	30	7	Macao 10GB 30Days (nonhkip)	t	14	2025-04-23 15:46:01.735277
39	4	TH_JC013	\N	Thailand 3GB 30Days	3	30	1.8	Thailand 3GB 30Days	t	3.6	2025-04-23 15:46:16.12217
40	4	TH_JC014	\N	Thailand 5GB 30Days	5	30	2.7	Thailand 5GB 30Days	t	5.4	2025-04-23 15:46:16.122189
41	4	TH_JC045	\N	Thailand 1GB 7Days	1	7	0.7	Thailand 1GB 7Days	t	1.4	2025-04-23 15:46:16.122195
42	4	TH_JC046	\N	Thailand 3GB 15Days	3	15	1.7	Thailand 3GB 15Days	t	3.4	2025-04-23 15:46:16.122201
43	4	TH_JC047	\N	Thailand 10GB 30Days	10	30	4.7	Thailand 10GB 30Days	t	9.4	2025-04-23 15:46:16.122206
44	4	TH_JC080	\N	Thailand 20GB 30Days	20	30	8.2	Thailand 20GB 30Days	t	16.4	2025-04-23 15:46:16.122212
45	4	TH_PNJW9PBXH	\N	Thailand 50GB 180Days	50	180	32	Thailand 50GB 180Days	t	64	2025-04-23 15:46:16.122217
46	4	TH_PZ9GTBKFR	\N	Thailand 500MB/Day	0.49	1	0.5	Thailand 500MB/Day	t	1	2025-04-23 15:46:16.122224
47	4	TH_P5V3QF0VA	\N	Thailand 1GB/Day	1	1	0.9	Thailand 1GB/Day	t	1.8	2025-04-23 15:46:16.122231
48	4	TH_PZPE5LW98	\N	Thailand 10GB/Day	10	1	8	Thailand 10GB/Day	t	16	2025-04-23 15:46:16.122237
49	4	TH_P2R7CWSN9	\N	Thailand 2GB/Day	2	1	1.6	Thailand 2GB/Day	t	3.2	2025-04-23 15:46:16.122249
50	4	TH_PJ0FB89GA	\N	Thailand 3GB/Day	3	1	2.4	Thailand 3GB/Day	t	4.8	2025-04-23 15:46:16.122255
51	4	TH_PQ2I5PFIT	\N	Thailand 100MB 7Days	0.1	7	0.12		t	0.24	2025-04-23 15:46:16.122271
58	4	TH_PPS28ZZ4H	\N	Thailand 1GB/Day (nonhkip)	1	1	1.2	Thailand 1GB/Day (nonhkip)	t	2.4	2025-04-23 15:46:16.122331
60	5	NL_CKH009	\N	Netherlands 3GB 30Days	3	30	2.3	Netherlands 3GB 30Days	t	4.6	2025-04-23 15:46:33.263958
61	5	NL_CKH010	\N	Netherlands 5GB 30Days	5	30	3.4	Netherlands 5GB 30Days	t	6.8	2025-04-23 15:46:33.263978
62	5	NL_CKH233	\N	Netherlands 1GB 7Days	1	7	0.9	Netherlands 1GB 7Days	t	1.8	2025-04-23 15:46:33.263984
63	5	NL_CKH234	\N	Netherlands 3GB 15Days	3	15	2.2	Netherlands 3GB 15Days	t	4.4	2025-04-23 15:46:33.263997
708	93	EG_P6XTH0M8D	\N	Egypt 500MB/Day	0.49	1	1	Egypt 500MB/Day	t	2	2025-04-23 16:08:23.31625
709	93	EG_PXG3YL37H	\N	Egypt 100MB 7Days	0.1	7	0.22		t	0.44	2025-04-23 16:08:23.316256
67	6	IL_CKH024	\N	Israel 3GB 30Days	3	30	3.8	Israel 3GB 30Days	t	7.6	2025-04-23 15:46:47.625566
68	6	IL_CKH223	\N	Israel 1GB 7Days	1	7	1.5	Israel 1GB 7Days	t	3	2025-04-23 15:46:47.625584
69	6	IL_CKH224	\N	Israel 3GB 15Days	3	15	3.7	Israel 3GB 15Days	t	7.4	2025-04-23 15:46:47.62559
78	7	TR_CKH025	\N	Turkey 3GB 30Days	3	30	1.42	Turkey 3GB 30Days	t	2.84	2025-04-23 15:47:05.00491
79	7	TR_CKH265	\N	Turkey 1GB 7Days	1	7	0.46	Turkey 1GB 7Days	t	0.92	2025-04-23 15:47:05.004932
80	7	TR_CKH266	\N	Turkey 3GB 15Days	3	15	1.39	Turkey 3GB 15Days	t	2.78	2025-04-23 15:47:05.004938
81	7	TR_CKH267	\N	Turkey 5GB 30Days	5	30	2.3	Turkey 5GB 30Days	t	4.6	2025-04-23 15:47:05.004943
82	7	TR_CKH268	\N	Turkey 10GB 30Days	10	30	4.2	Turkey 10GB 30Days	t	8.4	2025-04-23 15:47:05.004954
83	7	TR_CKH738	\N	Turkey 20GB 30Days	20	30	7	Turkey 20GB 30Days	t	14	2025-04-23 15:47:05.00496
84	7	TR_PAV5NMZ28	\N	Turkey 50GB 180Days	50	180	28	Turkey 50GB 180Days	t	56	2025-04-23 15:47:05.004967
85	7	TR_P1G6QKLC2	\N	Turkey 1GB/Day	1	1	0.42	Turkey 1GB/Day	t	0.84	2025-04-23 15:47:05.004973
86	7	TR_P4PJDQ93V	\N	Turkey 500MB/Day	0.49	1	0.3	Turkey 500MB/Day	t	0.6	2025-04-23 15:47:05.004991
91	8	JO_CKH026	\N	Jordan 3GB 30Days	3	30	4.7	Jordan 3GB 30Days	t	9.4	2025-04-23 15:47:17.824731
92	8	JO_CKH269	\N	Jordan 1GB 7Days	1	7	1.8	Jordan 1GB 7Days	t	3.6	2025-04-23 15:47:17.824769
93	8	JO_CKH270	\N	Jordan 3GB 15Days	3	15	4.6	Jordan 3GB 15Days	t	9.2	2025-04-23 15:47:17.824777
94	8	JO_CKH271	\N	Jordan 5GB 30Days	5	30	7	Jordan 5GB 30Days	t	14	2025-04-23 15:47:17.824788
95	8	JO_CKH272	\N	Jordan 10GB 30Days	10	30	12.2	Jordan 10GB 30Days	t	24.4	2025-04-23 15:47:17.824795
96	8	JO_CKH790	\N	Jordan 20GB 30Days	20	30	20	Jordan 20GB 30Days	t	40	2025-04-23 15:47:17.824801
97	8	JO_PF8LJK42E	\N	Jordan 100MB 7Days	0.1	7	0.18		t	0.36	2025-04-23 15:47:17.824807
98	9	KW_CKH027	\N	Kuwait 3GB 30Days	3	30	5.9	Kuwait 3GB 30Days	t	11.8	2025-04-23 15:47:31.55288
99	9	KW_CKH512	\N	Kuwait 1GB 7Days	1	7	2.3	Kuwait 1GB 7Days	t	4.6	2025-04-23 15:47:31.552903
100	9	KW_CKH628	\N	Kuwait 3GB 15Days	3	15	5.7	Kuwait 3GB 15Days	t	11.4	2025-04-23 15:47:31.552909
101	9	KW_CKH629	\N	Kuwait 5GB 30Days	5	30	8.8	Kuwait 5GB 30Days	t	17.6	2025-04-23 15:47:31.552915
102	9	KW_CKH748	\N	Kuwait 20GB 30Days	20	30	25	Kuwait 20GB 30Days	t	50	2025-04-23 15:47:31.55292
103	9	KW_PDM89TRPE	\N	Kuwait 100MB 7Days	0.1	7	0.28		t	0.56	2025-04-23 15:47:31.552927
104	10	OM_CKH028	\N	Oman 3GB 30Days	3	30	14.4	Oman 3GB 30Days	t	28.8	2025-04-23 15:47:44.136536
105	10	OM_CKH273	\N	Oman 1GB 7Days	1	7	5.7	Oman 1GB 7Days	t	11.4	2025-04-23 15:47:44.136556
106	10	OM_CKH274	\N	Oman 3GB 15Days	3	15	14.1	Oman 3GB 15Days	t	28.2	2025-04-23 15:47:44.136567
107	10	OM_CKH807	\N	Oman 20GB 30Days	20	30	63	Oman 20GB 30Days	t	126	2025-04-23 15:47:44.136572
108	11	QA_CKH029	\N	Qatar 3GB 30Days	3	30	9.1	Qatar 3GB 30Days	t	18.2	2025-04-23 15:47:57.311179
109	11	QA_CKH513	\N	Qatar 1GB 7Days	1	7	3.6	Qatar 1GB 7Days	t	7.2	2025-04-23 15:47:57.311216
110	11	QA_CKH667	\N	Qatar 3GB 15Days	3	15	8.9	Qatar 3GB 15Days	t	17.8	2025-04-23 15:47:57.311222
111	11	QA_CKH668	\N	Qatar 5GB 30Days	5	30	13.6	Qatar 5GB 30Days	t	27.2	2025-04-23 15:47:57.311228
112	11	QA_CKH762	\N	Qatar 20GB 30Days	20	30	40	Qatar 20GB 30Days	t	80	2025-04-23 15:47:57.311234
113	11	QA_PMJUJWRQ8	\N	Qatar 1GB/Day	1	1	1.7		t	3.4	2025-04-23 15:47:57.31124
114	11	QA_PIPAFTMRE	\N	Qatar 100MB 7Days	0.1	7	0.45		t	0.9	2025-04-23 15:47:57.311245
115	12	AM_CKH030	\N	Armenia 3GB 30Days	3	30	14.4	Armenia 3GB 30Days	t	28.8	2025-04-23 15:48:09.872559
116	12	AM_CKH514	\N	Armenia 1GB 7Days	1	7	5.7	Armenia 1GB 7Days	t	11.4	2025-04-23 15:48:09.872582
117	12	AM_CKH555	\N	Armenia 3GB 15Days	3	15	14.1	Armenia 3GB 15Days	t	28.2	2025-04-23 15:48:09.872589
118	12	AM_CKH776	\N	Armenia 20GB 30Days	20	30	123	Armenia 20GB 30Days	t	246	2025-04-23 15:48:09.872595
119	12	AM_PZBBJD4HG	\N	Armenia 100MB 7Days	0.1	7	0.56		t	1.12	2025-04-23 15:48:09.872601
120	13	AE_CKH031	\N	United Arab Emirates 3GB 30Days	3	30	5.27	United Arab Emirates 3GB 30Days	t	10.54	2025-04-23 15:48:23.135657
121	13	AE_CKH527	\N	United Arab Emirates 1GB 7Days	1	7	2.2	United Arab Emirates 1GB 7Days	t	4.4	2025-04-23 15:48:23.13568
122	13	AE_CKH692	\N	United Arab Emirates 3GB 15Days	3	15	5.27	United Arab Emirates 3GB 15Days	t	10.54	2025-04-23 15:48:23.135687
123	13	AE_CKH693	\N	United Arab Emirates 5GB 30Days	5	30	8.39	United Arab Emirates 5GB 30Days	t	16.78	2025-04-23 15:48:23.135693
124	13	AE_CKH694	\N	United Arab Emirates 10GB 60Days	10	60	14.98	United Arab Emirates 10GB 60Days	t	29.96	2025-04-23 15:48:23.135699
125	13	AE_P0LWCN1S2	\N	United Arab Emirates 20GB 30Days	20	30	26.54	United Arab Emirates 20GB 30Days	t	53.08	2025-04-23 15:48:23.135705
728	98	MA_P33C3KC73	\N	Morocco 2GB/Day	2	1	2.5		t	5	2025-04-23 16:09:39.248196
729	98	MA_PRPJ3X0Y2	\N	Morocco 500MB/Day	0.49	1	0.73	Morocco 500MB/Day	t	1.46	2025-04-23 16:09:39.248205
730	98	MA_PNQOJTLBQ	\N	Morocco 100MB 7Days	0.1	7	0.15		t	0.3	2025-04-23 16:09:39.248211
762	107	TN_PMV0HAP98	\N	Tunisia 1GB/Day	1	1	1.7	Tunisia 1GB/Day	t	3.4	2025-04-23 16:11:53.193299
763	107	TN_PMJ2GNEEK	\N	Tunisia 100MB 7Days	0.1	7	0.3		t	0.6	2025-04-23 16:11:53.193305
766	109	ZM_CKH393	\N	Zambia 1GB 7Days	1	7	4.6	Zambia 1GB 7Days	t	9.2	2025-04-23 16:12:23.444494
133	14	AZ_CKH032	\N	Azerbaijan 3GB 30Days	3	30	17.9	Azerbaijan 3GB 30Days	t	35.8	2025-04-23 15:48:35.832591
134	14	AZ_CKH281	\N	Azerbaijan 1GB 7Days	1	7	7.1	Azerbaijan 1GB 7Days	t	14.2	2025-04-23 15:48:35.832624
135	14	AZ_CKH282	\N	Azerbaijan 3GB 15Days	3	15	17.6	Azerbaijan 3GB 15Days	t	35.2	2025-04-23 15:48:35.832633
136	14	AZ_PLYTQ0XIR	\N	Azerbaijan 100MB 7Days	0.1	7	0.79		t	1.58	2025-04-23 15:48:35.83264
137	15	GE_CKH970	\N	Georgia 3GB 30Days	3	30	3.8	Georgia 3GB 30Days	t	7.6	2025-04-23 15:48:44.83807
138	15	GE_CKH511	\N	Georgia 1GB 7Days	1	7	1.5	Georgia 1GB 7Days	t	3	2025-04-23 15:48:44.838116
139	15	GE_CKH601	\N	Georgia 3GB 15Days	3	15	3.7	Georgia 3GB 15Days	t	7.4	2025-04-23 15:48:44.838126
140	15	GE_CKH602	\N	Georgia 5GB 30Days	5	30	5.7	Georgia 5GB 30Days	t	11.4	2025-04-23 15:48:44.838134
141	15	GE_CKH743	\N	Georgia 20GB 30Days	20	30	16.8	Georgia 20GB 30Days	t	33.6	2025-04-23 15:48:44.838142
142	16	BH_CKH035	\N	Bahrain 3GB 30Days	3	30	11.4	Bahrain 3GB 30Days	t	22.8	2025-04-23 15:48:53.760226
143	16	BH_CKH289	\N	Bahrain 1GB 7Days	1	7	4.6	Bahrain 1GB 7Days	t	9.2	2025-04-23 15:48:53.760253
144	16	BH_CKH290	\N	Bahrain 3GB 15Days	3	15	11.2	Bahrain 3GB 15Days	t	22.4	2025-04-23 15:48:53.76026
145	16	BH_PS4XW6D9Y	\N	Bahrain 500MB/Day	0.49	1	2.25	Bahrain 500MB/Day	t	4.5	2025-04-23 15:48:53.760268
149	17	SA_CKH036	\N	Saudi Arabia 3GB 30Days	3	30	7.3	Saudi Arabia 3GB 30Days	t	14.6	2025-04-23 15:49:07.472212
150	17	SA_CKH277	\N	Saudi Arabia 1GB 7Days	1	7	2.9	Saudi Arabia 1GB 7Days	t	5.8	2025-04-23 15:49:07.472238
151	17	SA_CKH278	\N	Saudi Arabia 3GB 15Days	3	15	7.2	Saudi Arabia 3GB 15Days	t	14.4	2025-04-23 15:49:07.472243
152	17	SA_CKH279	\N	Saudi Arabia 5GB 30Days	5	30	11	Saudi Arabia 5GB 30Days	t	22	2025-04-23 15:49:07.472248
153	17	SA_CKH280	\N	Saudi Arabia 10GB 30Days	10	30	19	Saudi Arabia 10GB 30Days	t	38	2025-04-23 15:49:07.472256
155	18	AT_CKH076	\N	Austria 3GB 30Days	3	30	2.3	Austria 3GB 30Days	t	4.6	2025-04-23 15:49:23.544888
156	18	AT_CKH115	\N	Austria 5GB 30Days	5	30	3.4	Austria 5GB 30Days	t	6.8	2025-04-23 15:49:23.544907
157	18	AT_CKH157	\N	Austria 1GB 7Days	1	7	0.9	Austria 1GB 7Days	t	1.8	2025-04-23 15:49:23.544913
158	18	AT_CKH158	\N	Austria 3GB 15Days	3	15	2.2	Austria 3GB 15Days	t	4.4	2025-04-23 15:49:23.544918
159	18	AT_CKH159	\N	Austria 10GB 30Days	10	30	6.1	Austria 10GB 30Days	t	12.2	2025-04-23 15:49:23.544923
160	18	AT_CKH537	\N	Austria 20GB 30Days	20	30	10.6	Austria 20GB 30Days	t	21.2	2025-04-23 15:49:23.544928
162	19	BE_CKH077	\N	Belgium 3GB 30Days	3	30	2.3	Belgium 3GB 30Days	t	4.6	2025-04-23 15:49:39.534606
163	19	BE_CKH116	\N	Belgium 5GB 30Days	5	30	3.4	Belgium 5GB 30Days	t	6.8	2025-04-23 15:49:39.534629
164	19	BE_CKH202	\N	Belgium 1GB 7Days	1	7	0.9	Belgium 1GB 7Days	t	1.8	2025-04-23 15:49:39.534635
165	19	BE_CKH203	\N	Belgium 3GB 15Days	3	15	2.2	Belgium 3GB 15Days	t	4.4	2025-04-23 15:49:39.53464
166	19	BE_CKH204	\N	Belgium 10GB 30Days	10	30	6.1	Belgium 10GB 30Days	t	12.2	2025-04-23 15:49:39.534646
167	19	BE_CKH502	\N	Belgium 20GB 30Days	20	30	10.6	Belgium 20GB 30Days	t	21.2	2025-04-23 15:49:39.534651
170	20	BG_CKH078	\N	Bulgaria 3GB 30Days	3	30	2.3	Bulgaria 3GB 30Days	t	4.6	2025-04-23 15:49:55.350203
171	20	BG_CKH205	\N	Bulgaria 1GB 7Days	1	7	0.9	Bulgaria 1GB 7Days	t	1.8	2025-04-23 15:49:55.350228
172	20	BG_CKH206	\N	Bulgaria 3GB 15Days	3	15	2.2	Bulgaria 3GB 15Days	t	4.4	2025-04-23 15:49:55.350234
173	20	BG_CKH207	\N	Bulgaria 10GB 30Days	10	30	6.1	Bulgaria 10GB 30Days	t	12.2	2025-04-23 15:49:55.35024
174	20	BG_PQQINSIX3	\N	Bulgaria 50GB 180Days	50	180	30	Bulgaria 50GB 180Days	t	60	2025-04-23 15:49:55.350246
175	21	HR_CKH079	\N	Croatia 3GB 30Days	3	30	2.3	Croatia 3GB 30Days	t	4.6	2025-04-23 15:50:12.39692
176	21	HR_CKH118	\N	Croatia 5GB 30Days	5	30	3.4	Croatia 5GB 30Days	t	6.8	2025-04-23 15:50:12.396938
177	21	HR_CKH160	\N	Croatia 1GB 7Days	1	7	0.9	Croatia 1GB 7Days	t	1.8	2025-04-23 15:50:12.396944
178	21	HR_CKH161	\N	Croatia 3GB 15Days	3	15	2.2	Croatia 3GB 15Days	t	4.4	2025-04-23 15:50:12.396949
179	21	HR_CKH162	\N	Croatia 10GB 30Days	10	30	6.1	Croatia 10GB 30Days	t	12.2	2025-04-23 15:50:12.396954
180	21	HR_CKH539	\N	Croatia 20GB 30Days	20	30	10.6	Croatia 20GB 30Days	t	21.2	2025-04-23 15:50:12.396959
182	22	CY_CKH080	\N	Cyprus 3GB 30Days	3	30	2.3	Cyprus 3GB 30Days	t	4.6	2025-04-23 15:50:28.8134
183	22	CY_CKH119	\N	Cyprus 5GB 30Days	5	30	3.4	Cyprus 5GB 30Days	t	6.8	2025-04-23 15:50:28.813417
184	22	CY_CKH208	\N	Cyprus 1GB 7Days	1	7	0.9	Cyprus 1GB 7Days	t	1.8	2025-04-23 15:50:28.813423
185	22	CY_CKH209	\N	Cyprus 3GB 15Days	3	15	2.2	Cyprus 3GB 15Days	t	4.4	2025-04-23 15:50:28.813428
186	22	CY_CKH210	\N	Cyprus 10GB 30Days	10	30	6.1	Cyprus 10GB 30Days	t	12.2	2025-04-23 15:50:28.813434
187	22	CY_PXHQDYUBO	\N	Cyprus 50GB 180Days	50	180	30	Cyprus 50GB 180Days	t	60	2025-04-23 15:50:28.813439
188	23	CZ_CKH081	\N	Czech Republic 3GB 30Days	3	30	2.3	Czech Republic 3GB 30Days	t	4.6	2025-04-23 15:50:44.727178
189	23	CZ_CKH120	\N	Czech Republic 5GB 30Days	5	30	3.4	Czech Republic 5GB 30Days	t	6.8	2025-04-23 15:50:44.727194
190	23	CZ_CKH163	\N	Czech Republic 1GB 7Days	1	7	0.9	Czech Republic 1GB 7Days	t	1.8	2025-04-23 15:50:44.7272
767	109	ZM_CKH422	\N	Zambia 3GB 15Days	3	15	11.2	Zambia 3GB 15Days	t	22.4	2025-04-23 16:12:23.44451
768	109	ZM_CKH451	\N	Zambia 5GB 30Days	5	30	17.1	Zambia 5GB 30Days	t	34.2	2025-04-23 16:12:23.444515
771	110	KH_JC149	\N	Cambodia 10GB 30Days	10	30	15.2	Cambodia 10GB 30Days	t	30.4	2025-04-23 16:12:36.410943
772	110	KH_JC150	\N	Cambodia 20GB 30Days	20	30	25	Cambodia 20GB 30Days	t	50	2025-04-23 16:12:36.41095
773	110	KH_P04JLSJF8	\N	Cambodia 100MB 7Days	0.1	7	0.26		t	0.52	2025-04-23 16:12:36.410955
778	111	DZ_CKH810	\N	Algeria 20GB 30Days	20	30	12.9	Algeria 20GB 30Days	t	25.8	2025-04-23 16:12:45.852259
780	111	DZ_PJVN54W3O	\N	Algeria 100MB 7Days	0.1	7	0.11		t	0.22	2025-04-23 16:12:45.852275
195	24	DK_CKH082	\N	Denmark 3GB 30Days	3	30	2.3	Denmark 3GB 30Days	t	4.6	2025-04-23 15:51:00.664924
196	24	DK_CKH121	\N	Denmark 5GB 30Days	5	30	3.4	Denmark 5GB 30Days	t	6.8	2025-04-23 15:51:00.664945
197	24	DK_CKH166	\N	Denmark 1GB 7Days	1	7	0.9	Denmark 1GB 7Days	t	1.8	2025-04-23 15:51:00.664954
198	24	DK_CKH167	\N	Denmark 3GB 15Days	3	15	2.2	Denmark 3GB 15Days	t	4.4	2025-04-23 15:51:00.664961
202	25	EE_CKH083	\N	Estonia 3GB 30Days	3	30	2.3	Estonia 3GB 30Days	t	4.6	2025-04-23 15:51:16.953477
203	25	EE_CKH122	\N	Estonia 5GB 30Days	5	30	3.4	Estonia 5GB 30Days	t	6.8	2025-04-23 15:51:16.953497
204	25	EE_CKH211	\N	Estonia 1GB 7Days	1	7	0.9	Estonia 1GB 7Days	t	1.8	2025-04-23 15:51:16.953503
205	25	EE_CKH212	\N	Estonia 3GB 15Days	3	15	2.2	Estonia 3GB 15Days	t	4.4	2025-04-23 15:51:16.953508
206	25	EE_CKH213	\N	Estonia 10GB 30Days	10	30	6.1	Estonia 10GB 30Days	t	12.2	2025-04-23 15:51:16.953513
207	25	EE_CKH710	\N	Estonia 20GB 30Days	20	30	10.6	Estonia 20GB 30Days	t	21.2	2025-04-23 15:51:16.953519
209	26	FI_CKH084	\N	Finland 3GB 30Days	3	30	1.8	Finland 3GB 30Days	t	3.6	2025-04-23 15:51:32.991983
210	26	FI_CKH123	\N	Finland 5GB 30Days	5	30	2.7	Finland 5GB 30Days	t	5.4	2025-04-23 15:51:32.992
211	26	FI_CKH214	\N	Finland 1GB 7Days	1	7	0.7	Finland 1GB 7Days	t	1.4	2025-04-23 15:51:32.992007
212	26	FI_CKH215	\N	Finland 3GB 15Days	3	15	1.7	Finland 3GB 15Days	t	3.4	2025-04-23 15:51:32.992012
213	26	FI_CKH216	\N	Finland 10GB 30Days	10	30	4.7	Finland 10GB 30Days	t	9.4	2025-04-23 15:51:32.992017
214	26	FI_PU4UANEPA	\N	Finland 50GB 180Days	50	180	28	Finland 50GB 180Days	t	56	2025-04-23 15:51:32.992024
215	27	FR_CKH977	\N	France 3GB 30Days	3	30	2.3	France 3GB 30Days	t	4.6	2025-04-23 15:51:49.56505
216	27	FR_CKH983	\N	France 5GB 30Days	5	30	3.4	France 5GB 30Days	t	6.8	2025-04-23 15:51:49.565068
217	27	FR_CKH990	\N	France 1GB 7Days	1	7	0.9	France 1GB 7Days	t	1.8	2025-04-23 15:51:49.565074
218	27	FR_CKH991	\N	France 3GB 15Days	3	15	2.2	France 3GB 15Days	t	4.4	2025-04-23 15:51:49.565079
219	27	FR_CKH992	\N	France 10GB 30Days	10	30	6.1	France 10GB 30Days	t	12.2	2025-04-23 15:51:49.565085
226	28	DE_CKH978	\N	Germany 3GB 30Days	3	30	2.3	Germany 3GB 30Days	t	4.6	2025-04-23 15:52:05.620789
227	28	DE_CKH984	\N	Germany 5GB 30Days	5	30	3.4	Germany 5GB 30Days	t	6.8	2025-04-23 15:52:05.620809
228	28	DE_CKH993	\N	Germany 1GB 7Days	1	7	0.9	Germany 1GB 7Days	t	1.8	2025-04-23 15:52:05.620814
229	28	DE_CKH994	\N	Germany 3GB 15Days	3	15	2.2	Germany 3GB 15Days	t	4.4	2025-04-23 15:52:05.62082
230	28	DE_CKH995	\N	Germany 10GB 30Days	10	30	6.1	Germany 10GB 30Days	t	12.2	2025-04-23 15:52:05.620826
231	28	DE_CKH1013	\N	Germany 20GB 30Days	20	30	10.6	Germany 20GB 30Days	t	21.2	2025-04-23 15:52:05.620831
232	28	DE_PMDYU8KU3	\N	Germany 50GB 180Days	50	180	22	Germany 50GB 180Days	t	44	2025-04-23 15:52:05.620837
233	28	DE_PXB5F4VY4	\N	Germany 1GB/Day	1	1	0.85		t	1.7	2025-04-23 15:52:05.620842
234	28	DE_PQWSL862L	\N	Germany 500MB/Day	0.49	1	0.45	Germany 500MB/Day	t	0.9	2025-04-23 15:52:05.620847
237	29	GR_CKH979	\N	Greece 3GB 30Days	3	30	2.3	Greece 3GB 30Days	t	4.6	2025-04-23 15:52:21.751203
238	29	GR_CKH985	\N	Greece 5GB 30Days	5	30	3.4	Greece 5GB 30Days	t	6.8	2025-04-23 15:52:21.751222
239	29	GR_CKH996	\N	Greece 1GB 7Days	1	7	0.9	Greece 1GB 7Days	t	1.8	2025-04-23 15:52:21.751229
240	29	GR_CKH997	\N	Greece 3GB 15Days	3	15	2.2	Greece 3GB 15Days	t	4.4	2025-04-23 15:52:21.751234
241	29	GR_CKH998	\N	Greece 10GB 30Days	10	30	6.1	Greece 10GB 30Days	t	12.2	2025-04-23 15:52:21.75124
242	29	GR_CKH1007	\N	Greece 20GB 30Days	20	30	10.6	Greece 20GB 30Days	t	21.2	2025-04-23 15:52:21.751246
243	29	GR_PGLSEATB8	\N	Greece 50GB 180Days	50	180	22	Greece 50GB 180Days	t	44	2025-04-23 15:52:21.751252
244	30	HU_CKH088	\N	Hungary 3GB 30Days	3	30	2.3	Hungary 3GB 30Days	t	4.6	2025-04-23 15:52:38.225034
245	30	HU_CKH127	\N	Hungary 5GB 30Days	5	30	3.4	Hungary 5GB 30Days	t	6.8	2025-04-23 15:52:38.225062
246	30	HU_CKH178	\N	Hungary 1GB 7Days	1	7	0.9	Hungary 1GB 7Days	t	1.8	2025-04-23 15:52:38.225068
247	30	HU_CKH179	\N	Hungary 3GB 15Days	3	15	2.2	Hungary 3GB 15Days	t	4.4	2025-04-23 15:52:38.225073
248	30	HU_CKH180	\N	Hungary 10GB 30Days	10	30	6.1	Hungary 10GB 30Days	t	12.2	2025-04-23 15:52:38.225078
249	30	HU_CKH545	\N	Hungary 20GB 30Days	20	30	10.6	Hungary 20GB 30Days	t	21.2	2025-04-23 15:52:38.225085
250	30	HU_PNLUHHYLQ	\N	Hungary 50GB 180Days	50	180	22	Hungary 50GB 180Days	t	44	2025-04-23 15:52:38.225091
251	31	IS_CKH089	\N	Iceland 3GB 30Days	3	30	3.8	Iceland 3GB 30Days	t	7.6	2025-04-23 15:52:54.869675
252	31	IS_CKH128	\N	Iceland 5GB 30Days	5	30	5.7	Iceland 5GB 30Days	t	11.4	2025-04-23 15:52:54.869699
253	31	IS_CKH217	\N	Iceland 1GB 7Days	1	7	1.5	Iceland 1GB 7Days	t	3	2025-04-23 15:52:54.869705
254	31	IS_CKH218	\N	Iceland 3GB 15Days	3	15	3.7	Iceland 3GB 15Days	t	7.4	2025-04-23 15:52:54.869711
255	31	IS_CKH219	\N	Iceland 10GB 30Days	10	30	9.9	Iceland 10GB 30Days	t	19.8	2025-04-23 15:52:54.869716
790	113	CA_P4SQTPX02	\N	Canada 1GB/Day	1	1	1.8	Canada 1GB/Day	t	3.6	2025-04-23 16:13:11.825174
791	113	CA_PDSKSPL0T	\N	Canada 1.5GB/Day	1.5	1	2.7	Canada 1.5GB/Day	t	5.4	2025-04-23 16:13:11.82518
792	113	CA_P3BGO3VLL	\N	Canada 2GB/Day	2	1	3.6	Canada 2GB/Day	t	7.2	2025-04-23 16:13:11.825187
793	113	CA_PJYU684PF	\N	Canada 3GB 30Days	3	30	5.9	Canada 3GB 30Days	t	11.8	2025-04-23 16:13:11.825204
794	113	CA_PPPTNR783	\N	Canada 500MB/Day	0.49	1	0.9	Canada 500MB/Day	t	1.8	2025-04-23 16:13:11.825211
795	113	CA_P58GBEZQ3	\N	Canada 3GB/Day	3	1	5.4	Canada 3GB/Day	t	10.8	2025-04-23 16:13:11.825217
258	32	IE_CKH090	\N	Ireland 3GB 30Days	3	30	2.3	Ireland 3GB 30Days	t	4.6	2025-04-23 15:53:11.237826
259	32	IE_CKH129	\N	Ireland 5GB 30Days	5	30	3.4	Ireland 5GB 30Days	t	6.8	2025-04-23 15:53:11.237847
267	33	IT_CKH091	\N	Italy 3GB 30Days	3	30	2.3	Italy 3GB 30Days	t	4.6	2025-04-23 15:53:29.022803
268	33	IT_CKH130	\N	Italy 5GB 30Days	5	30	3.4	Italy 5GB 30Days	t	6.8	2025-04-23 15:53:29.022818
269	33	IT_CKH227	\N	Italy 1GB 7Days	1	7	0.9	Italy 1GB 7Days	t	1.8	2025-04-23 15:53:29.022823
270	33	IT_CKH228	\N	Italy 3GB 15Days	3	15	2.2	Italy 3GB 15Days	t	4.4	2025-04-23 15:53:29.022828
271	33	IT_CKH229	\N	Italy 10GB 30Days	10	30	6.1	Italy 10GB 30Days	t	12.2	2025-04-23 15:53:29.022833
272	33	IT_CKH504	\N	Italy 20GB 30Days	20	30	10.6	Italy 20GB 30Days	t	21.2	2025-04-23 15:53:29.022838
273	33	IT_PX1CNITSE	\N	Italy 50GB 180Days	50	180	22	Italy 50GB 180Days	t	44	2025-04-23 15:53:29.022843
274	33	IT_PZARONTRP	\N	Italy 1GB/Day	1	1	0.85		t	1.7	2025-04-23 15:53:29.022848
278	34	LV_CKH092	\N	Latvia 3GB 30Days	3	30	2.3	Latvia 3GB 30Days	t	4.6	2025-04-23 15:53:46.401866
279	34	LV_CKH131	\N	Latvia 5GB 30Days	5	30	3.4	Latvia 5GB 30Days	t	6.8	2025-04-23 15:53:46.401884
280	34	LV_CKH181	\N	Latvia 1GB 7Days	1	7	0.9	Latvia 1GB 7Days	t	1.8	2025-04-23 15:53:46.40189
281	34	LV_CKH182	\N	Latvia 3GB 15Days	3	15	2.2	Latvia 3GB 15Days	t	4.4	2025-04-23 15:53:46.401896
282	34	LV_CKH183	\N	Latvia 10GB 30Days	10	30	6.1	Latvia 10GB 30Days	t	12.2	2025-04-23 15:53:46.401902
283	34	LV_CKH702	\N	Latvia 20GB 30Days	20	30	10.6	Latvia 20GB 30Days	t	21.2	2025-04-23 15:53:46.401908
284	34	LV_PUS1LIQUY	\N	Latvia 50GB 180Days	50	180	30	Latvia 50GB 180Days	t	60	2025-04-23 15:53:46.401914
285	35	LT_CKH093	\N	Lithuania 3GB 30Days	3	30	2.3	Lithuania 3GB 30Days	t	4.6	2025-04-23 15:54:04.255399
286	35	LT_CKH132	\N	Lithuania 5GB 30Days	5	30	3.4	Lithuania 5GB 30Days	t	6.8	2025-04-23 15:54:04.255422
287	35	LT_CKH184	\N	Lithuania 1GB 7Days	1	7	0.9	Lithuania 1GB 7Days	t	1.8	2025-04-23 15:54:04.255428
288	35	LT_CKH185	\N	Lithuania 3GB 15Days	3	15	2.2	Lithuania 3GB 15Days	t	4.4	2025-04-23 15:54:04.255434
289	35	LT_CKH186	\N	Lithuania 10GB 30Days	10	30	9.9	Lithuania 10GB 30Days	t	19.8	2025-04-23 15:54:04.255439
290	35	LT_CKH704	\N	Lithuania 20GB 30Days	20	30	16.8	Lithuania 20GB 30Days	t	33.6	2025-04-23 15:54:04.255445
291	35	LT_PDCRKSTTY	\N	Lithuania 50GB 180Days	50	180	37	Lithuania 50GB 180Days	t	74	2025-04-23 15:54:04.255451
292	36	LU_CKH094	\N	Luxembourg 3GB 30Days	3	30	2.3	Luxembourg 3GB 30Days	t	4.6	2025-04-23 15:54:21.706868
293	36	LU_CKH133	\N	Luxembourg 5GB 30Days	5	30	3.4	Luxembourg 5GB 30Days	t	6.8	2025-04-23 15:54:21.70689
294	36	LU_CKH230	\N	Luxembourg 1GB 7Days	1	7	0.9	Luxembourg 1GB 7Days	t	1.8	2025-04-23 15:54:21.706895
295	36	LU_CKH231	\N	Luxembourg 3GB 15Days	3	15	2.2	Luxembourg 3GB 15Days	t	4.4	2025-04-23 15:54:21.7069
296	36	LU_CKH232	\N	Luxembourg 10GB 30Days	10	30	6.1	Luxembourg 10GB 30Days	t	12.2	2025-04-23 15:54:21.706906
297	36	LU_CKH716	\N	Luxembourg 20GB 30Days	20	30	10.6	Luxembourg 20GB 30Days	t	21.2	2025-04-23 15:54:21.706916
298	36	LU_PQIWDILIV	\N	Luxembourg 50GB 180Days	50	180	30	Luxembourg 50GB 180Days	t	60	2025-04-23 15:54:21.706922
299	37	MT_CKH095	\N	Malta 3GB 30Days	3	30	3.8	Malta 3GB 30Days	t	7.6	2025-04-23 15:54:38.519124
300	37	MT_CKH134	\N	Malta 5GB 30Days	5	30	5.7	Malta 5GB 30Days	t	11.4	2025-04-23 15:54:38.519141
301	37	MT_CKH187	\N	Malta 1GB 7Days	1	7	1.5	Malta 1GB 7Days	t	3	2025-04-23 15:54:38.519151
302	37	MT_CKH188	\N	Malta 3GB 15Days	3	15	3.7	Malta 3GB 15Days	t	7.4	2025-04-23 15:54:38.519199
303	37	MT_CKH189	\N	Malta 10GB 30Days	10	30	9.9	Malta 10GB 30Days	t	19.8	2025-04-23 15:54:38.519207
304	37	MT_CKH706	\N	Malta 20GB 30Days	20	30	16.8	Malta 20GB 30Days	t	33.6	2025-04-23 15:54:38.519213
305	38	PL_CKH096	\N	Poland 3GB 30Days	3	30	1.8	Poland 3GB 30Days	t	3.6	2025-04-23 15:54:56.713699
306	38	PL_CKH135	\N	Poland 5GB 30Days	5	30	2.7	Poland 5GB 30Days	t	5.4	2025-04-23 15:54:56.713722
307	38	PL_CKH236	\N	Poland 1GB 7Days	1	7	0.7	Poland 1GB 7Days	t	1.4	2025-04-23 15:54:56.713728
308	38	PL_CKH237	\N	Poland 3GB 15Days	3	15	1.7	Poland 3GB 15Days	t	3.4	2025-04-23 15:54:56.713735
309	38	PL_CKH726	\N	Poland 20GB 30Days	20	30	8.2	Poland 20GB 30Days	t	16.4	2025-04-23 15:54:56.71374
311	39	PT_CKH980	\N	Portugal 3GB 30Days	3	30	2.3	Portugal 3GB 30Days	t	4.6	2025-04-23 15:55:14.202704
312	39	PT_CKH986	\N	Portugal 5GB 30Days	5	30	3.4	Portugal 5GB 30Days	t	6.8	2025-04-23 15:55:14.202724
313	39	PT_CKH1002	\N	Portugal 1GB 7Days	1	7	0.9	Portugal 1GB 7Days	t	1.8	2025-04-23 15:55:14.202729
314	39	PT_CKH1003	\N	Portugal 3GB 15Days	3	15	2.2	Portugal 3GB 15Days	t	4.4	2025-04-23 15:55:14.202734
315	39	PT_CKH1004	\N	Portugal 10GB 30Days	10	30	6.1	Portugal 10GB 30Days	t	12.2	2025-04-23 15:55:14.202739
318	40	RO_CKH098	\N	Romania 3GB 30Days	3	30	1.8	Romania 3GB 30Days	t	3.6	2025-04-23 15:55:31.816074
319	40	RO_CKH137	\N	Romania 5GB 30Days	5	30	2.7	Romania 5GB 30Days	t	5.4	2025-04-23 15:55:31.816094
320	40	RO_CKH239	\N	Romania 1GB 7Days	1	7	0.7	Romania 1GB 7Days	t	1.4	2025-04-23 15:55:31.816102
796	113	CA_P62Q7VLTJ	\N	Canada 10GB 30Days Single Use	10	30	18	Canada 10GB 30Days Single Use	t	36	2025-04-23 16:13:11.825223
797	113	CA_PL1YY76UZ	\N	Canada 5GB  30Days Single Use	5	30	10	Canada 5GB  30Days Single Use	t	20	2025-04-23 16:13:11.825229
798	113	CA_PUYZ1X5Z9	\N	Canada 3GB  30Days Single Use	3	30	6.6	Canada 3GB  30Days Single Use	t	13.2	2025-04-23 16:13:11.825236
799	113	CA_PNGH5E6S7	\N	Canada 1GB 7Days Single Use	1	7	2.5	Canada 1GB 7Days Single Use	t	5	2025-04-23 16:13:11.825242
800	113	CA_PT73ZDYVK	\N	Canada 100MB 7Days	0.1	7	0.23		t	0.46	2025-04-23 16:13:11.825248
831	121	AL_CKH549	\N	Albania 5GB 30Days	5	30	11	Albania 5GB 30Days	t	22	2025-04-23 16:14:57.603306
832	121	AL_CKH952	\N	Albania 10GB 30Days	10	30	18.5	Albania 10GB 30Days	t	37	2025-04-23 16:14:57.603313
833	121	AL_CKH953	\N	Albania 20GB 30Days	20	30	33	Albania 20GB 30Days	t	66	2025-04-23 16:14:57.603319
325	41	SK_CKH099	\N	Slovakia 3GB 30Days	3	30	2.3	Slovakia 3GB 30Days	t	4.6	2025-04-23 15:55:50.843823
326	41	SK_CKH138	\N	Slovakia 5GB 30Days	5	30	3.4	Slovakia 5GB 30Days	t	6.8	2025-04-23 15:55:50.843843
327	41	SK_CKH196	\N	Slovakia 1GB 7Days	1	7	0.9	Slovakia 1GB 7Days	t	1.8	2025-04-23 15:55:50.843849
332	42	SI_CKH100	\N	Slovenia 3GB 30Days	3	30	2.3	Slovenia 3GB 30Days	t	4.6	2025-04-23 15:56:07.718352
333	42	SI_CKH139	\N	Slovenia 5GB 30Days	5	30	3.4	Slovenia 5GB 30Days	t	6.8	2025-04-23 15:56:07.718437
334	42	SI_CKH242	\N	Slovenia 1GB 7Days	1	7	0.9	Slovenia 1GB 7Days	t	1.8	2025-04-23 15:56:07.718508
335	42	SI_CKH243	\N	Slovenia 3GB 15Days	3	15	2.2	Slovenia 3GB 15Days	t	4.4	2025-04-23 15:56:07.718516
336	42	SI_CKH244	\N	Slovenia 10GB 30Days	10	30	6.1	Slovenia 10GB 30Days	t	12.2	2025-04-23 15:56:07.718527
337	42	SI_CKH732	\N	Slovenia 20GB 30Days	20	30	10.6	Slovenia 20GB 30Days	t	21.2	2025-04-23 15:56:07.718534
339	43	SE_CKH101	\N	Sweden 3GB 30Days	3	30	2.3	Sweden 3GB 30Days	t	4.6	2025-04-23 15:56:23.98221
340	43	SE_CKH140	\N	Sweden 5GB 30Days	5	30	3.4	Sweden 5GB 30Days	t	6.8	2025-04-23 15:56:23.982227
341	43	SE_CKH199	\N	Sweden 1GB 7Days	1	7	0.9	Sweden 1GB 7Days	t	1.8	2025-04-23 15:56:23.982233
342	43	SE_CKH200	\N	Sweden 3GB 15Days	3	15	2.2	Sweden 3GB 15Days	t	4.4	2025-04-23 15:56:23.982238
343	43	SE_CKH201	\N	Sweden 10GB 30Days	10	30	6.1	Sweden 10GB 30Days	t	12.2	2025-04-23 15:56:23.982244
344	43	SE_CKH734	\N	Sweden 20GB 30Days	20	30	10.6	Sweden 20GB 30Days	t	21.2	2025-04-23 15:56:23.982249
345	44	CH_CKH102	\N	Switzerland 3GB 30Days	3	30	2.3	Switzerland 3GB 30Days	t	4.6	2025-04-23 15:56:40.602533
346	44	CH_CKH141	\N	Switzerland 5GB 30Days	5	30	3.4	Switzerland 5GB 30Days	t	6.8	2025-04-23 15:56:40.602554
347	44	CH_CKH247	\N	Switzerland 1GB 7Days	1	7	0.9	Switzerland 1GB 7Days	t	1.8	2025-04-23 15:56:40.60256
348	44	CH_CKH248	\N	Switzerland 3GB 15Days	3	15	2.2	Switzerland 3GB 15Days	t	4.4	2025-04-23 15:56:40.602565
349	44	CH_CKH249	\N	Switzerland 10GB 30Days	10	30	6.1	Switzerland 10GB 30Days	t	12.2	2025-04-23 15:56:40.60257
353	45	UA_CKH103	\N	Ukraine 3GB 30Days	3	30	1.8	Ukraine 3GB 30Days	t	3.6	2025-04-23 15:56:57.126918
354	45	UA_CKH142	\N	Ukraine 5GB 30Days	5	30	2.7	Ukraine 5GB 30Days	t	5.4	2025-04-23 15:56:57.126934
355	45	UA_CKH250	\N	Ukraine 1GB 7Days	1	7	0.7	Ukraine 1GB 7Days	t	1.4	2025-04-23 15:56:57.126939
356	45	UA_CKH251	\N	Ukraine 3GB 15Days	3	15	1.7	Ukraine 3GB 15Days	t	3.4	2025-04-23 15:56:57.126944
357	45	UA_CKH252	\N	Ukraine 10GB 30Days	10	30	4.7	Ukraine 10GB 30Days	t	9.4	2025-04-23 15:56:57.12695
358	45	UA_P3AFY29GY	\N	Ukraine 1GB/Day	1	1	0.65	Ukraine 1GB/Day	t	1.3	2025-04-23 15:56:57.126955
359	46	GB_CKH104	\N	United Kingdom 3GB 30Days	3	30	2.3	United Kingdom 3GB 30Days	t	4.6	2025-04-23 15:57:13.004736
360	46	GB_CKH143	\N	United Kingdom 5GB 30Days	5	30	3.4	United Kingdom 5GB 30Days	t	6.8	2025-04-23 15:57:13.004752
361	46	GB_CKH253	\N	United Kingdom 1GB 7Days	1	7	0.9	United Kingdom 1GB 7Days	t	1.8	2025-04-23 15:57:13.004758
362	46	GB_CKH254	\N	United Kingdom 3GB 15Days	3	15	2.2	United Kingdom 3GB 15Days	t	4.4	2025-04-23 15:57:13.004763
363	46	GB_CKH255	\N	United Kingdom 10GB 30Days	10	30	6.1	United Kingdom 10GB 30Days	t	12.2	2025-04-23 15:57:13.004769
364	46	GB_CKH509	\N	United Kingdom 20GB 30Days	20	30	10.6	United Kingdom 20GB 30Days	t	21.2	2025-04-23 15:57:13.004774
370	47	AX_CKH105	\N	Aaland Islands 3GB 30Days	3	30	4.7	Aaland Islands 3GB 30Days	t	9.4	2025-04-23 15:57:23.630414
371	47	AX_CKH144	\N	Aaland Islands 5GB 30Days	5	30	7	Aaland Islands 5GB 30Days	t	14	2025-04-23 15:57:23.630435
372	47	AX_CKH256	\N	Aaland Islands 1GB 7Days	1	7	1.8	Aaland Islands 1GB 7Days	t	3.6	2025-04-23 15:57:23.630443
373	47	AX_CKH257	\N	Aaland Islands 3GB 15Days	3	15	4.6	Aaland Islands 3GB 15Days	t	9.2	2025-04-23 15:57:23.63045
374	47	AX_CKH740	\N	Aaland Islands 20GB 30Days	20	30	20	Aaland Islands 20GB 30Days	t	40	2025-04-23 15:57:23.630458
375	48	IM_CKH106	\N	Isle of Man 3GB 30Days	3	30	3	Isle of Man 3GB 30Days	t	6	2025-04-23 15:57:34.032127
376	48	IM_CKH145	\N	Isle of Man 5GB 30Days	5	30	4.4	Isle of Man 5GB 30Days	t	8.8	2025-04-23 15:57:34.032149
377	48	IM_CKH259	\N	Isle of Man 1GB 7Days	1	7	1.1	Isle of Man 1GB 7Days	t	2.2	2025-04-23 15:57:34.032158
378	48	IM_CKH260	\N	Isle of Man 3GB 15Days	3	15	2.8	Isle of Man 3GB 15Days	t	5.6	2025-04-23 15:57:34.032166
379	48	IM_CKH745	\N	Isle of Man 20GB 30Days	20	30	12.9	Isle of Man 20GB 30Days	t	25.8	2025-04-23 15:57:34.032175
380	49	JE_CKH107	\N	Jersey 3GB 30Days	3	30	1.8	Jersey 3GB 30Days	t	3.6	2025-04-23 15:57:44.568522
381	49	JE_CKH146	\N	Jersey 5GB 30Days	5	30	2.7	Jersey 5GB 30Days	t	5.4	2025-04-23 15:57:44.568542
382	49	JE_CKH262	\N	Jersey 1GB 7Days	1	7	0.7	Jersey 1GB 7Days	t	1.4	2025-04-23 15:57:44.568548
383	49	JE_CKH263	\N	Jersey 3GB 15Days	3	15	1.7	Jersey 3GB 15Days	t	3.4	2025-04-23 15:57:44.568554
834	121	AL_PL5JS8GQQ	\N	Albania 3GB 30Days	3	30	7.3	Albania 3GB 30Days	t	14.6	2025-04-23 16:14:57.603325
835	121	AL_PFRQ8FIBC	\N	Albania 100MB 7Days	0.1	7	0.28		t	0.56	2025-04-23 16:14:57.603331
836	121	AL_PP2FWWA8N	\N	Albania 500MB/Day	0.49	1	1.6		t	3.2	2025-04-23 16:14:57.603338
837	121	AL_PT6YNFLX8	\N	Albania 1GB/Day	1	1	2.8		t	5.6	2025-04-23 16:14:57.603349
838	121	AL_PSXVB0YDP	\N	Albania 2GB/Day	2	1	5.3		t	10.6	2025-04-23 16:14:57.603356
861	129	KZ_CKH751	\N	Kazakhstan 20GB 30Days	20	30	16.8	Kazakhstan 20GB 30Days	t	33.6	2025-04-23 16:16:37.22426
862	129	KZ_PHGAWJM6O	\N	Kazakhstan 100MB 7Days	0.1	7	0.15		t	0.3	2025-04-23 16:16:37.224265
385	50	RU_JC068	\N	Russia 3GB 30Days	3	30	7.3	Russia 3GB 30Days	t	14.6	2025-04-23 15:57:58.530633
390	51	GG_CKH109	\N	Guernsey 3GB 30Days	3	30	11.4	Guernsey 3GB 30Days	t	22.8	2025-04-23 15:58:09.152969
391	51	GG_CKH148	\N	Guernsey 5GB 30Days	5	30	17.1	Guernsey 5GB 30Days	t	34.2	2025-04-23 15:58:09.153022
392	51	GG_CKH608	\N	Guernsey 1GB 7Days	1	7	4.6	Guernsey 1GB 7Days	t	9.2	2025-04-23 15:58:09.15303
393	51	GG_CKH609	\N	Guernsey 3GB 15Days	3	15	11.2	Guernsey 3GB 15Days	t	22.4	2025-04-23 15:58:09.153039
395	52	LI_CKH981	\N	Liechtenstein 3GB 30Days	3	30	3.8	Liechtenstein 3GB 30Days	t	7.6	2025-04-23 15:58:25.483715
396	52	LI_CKH1015	\N	Liechtenstein 1GB 7Days	1	7	1.5	Liechtenstein 1GB 7Days	t	3	2025-04-23 15:58:25.483733
397	52	LI_CKH1021	\N	Liechtenstein 3GB 15Days	3	15	3.7	Liechtenstein 3GB 15Days	t	7.4	2025-04-23 15:58:25.483739
398	53	NO_CKH982	\N	Norway 3GB 30Days	3	30	1.8	Norway 3GB 30Days	t	3.6	2025-04-23 15:58:40.80602
399	53	NO_CKH988	\N	Norway 5GB 30Days	5	30	2.7	Norway 5GB 30Days	t	5.4	2025-04-23 15:58:40.806054
400	53	NO_CKH999	\N	Norway 1GB 7Days	1	7	0.7	Norway 1GB 7Days	t	1.4	2025-04-23 15:58:40.80606
401	53	NO_CKH1000	\N	Norway 3GB 15Days	3	15	1.7	Norway 3GB 15Days	t	3.4	2025-04-23 15:58:40.806066
406	54	RS_CKH113	\N	Serbia 3GB 30Days	3	30	7.3	Serbia 3GB 30Days	t	14.6	2025-04-23 15:58:54.781045
407	54	RS_CKH1016	\N	Serbia 1GB 7Days	1	7	2.9	Serbia 1GB 7Days	t	5.8	2025-04-23 15:58:54.781063
408	54	RS_CKH677	\N	Serbia 3GB 15Days	3	15	7.2	Serbia 3GB 15Days	t	14.4	2025-04-23 15:58:54.781069
409	54	RS_CKH803	\N	Serbia 20GB 30Days	20	30	32	Serbia 20GB 30Days	t	64	2025-04-23 15:58:54.781075
410	54	RS_PHLQ4R8Z8	\N	Serbia 100MB 7Days	0.1	7	0.32		t	0.64	2025-04-23 15:58:54.781081
411	55	GI_CKH114	\N	Gibraltar 3GB 30Days	3	30	7.3	Gibraltar 3GB 30Days	t	14.6	2025-04-23 15:59:07.405724
412	55	GI_CKH481	\N	Gibraltar 1GB 7Days	1	7	2.9	Gibraltar 1GB 7Days	t	5.8	2025-04-23 15:59:07.405742
413	55	GI_CKH482	\N	Gibraltar 3GB 15Days	3	15	7.2	Gibraltar 3GB 15Days	t	14.4	2025-04-23 15:59:07.405747
414	56	AU_JC018	\N	Australia 1GB 7Days	1	7	0.7	Australia 1GB 7Days	t	1.4	2025-04-23 15:59:19.99311
415	56	AU_JC019	\N	Australia 3GB 15Days	3	15	1.7	Australia 3GB 15Days	t	3.4	2025-04-23 15:59:19.993127
416	56	AU_JC020	\N	Australia 5GB 30Days	5	30	2.7	Australia 5GB 30Days	t	5.4	2025-04-23 15:59:19.993133
417	56	AU_JC101	\N	Australia 10GB 30Days	10	30	4.7	Australia 10GB 30Days	t	9.4	2025-04-23 15:59:19.993139
418	56	AU_JC102	\N	Australia 20GB 30Days	20	30	8.2	Australia 20GB 30Days	t	16.4	2025-04-23 15:59:19.993146
427	57	MY_JC027	\N	Malaysia 1GB 7Days	1	7	0.7	Malaysia 1GB 7Days	t	1.4	2025-04-23 15:59:33.52819
428	57	MY_JC028	\N	Malaysia 3GB 15Days	3	15	1.7	Malaysia 3GB 15Days	t	3.4	2025-04-23 15:59:33.528208
429	57	MY_JC029	\N	Malaysia 5GB 30Days	5	30	2.7	Malaysia 5GB 30Days	t	5.4	2025-04-23 15:59:33.528214
430	57	MY_JC030	\N	Malaysia 10GB 30Days	10	30	4.7	Malaysia 10GB 30Days	t	9.4	2025-04-23 15:59:33.528219
431	57	MY_JC097	\N	Malaysia 20GB 30Days	20	30	8.2	Malaysia 20GB 30Days	t	16.4	2025-04-23 15:59:33.528224
432	57	MY_PBAGTADCE	\N	Malaysia 50GB 180Days	50	180	28	Malaysia 50GB 180Days	t	56	2025-04-23 15:59:33.528229
433	57	MY_PAN6REMMI	\N	Malaysia 500MB/Day	0.49	1	0.5	Malaysia 500MB/Day	t	1	2025-04-23 15:59:33.528234
434	57	MY_P4UTFE9WB	\N	Malaysia 1GB/Day	1	1	0.9	Malaysia 1GB/Day	t	1.8	2025-04-23 15:59:33.528239
435	57	MY_POLZ7NLE0	\N	Malaysia 2GB/Day	2	1	1.7	Malaysia 2GB/Day	t	3.4	2025-04-23 15:59:33.528244
436	57	MY_PT4RIB8UL	\N	Malaysia 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 15:59:33.528249
437	57	MY_P298MQEKY	\N	Malaysia 1GB 7Days (nonhkip)	1	7	1	Malaysia 1GB 7Days (nonhkip)	t	2	2025-04-23 15:59:33.528253
445	58	NZ_JC031	\N	New Zealand 1GB 7Days	1	7	1.8	New Zealand 1GB 7Days	t	3.6	2025-04-23 15:59:46.498132
446	58	NZ_JC032	\N	New Zealand 3GB 15Days	3	15	4.6	New Zealand 3GB 15Days	t	9.2	2025-04-23 15:59:46.498148
447	58	NZ_JC033	\N	New Zealand 5GB 30Days	5	30	7	New Zealand 5GB 30Days	t	14	2025-04-23 15:59:46.498154
870	131	DO_PSW0PJJ42	\N	Dominican Republic 100MB 7Days	0.1	7	0.58		t	1.16	2025-04-23 16:16:58.459103
878	133	BN_PU2ENL69H	\N	Brunei Darussalam 1GB/Day	1	1	14.5	Brunei Darussalam 1GB/Day	t	29	2025-04-23 16:17:13.523528
886	135	US_PHAJHEAYP	\N	United States 1GB 7Days	1	7	0.9	United States 1GB 7Days	t	1.8	2025-04-23 16:17:39.29752
887	135	US_PKJNMJIIU	\N	United States 5GB 30Days	5	30	3.4	United States 5GB 30Days	t	6.8	2025-04-23 16:17:39.297526
888	135	US_PKY3WHPRZ	\N	United States 3GB 30Days	3	30	2.3	United States 3GB 30Days	t	4.6	2025-04-23 16:17:39.297534
889	135	US_P5NHFJKUS	\N	United States 1GB/Day	1	1	1.3	United States 1GB/Day	t	2.6	2025-04-23 16:17:39.297543
890	135	US_P7KMNQCEM	\N	United States 1.5GB/Day	1.5	1	1.6	United States 1.5GB/Day	t	3.2	2025-04-23 16:17:39.297557
891	135	US_P2D1OQDLK	\N	United States 2GB/Day	2	1	2.3	United States 2GB/Day	t	4.6	2025-04-23 16:17:39.297572
892	135	US_PZGX3L09J	\N	United States 3GB/Day	3	1	3.8	United States 3GB/Day	t	7.6	2025-04-23 16:17:39.29758
893	135	US_PCD8C1K9R	\N	United States 500MB/Day	0.49	1	0.86	United States 500MB/Day	t	1.72	2025-04-23 16:17:39.29759
894	135	US_P0VDH4W3H	\N	United States 10GB/Day	10	1	12.4	United States 10GB/Day	t	24.8	2025-04-23 16:17:39.297597
895	135	US_PAQ367DAU	\N	United States 10GB 30Days Single Use	10	30	5.9	United States 10GB 30Days Single Use	t	11.8	2025-04-23 16:17:39.297605
896	135	US_PA0GX5V6R	\N	United States 5GB  30Days Single Use	5	30	3.25	United States 5GB  30Days Single Use	t	6.5	2025-04-23 16:17:39.297613
456	59	PH_JC034	\N	Philippines 1GB 7Days	1	7	1.8	Philippines 1GB 7Days	t	3.6	2025-04-23 16:00:00.448271
457	59	PH_JC035	\N	Philippines 3GB 15Days	3	15	4.6	Philippines 3GB 15Days	t	9.2	2025-04-23 16:00:00.448291
458	59	PH_JC036	\N	Philippines 5GB 30Days	5	30	7	Philippines 5GB 30Days	t	14	2025-04-23 16:00:00.448298
459	59	PH_JC037	\N	Philippines 10GB 30Days	10	30	12.2	Philippines 10GB 30Days	t	24.4	2025-04-23 16:00:00.448304
460	59	PH_JC099	\N	Philippines 20GB 30Days	20	30	20	Philippines 20GB 30Days	t	40	2025-04-23 16:00:00.448309
461	59	PH_PYEPCSNFU	\N	Philippines 50GB 180Days	50	180	45	Philippines 50GB 180Days	t	90	2025-04-23 16:00:00.448315
462	59	PH_PKI8J4QW7	\N	Philippines 500MB/Day	0.49	1	0.8	Philippines 500MB/Day	t	1.6	2025-04-23 16:00:00.448321
468	60	SG_JC038	\N	Singapore 1GB 7Days	1	7	0.7	Singapore 1GB 7Days	t	1.4	2025-04-23 16:00:16.223344
469	60	SG_JC040	\N	Singapore 5GB 30Days	5	30	2.7	Singapore 5GB 30Days	t	5.4	2025-04-23 16:00:16.223366
470	60	SG_JC041	\N	Singapore 10GB 30Days	10	30	4.7	Singapore 10GB 30Days	t	9.4	2025-04-23 16:00:16.223372
471	60	SG_JC092	\N	Singapore 20GB 30Days	20	30	8.2	Singapore 20GB 30Days	t	16.4	2025-04-23 16:00:16.223378
472	60	SG_JC093	\N	Singapore 50GB 30Days	50	30	28	Singapore 50GB 30Days	t	56	2025-04-23 16:00:16.223384
473	60	SG_PR2GUXUD5	\N	Singapore 3GB 30Days	3	30	1.8	Singapore 3GB 30Days	t	3.6	2025-04-23 16:00:16.223389
474	60	SG_P7YECLII9	\N	Singapore 1GB/Day	1	1	0.9	Singapore 1GB/Day	t	1.8	2025-04-23 16:00:16.223395
475	60	SG_PXAZ8ZALE	\N	Singapore 2GB/Day	2	1	1.8	Singapore 2GB/Day	t	3.6	2025-04-23 16:00:16.2234
476	60	SG_PH83BFJ2F	\N	Singapore 500MB/Day	0.49	1	0.5	Singapore 500MB/Day	t	1	2025-04-23 16:00:16.223406
477	60	SG_P3LR5JXFO	\N	Singapore 10GB/Day	10	1	9		t	18	2025-04-23 16:00:16.223412
487	61	LK_JC042	\N	Sri Lanka 1GB 7Days	1	7	2.9	Sri Lanka 1GB 7Days	t	5.8	2025-04-23 16:00:31.208499
488	61	LK_JC043	\N	Sri Lanka 3GB 15Days	3	15	4.8	Sri Lanka 3GB 15Days	t	9.6	2025-04-23 16:00:31.20854
489	61	LK_JC044	\N	Sri Lanka 5GB 30Days	5	30	7.7	Sri Lanka 5GB 30Days	t	15.4	2025-04-23 16:00:31.208555
490	61	LK_JC085	\N	Sri Lanka 10GB 30Days	10	30	15.4	Sri Lanka 10GB 30Days	t	30.8	2025-04-23 16:00:31.20857
491	61	LK_JC086	\N	Sri Lanka 20GB 30Days	20	30	28	Sri Lanka 20GB 30Days	t	56	2025-04-23 16:00:31.208584
492	61	LK_PVCA0JAXV	\N	Sri Lanka 50GB 180Days	50	180	71	Sri Lanka 50GB 180Days	t	142	2025-04-23 16:00:31.2086
493	61	LK_PTSKLWZVK	\N	Sri Lanka 3GB 30Days	3	30	4.9		t	9.8	2025-04-23 16:00:31.208615
494	61	LK_PF4K8XI0Q	\N	Sri Lanka 500MB/Day	0.49	1	1.3		t	2.6	2025-04-23 16:00:31.208647
495	61	LK_PB6CYXWPA	\N	Sri Lanka 1GB/Day	1	1	2.2		t	4.4	2025-04-23 16:00:31.208677
496	61	LK_PSUGO9SDM	\N	Sri Lanka 2GB/Day	2	1	3.2		t	6.4	2025-04-23 16:00:31.208699
497	61	LK_PGP70GWM9	\N	Sri Lanka 3GB/Day	3	1	4.4		t	8.8	2025-04-23 16:00:31.208705
498	61	LK_PWNVS0KKQ	\N	Sri Lanka 5GB/Day	5	1	7		t	14	2025-04-23 16:00:31.208711
499	61	LK_PWJT28BG0	\N	Sri Lanka 100MB 7Days	0.1	7	0.28		t	0.56	2025-04-23 16:00:31.208716
500	62	VN_JC048	\N	Vietnam 1GB 7Days	1	7	1.8	Vietnam 1GB 7Days	t	3.6	2025-04-23 16:00:42.997905
501	62	VN_JC049	\N	Vietnam 3GB 15Days	3	15	4.6	Vietnam 3GB 15Days	t	9.2	2025-04-23 16:00:42.997964
502	62	VN_JC050	\N	Vietnam 5GB 30Days	5	30	7	Vietnam 5GB 30Days	t	14	2025-04-23 16:00:42.99797
503	62	VN_JC051	\N	Vietnam 10GB 30Days	10	30	12.2	Vietnam 10GB 30Days	t	24.4	2025-04-23 16:00:42.997977
504	62	VN_JC088	\N	Vietnam 20GB 30Days	20	30	20	Vietnam 20GB 30Days	t	40	2025-04-23 16:00:42.99808
505	62	VN_PU3OJKPFD	\N	Vietnam 50GB 180Days	50	180	45	Vietnam 50GB 180Days	t	90	2025-04-23 16:00:42.998089
506	62	VN_PT2J1Y4JX	\N	Vietnam 1GB/Day	1	1	1.46	Vietnam 1GB/Day	t	2.92	2025-04-23 16:00:42.998096
507	62	VN_PUHL77M18	\N	Vietnam 10GB/Day	10	1	13.6		t	27.2	2025-04-23 16:00:42.998102
508	62	VN_PTS4IGND3	\N	Vietnam 500MB/Day	0.49	1	0.58		t	1.15	2025-04-23 16:00:42.998109
509	62	VN_PM2K0J3TX	\N	Vietnam 2GB/Day	2	1	2.8	Vietnam 2GB/Day	t	5.6	2025-04-23 16:00:42.998115
510	62	VN_PIK0SW14Q	\N	Vietnam 100MB 7Days	0.1	7	0.18		t	0.36	2025-04-23 16:00:42.998122
571	66	JP_JC066	\N	Japan 10GB 30Days	10	30	4.7	Japan 10GB 30Days	t	9.4	2025-04-23 16:01:45.484493
897	135	US_P50J6FMKJ	\N	United States 3GB  30Days Single Use	3	30	2.2	United States 3GB  30Days Single Use	t	4.4	2025-04-23 16:17:39.297631
898	135	US_PZNVW17M2	\N	United States 1GB  7Days Single Use	1	7	0.8	United States 1GB  7Days Single Use	t	1.6	2025-04-23 16:17:39.297649
918	139	JM_PLKIA6PIQ	\N	Jamaica 20GB 30Days	20	30	89.58		t	179.16	2025-04-23 16:18:10.665145
519	63	CN_JC052	\N	China 1GB 7Days	1	7	0.7	China 1GB 7Days	t	1.4	2025-04-23 16:00:59.205274
520	63	CN_JC053	\N	China 3GB 15Days	3	15	1.7	China 3GB 15Days	t	3.4	2025-04-23 16:00:59.205291
521	63	CN_JC054	\N	China 5GB 30Days	5	30	2.7	China 5GB 30Days	t	5.4	2025-04-23 16:00:59.205298
522	63	CN_JC055	\N	China 10GB 30Days	10	30	4.7	China 10GB 30Days	t	9.4	2025-04-23 16:00:59.205304
523	63	CN_JC090	\N	China 20GB 30Days	20	30	8.2	China 20GB 30Days	t	16.4	2025-04-23 16:00:59.205315
524	63	CN_PXI7MA5MW	\N	China 50GB 180Days	50	180	28	China 50GB 180Days	t	56	2025-04-23 16:00:59.205322
525	63	CN_P0R7HML2W	\N	China 3GB 30Days	3	30	1.8	China 3GB 30Days	t	3.6	2025-04-23 16:00:59.205328
526	63	CN_PZ60GWHNI	\N	China 500MB/Day	0.49	1	0.5		t	1	2025-04-23 16:00:59.205334
527	63	CN_P92TALXP8	\N	China 1GB/Day	1	1	0.65		t	1.3	2025-04-23 16:00:59.20534
539	64	ID_JC056	\N	Indonesia 1GB 7Days	1	7	0.7	Indonesia 1GB 7Days	t	1.4	2025-04-23 16:01:14.755828
540	64	ID_JC057	\N	Indonesia 3GB 15Days	3	15	1.7	Indonesia 3GB 15Days	t	3.4	2025-04-23 16:01:14.755852
541	64	ID_JC058	\N	Indonesia 5GB 30Days	5	30	2.7	Indonesia 5GB 30Days	t	5.4	2025-04-23 16:01:14.755859
542	64	ID_JC059	\N	Indonesia 10GB 30Days	10	30	4.7	Indonesia 10GB 30Days	t	9.4	2025-04-23 16:01:14.755866
543	64	ID_JC143	\N	Indonesia 20GB 30Days	20	30	8.2	Indonesia 20GB 30Days	t	16.4	2025-04-23 16:01:14.755872
544	64	ID_PXCJQ9KNR	\N	Indonesia 500MB/Day	0.49	1	0.5	Indonesia 500MB/Day	t	1	2025-04-23 16:01:14.755879
545	64	ID_PGBV9EXGK	\N	Indonesia 1GB/Day	1	1	0.9	Indonesia 1GB/Day	t	1.8	2025-04-23 16:01:14.755885
546	64	ID_P3H6TP1TU	\N	Indonesia 3GB 30Days	3	30	1.8	Indonesia 3GB 30Days	t	3.6	2025-04-23 16:01:14.755891
547	64	ID_P3RA09KRL	\N	Indonesia 2GB/Day	2	1	1.6	Indonesia 2GB/Day	t	3.2	2025-04-23 16:01:14.755897
548	64	ID_PWV1DH08R	\N	Indonesia 3GB/Day	3	1	2.4	Indonesia 3GB/Day	t	4.8	2025-04-23 16:01:14.755915
549	64	ID_P2KEH0D5E	\N	Indonesia 10GB/Day	10	1	8	Indonesia 10GB/Day	t	16	2025-04-23 16:01:14.755921
550	64	ID_P402OGJG8	\N	Indonesia 100MB 7Days	0.1	7	0.13		t	0.26	2025-04-23 16:01:14.755941
551	64	ID_PRG960RGE	\N	Indonesia 1GB 7Days (nonhkip)	1	7	1.3	Indonesia 1GB 7Days (nonhkip)	t	2.6	2025-04-23 16:01:14.755947
552	64	ID_P0BS87WNL	\N	Indonesia 3GB 15Days (nonhkip)	3	15	3	Indonesia 3GB 15Days (nonhkip)	t	6	2025-04-23 16:01:14.755953
553	64	ID_P0YGLXY82	\N	Indonesia 5GB 30Days (nonhkip)	5	30	5	Indonesia 5GB 30Days (nonhkip)	t	10	2025-04-23 16:01:14.755959
554	64	ID_PSGW82WV9	\N	Indonesia 10GB 30Days (nonhkip)	10	30	8.65	Indonesia 10GB 30Days (nonhkip)	t	17.3	2025-04-23 16:01:14.755965
555	64	ID_PNRFJ542B	\N	Indonesia 20GB 30Days (nonhkip)	20	30	12	Indonesia 20GB 30Days (nonhkip)	t	24	2025-04-23 16:01:14.755971
559	65	IN_JC060	\N	India 1GB 7Days	1	7	2.9	India 1GB 7Days	t	5.8	2025-04-23 16:01:29.434345
560	65	IN_JC061	\N	India 3GB 15Days	3	15	7.2	India 3GB 15Days	t	14.4	2025-04-23 16:01:29.43436
561	65	IN_JC062	\N	India 5GB 30Days	5	30	11	India 5GB 30Days	t	22	2025-04-23 16:01:29.434366
562	65	IN_JC140	\N	India 10GB 30Days	10	30	19	India 10GB 30Days	t	38	2025-04-23 16:01:29.434371
563	65	IN_JC141	\N	India 20GB 30Days	20	30	32	India 20GB 30Days	t	64	2025-04-23 16:01:29.434376
564	65	IN_PGS3HB984	\N	India 500MB/Day	0.49	1	1.2	India 500MB/Day	t	2.4	2025-04-23 16:01:29.434382
565	65	IN_PYGUMRHX1	\N	India 1GB/Day	1	1	2.4	India 1GB/Day	t	4.8	2025-04-23 16:01:29.434387
566	65	IN_PKS9FL7X0	\N	India 2GB/Day	2	1	4	India 2GB/Day	t	8	2025-04-23 16:01:29.434392
567	65	IN_PNJCUC29S	\N	India 100MB 7Days	0.1	7	0.28		t	0.56	2025-04-23 16:01:29.434397
568	66	JP_JC063	\N	Japan 1GB 7Days	1	7	0.7	Japan 1GB 7Days	t	1.4	2025-04-23 16:01:45.484463
569	66	JP_JC064	\N	Japan 3GB 15Days	3	15	1.7	Japan 3GB 15Days	t	3.4	2025-04-23 16:01:45.484481
570	66	JP_JC065	\N	Japan 5GB 30Days	5	30	2.7	Japan 5GB 30Days	t	5.4	2025-04-23 16:01:45.484487
590	67	KR_JC072	\N	South Korea 1GB 7Days	1	7	0.7	South Korea 1GB 7Days	t	1.4	2025-04-23 16:02:01.520222
591	67	KR_JC073	\N	South Korea 3GB 15Days	3	15	1.7	South Korea 3GB 15Days	t	3.4	2025-04-23 16:02:01.520239
592	67	KR_JC074	\N	South Korea 5GB 30Days	5	30	2.7	South Korea 5GB 30Days	t	5.4	2025-04-23 16:02:01.520245
593	67	KR_JC075	\N	South Korea 10GB 30Days	10	30	4.7	South Korea 10GB 30Days	t	9.4	2025-04-23 16:02:01.520251
594	67	KR_JC147	\N	South Korea 20GB 30Days	20	30	8.2	South Korea 20GB 30Days	t	16.4	2025-04-23 16:02:01.520256
595	67	KR_PR7PDLXPX	\N	South Korea 1GB/Day	1	1	0.8	South Korea 1GB/Day	t	1.6	2025-04-23 16:02:01.520262
596	67	KR_P21XNC9CT	\N	South Korea 500MB/Day	0.49	1	0.4	South Korea 500MB/Day	t	0.8	2025-04-23 16:02:01.520268
597	67	KR_PD97RF0HS	\N	South Korea 2GB/Day	2	1	1.6	South Korea 2GB/Day	t	3.2	2025-04-23 16:02:01.520273
598	67	KR_P8Z0SR4YM	\N	South Korea 3GB/Day	3	1	2.4	South Korea 3GB/Day	t	4.8	2025-04-23 16:02:01.520279
599	67	KR_PX9TSB16T	\N	South Korea 5GB/Day	5	1	3.9		t	7.8	2025-04-23 16:02:01.520289
600	67	KR_P2XI9YHJG	\N	South Korea 10GB/Day	10	1	8		t	16	2025-04-23 16:02:01.520305
601	67	KR_PKLF9M3N7	\N	South Korea 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 16:02:01.520311
602	67	KR_PU60C7NHY	\N	South Korea 1GB 7Days (nonhkip)	1	7	1.05	South Korea 1GB 7Days (nonhkip)	t	2.1	2025-04-23 16:02:01.520317
603	67	KR_P2FQ0VL1B	\N	South Korea 3GB 15Days (nonhkip)	3	15	2.6	South Korea 3GB 15Days (nonhkip)	t	5.2	2025-04-23 16:02:01.520322
604	67	KR_PQ708AANE	\N	South Korea 5GB 30Days (nonhkip)	5	30	4.25	South Korea 5GB 30Days (nonhkip)	t	8.5	2025-04-23 16:02:01.520328
611	68	YE_CKH285	\N	Yemen 1GB 7Days	1	7	11.2	Yemen 1GB 7Days	t	22.4	2025-04-23 16:02:11.409344
612	68	YE_CKH286	\N	Yemen 3GB 15Days	3	15	27	Yemen 3GB 15Days	t	54	2025-04-23 16:02:11.409368
613	68	YE_CKH287	\N	Yemen 5GB 30Days	5	30	41	Yemen 5GB 30Days	t	82	2025-04-23 16:02:11.409375
614	69	AR_CKH293	\N	Argentina 1GB 7Days	1	7	3.6	Argentina 1GB 7Days	t	7.2	2025-04-23 16:02:26.112006
615	69	AR_CKH294	\N	Argentina 3GB 15Days	3	15	8.9	Argentina 3GB 15Days	t	17.8	2025-04-23 16:02:26.112025
616	69	AR_CKH858	\N	Argentina 20GB 30Days	20	30	40	Argentina 20GB 30Days	t	80	2025-04-23 16:02:26.112032
617	69	AR_P0VDPD9F2	\N	Argentina 1GB/Day	1	1	3.4		t	6.8	2025-04-23 16:02:26.112038
618	69	AR_PHDE7ZP42	\N	Argentina 100MB 7Days	0.1	7	0.46		t	0.92	2025-04-23 16:02:26.112044
619	70	BO_CKH297	\N	Bolivia 1GB 7Days	1	7	5.7	Bolivia 1GB 7Days	t	11.4	2025-04-23 16:02:41.718314
620	70	BO_CKH298	\N	Bolivia 3GB 15Days	3	15	16.8	Bolivia 3GB 15Days	t	33.6	2025-04-23 16:02:41.718333
621	70	BO_CKH831	\N	Bolivia 20GB 30Days	20	30	99	Bolivia 20GB 30Days	t	198	2025-04-23 16:02:41.71834
622	70	BO_PWB2NZA39	\N	Bolivia 100MB 7Days	0.1	7	0.63		t	1.26	2025-04-23 16:02:41.718346
623	71	BR_CKH301	\N	Brazil 1GB 7Days	1	7	2.3	Brazil 1GB 7Days	t	4.6	2025-04-23 16:02:57.585554
624	71	BR_CKH317	\N	Brazil 3GB 15Days	3	15	5.7	Brazil 3GB 15Days	t	11.4	2025-04-23 16:02:57.585572
625	71	BR_CKH860	\N	Brazil 20GB 30Days	20	30	25	Brazil 20GB 30Days	t	50	2025-04-23 16:02:57.585579
626	71	BR_PUQ2TP57A	\N	Brazil 5GB/Day	5	1	8.7	Brazil 5GB/Day	t	17.4	2025-04-23 16:02:57.585586
627	71	BR_PT5G8VBW7	\N	Brazil 1GB/Day	1	1	2.2	Brazil 1GB/Day	t	4.4	2025-04-23 16:02:57.585592
628	71	BR_P74QTP3AR	\N	Brazil 500MB/Day	0.49	1	1.1	Brazil 500MB/Day	t	2.2	2025-04-23 16:02:57.585599
629	71	BR_P2QDY5WD1	\N	Brazil 10GB 30Days Single Use	10	30	22.8	Brazil 10GB 30Days Single Use	t	45.6	2025-04-23 16:02:57.585605
630	71	BR_PVYS147BB	\N	Brazil 5GB 30Days Single Use	5	30	12.5	Brazil 5GB 30Days Single Use	t	25	2025-04-23 16:02:57.585612
631	71	BR_P4J9BRTA3	\N	Brazil 3GB 30Days Single Use	3	30	7.5	Brazil 3GB 30Days Single Use	t	15	2025-04-23 16:02:57.585618
632	71	BR_P7QUD52XF	\N	Brazil 1GB 7Days Single Use	1	7	2.8	Brazil 1GB 7Days Single Use	t	5.6	2025-04-23 16:02:57.585629
633	71	BR_PTN42GL18	\N	Brazil 100MB 7Days	0.1	7	0.24		t	0.48	2025-04-23 16:02:57.585636
640	74	CR_CKH304	\N	Costa Rica 1GB 7Days	1	7	4.6	Costa Rica 1GB 7Days	t	9.2	2025-04-23 16:03:44.413235
641	74	CR_CKH320	\N	Costa Rica 3GB 15Days	3	15	11.2	Costa Rica 3GB 15Days	t	22.4	2025-04-23 16:03:44.413257
642	75	EC_CKH305	\N	Ecuador 1GB 7Days	1	7	4.6	Ecuador 1GB 7Days	t	9.2	2025-04-23 16:03:59.864651
637	73	CO_CKH303	\N	Colombia 1GB 7Days	1	7	5.7	Colombia 1GB 7Days	t	11.4	2025-04-23 16:03:29.167853
638	73	CO_CKH319	\N	Colombia 3GB 15Days	3	15	14.4	Colombia 3GB 15Days	t	28.8	2025-04-23 16:03:29.167877
639	73	CO_PPHO2UDYS	\N	Colombia 100MB 7Days	0.1	7	0.56		t	1.12	2025-04-23 16:03:29.167884
643	75	EC_CKH321	\N	Ecuador 3GB 15Days	3	15	11.2	Ecuador 3GB 15Days	t	22.4	2025-04-23 16:03:59.864669
644	76	SV_CKH306	\N	El Salvador 1GB 7Days	1	7	5.7	El Salvador 1GB 7Days	t	11.4	2025-04-23 16:04:14.737967
645	76	SV_CKH322	\N	El Salvador 3GB 15Days	3	15	14.1	El Salvador 3GB 15Days	t	28.2	2025-04-23 16:04:14.73799
647	77	GT_CKH309	\N	Guatemala 1GB 7Days	1	7	5.7	Guatemala 1GB 7Days	t	11.4	2025-04-23 16:04:29.841629
648	77	GT_CKH325	\N	Guatemala 3GB 15Days	3	15	14.1	Guatemala 3GB 15Days	t	28.2	2025-04-23 16:04:29.84165
650	78	HN_CKH310	\N	Honduras 1GB 7Days	1	7	4.6	Honduras 1GB 7Days	t	9.2	2025-04-23 16:04:44.590832
651	78	HN_CKH326	\N	Honduras 3GB 15Days	3	15	11.2	Honduras 3GB 15Days	t	22.4	2025-04-23 16:04:44.590868
652	78	HN_P3WDTMWGS	\N	Honduras 100MB 7Days	0.1	7	0.57		t	1.14	2025-04-23 16:04:44.590876
653	79	NI_CKH311	\N	Nicaragua 1GB 7Days	1	7	4.6	Nicaragua 1GB 7Days	t	9.2	2025-04-23 16:04:59.987468
654	79	NI_CKH327	\N	Nicaragua 3GB 15Days	3	15	11.2	Nicaragua 3GB 15Days	t	22.4	2025-04-23 16:04:59.987488
656	80	PA_CKH312	\N	Panama 1GB 7Days	1	7	4.6	Panama 1GB 7Days	t	9.2	2025-04-23 16:05:15.334248
657	80	PA_CKH328	\N	Panama 3GB 15Days	3	15	11.2	Panama 3GB 15Days	t	22.4	2025-04-23 16:05:15.334273
658	80	PA_P76PJ8WFO	\N	Panama 100MB 7Days	0.1	7	0.57		t	1.14	2025-04-23 16:05:15.33428
659	81	PY_CKH313	\N	Paraguay 1GB 7Days	1	7	4.6	Paraguay 1GB 7Days	t	9.2	2025-04-23 16:05:31.128093
660	81	PY_CKH329	\N	Paraguay 3GB 15Days	3	15	11.2	Paraguay 3GB 15Days	t	22.4	2025-04-23 16:05:31.128115
662	82	PE_CKH314	\N	Peru 1GB 7Days	1	7	5.7	Peru 1GB 7Days	t	11.4	2025-04-23 16:05:46.866425
663	82	PE_CKH330	\N	Peru 3GB 15Days	3	15	14.1	Peru 3GB 15Days	t	28.2	2025-04-23 16:05:46.866445
664	82	PE_CKH862	\N	Peru 20GB 30Days	20	30	98	Peru 20GB 30Days	t	196	2025-04-23 16:05:46.866451
666	83	PR_CKH315	\N	Puerto Rico 1GB 7Days	1	7	2.9	Puerto Rico 1GB 7Days	t	5.8	2025-04-23 16:06:02.433463
667	83	PR_CKH331	\N	Puerto Rico 3GB 15Days	3	15	7.2	Puerto Rico 3GB 15Days	t	14.4	2025-04-23 16:06:02.43349
668	83	PR_CKH347	\N	Puerto Rico 5GB 30Days	5	30	11	Puerto Rico 5GB 30Days	t	22	2025-04-23 16:06:02.433496
670	84	UY_CKH316	\N	Uruguay 1GB 7Days	1	7	4.6	Uruguay 1GB 7Days	t	9.2	2025-04-23 16:06:18.017609
671	84	UY_CKH332	\N	Uruguay 3GB 15Days	3	15	11.2	Uruguay 3GB 15Days	t	22.4	2025-04-23 16:06:18.017626
672	84	UY_PDPRP70HM	\N	Uruguay 100MB 7Days	0.1	7	0.63		t	1.26	2025-04-23 16:06:18.017633
673	85	RE_CKH365	\N	Reunion 1GB 7Days	1	7	2.9	Reunion 1GB 7Days	t	5.8	2025-04-23 16:06:28.543705
674	85	RE_CKH394	\N	Reunion 3GB 15Days	3	15	7.2	Reunion 3GB 15Days	t	14.4	2025-04-23 16:06:28.543724
675	85	RE_CKH423	\N	Reunion 5GB 30Days	5	30	11	Reunion 5GB 30Days	t	22	2025-04-23 16:06:28.543734
681	86	MG_CKH366	\N	Madagascar 1GB 7Days	1	7	4.6	Madagascar 1GB 7Days	t	9.2	2025-04-23 16:06:43.837672
682	86	MG_CKH395	\N	Madagascar 3GB 15Days	3	15	11.2	Madagascar 3GB 15Days	t	22.4	2025-04-23 16:06:43.837696
683	87	MW_CKH367	\N	Malawi 1GB 7Days	1	7	5.7	Malawi 1GB 7Days	t	11.4	2025-04-23 16:06:58.819251
684	87	MW_CKH396	\N	Malawi 3GB 15Days	3	15	14.1	Malawi 3GB 15Days	t	28.2	2025-04-23 16:06:58.81927
685	87	MW_CKH425	\N	Malawi 5GB 30Days	5	30	21	Malawi 5GB 30Days	t	42	2025-04-23 16:06:58.819277
686	88	BW_CKH368	\N	Botswana 1GB 7Days	1	7	7.1	Botswana 1GB 7Days	t	14.2	2025-04-23 16:07:13.955018
687	88	BW_CKH397	\N	Botswana 3GB 15Days	3	15	17.6	Botswana 3GB 15Days	t	35.2	2025-04-23 16:07:13.955049
688	89	CF_CKH370	\N	Central African Republic 1GB 7Days	1	7	7.1	Central African Republic 1GB 7Days	t	14.2	2025-04-23 16:07:24.217763
689	89	CF_CKH399	\N	Central African Republic 3GB 15Days	3	15	17.6	Central African Republic 3GB 15Days	t	35.2	2025-04-23 16:07:24.217797
690	89	CF_CKH428	\N	Central African Republic 5GB 30Days	5	30	26	Central African Republic 5GB 30Days	t	52	2025-04-23 16:07:24.217811
691	90	TD_CKH371	\N	Chad 1GB 7Days	1	7	5.7	Chad 1GB 7Days	t	11.4	2025-04-23 16:07:38.921816
692	90	TD_CKH400	\N	Chad 3GB 15Days	3	15	14.1	Chad 3GB 15Days	t	28.2	2025-04-23 16:07:38.921833
693	90	TD_CKH429	\N	Chad 5GB 30Days	5	30	21	Chad 5GB 30Days	t	42	2025-04-23 16:07:38.92184
694	91	CG_MB023	\N	Congo 1GB 7Days	1	7	5.7	Congo 1GB 7Days	t	11.4	2025-04-23 16:07:53.553655
695	91	CG_MB028	\N	Congo 3GB 15Days	3	15	14.1	Congo 3GB 15Days	t	28.2	2025-04-23 16:07:53.553696
696	91	CG_MB033	\N	Congo 5GB 30Days	5	30	21	Congo 5GB 30Days	t	42	2025-04-23 16:07:53.553703
697	92	CI_CKH374	\N	Cote d'Ivoire 1GB 7Days	1	7	7.1	Cote d'Ivoire 1GB 7Days	t	14.2	2025-04-23 16:08:08.42945
698	92	CI_CKH403	\N	Cote d'Ivoire 3GB 15Days	3	15	17.6	Cote d'Ivoire 3GB 15Days	t	35.2	2025-04-23 16:08:08.429486
700	93	EG_MB024	\N	Egypt 1GB 7Days	1	7	1.8	Egypt 1GB 7Days	t	3.6	2025-04-23 16:08:23.316187
710	94	GA_CKH376	\N	Gabon 1GB 7Days	1	7	4.6	Gabon 1GB 7Days	t	9.2	2025-04-23 16:08:38.585124
711	94	GA_CKH405	\N	Gabon 3GB 15Days	3	15	11.2	Gabon 3GB 15Days	t	22.4	2025-04-23 16:08:38.585143
712	95	KE_CKH379	\N	Kenya 1GB 7Days	1	7	5.7	Kenya 1GB 7Days	t	11.4	2025-04-23 16:08:53.936577
713	95	KE_CKH408	\N	Kenya 3GB 15Days	3	15	14.1	Kenya 3GB 15Days	t	28.2	2025-04-23 16:08:53.936604
714	95	KE_CKH437	\N	Kenya 5GB 30Days	5	30	21	Kenya 5GB 30Days	t	42	2025-04-23 16:08:53.936611
715	95	KE_P9A3DBLOA	\N	Kenya 100MB 7Days	0.1	7	0.7		t	1.4	2025-04-23 16:08:53.936617
716	96	LR_CKH380	\N	Liberia 1GB 7Days	1	7	5.7	Liberia 1GB 7Days	t	11.4	2025-04-23 16:09:09.33172
717	96	LR_CKH409	\N	Liberia 3GB 15Days	3	15	14.1	Liberia 3GB 15Days	t	28.2	2025-04-23 16:09:09.331741
718	96	LR_CKH438	\N	Liberia 5GB 30Days	5	30	21	Liberia 5GB 30Days	t	42	2025-04-23 16:09:09.331748
719	97	ML_CKH381	\N	Mali 1GB 7Days	1	7	7.1	Mali 1GB 7Days	t	14.2	2025-04-23 16:09:24.383191
720	97	ML_CKH410	\N	Mali 3GB 15Days	3	15	17.6	Mali 3GB 15Days	t	35.2	2025-04-23 16:09:24.383218
721	98	MA_CKH382	\N	Morocco 1GB 7Days	1	7	1.5	Morocco 1GB 7Days	t	3	2025-04-23 16:09:39.248072
722	98	MA_CKH411	\N	Morocco 3GB 15Days	3	15	3.7	Morocco 3GB 15Days	t	7.4	2025-04-23 16:09:39.248131
723	98	MA_CKH829	\N	Morocco 20GB 30Days	20	30	16.8	Morocco 20GB 30Days	t	33.6	2025-04-23 16:09:39.248153
724	98	MA_PPHIWSELT	\N	Morocco 3GB 30Days	3	30	3.8		t	7.6	2025-04-23 16:09:39.248162
725	98	MA_P7BXAR31R	\N	Morocco 5GB 30Days	5	30	5.7		t	11.4	2025-04-23 16:09:39.248169
726	98	MA_PO5WKZOPV	\N	Morocco 10GB 30Days	10	30	9.9		t	19.8	2025-04-23 16:09:39.248176
727	98	MA_PKUWF7BJC	\N	Morocco 1GB/Day	1	1	1.4		t	2.8	2025-04-23 16:09:39.248182
731	99	NE_CKH383	\N	Niger 1GB 7Days	1	7	7.1	Niger 1GB 7Days	t	14.2	2025-04-23 16:09:54.404455
732	99	NE_CKH412	\N	Niger 3GB 15Days	3	15	17.6	Niger 3GB 15Days	t	35.2	2025-04-23 16:09:54.404476
733	99	NE_P8Y35DWA0	\N	Niger 100MB 7Days	0.1	7	0.86		t	1.72	2025-04-23 16:09:54.404483
734	100	NG_CKH384	\N	Nigeria 1GB 7Days	1	7	4.6	Nigeria 1GB 7Days	t	9.2	2025-04-23 16:10:09.790799
735	100	NG_CKH413	\N	Nigeria 3GB 15Days	3	15	11.2	Nigeria 3GB 15Days	t	22.4	2025-04-23 16:10:09.790816
736	100	NG_P0Q24KI1C	\N	Nigeria 100MB 7Days	0.1	7	0.47		t	0.94	2025-04-23 16:10:09.790821
737	101	SN_CKH385	\N	Senegal 1GB 7Days	1	7	7.1	Senegal 1GB 7Days	t	14.2	2025-04-23 16:10:25.519761
738	101	SN_CKH414	\N	Senegal 3GB 15Days	3	15	17.6	Senegal 3GB 15Days	t	35.2	2025-04-23 16:10:25.519777
739	101	SN_CKH443	\N	Senegal 5GB 30Days	5	30	26	Senegal 5GB 30Days	t	52	2025-04-23 16:10:25.519784
740	101	SN_PBBWJ5ZI6	\N	Senegal 100MB 7Days	0.1	7	0.86		t	1.72	2025-04-23 16:10:25.519791
741	102	SC_CKH386	\N	Seychelles 1GB 7Days	1	7	4.6	Seychelles 1GB 7Days	t	9.2	2025-04-23 16:10:40.851474
742	102	SC_CKH415	\N	Seychelles 3GB 15Days	3	15	11.2	Seychelles 3GB 15Days	t	22.4	2025-04-23 16:10:40.851495
743	102	SC_CKH444	\N	Seychelles 5GB 30Days	5	30	17.1	Seychelles 5GB 30Days	t	34.2	2025-04-23 16:10:40.851502
744	103	ZA_MB026	\N	South Africa 1GB 7Days	1	7	3.6	South Africa 1GB 7Days	t	7.2	2025-04-23 16:10:56.553512
745	103	ZA_MB036	\N	South Africa 5GB 30Days	5	30	13.6	South Africa 5GB 30Days	t	27.2	2025-04-23 16:10:56.553529
746	103	ZA_MB041	\N	South Africa 10GB 30Days	10	30	23	South Africa 10GB 30Days	t	46	2025-04-23 16:10:56.553535
747	103	ZA_MB065	\N	South Africa 3GB 30Days	3	30	9.1	South Africa 3GB 30Days	t	18.2	2025-04-23 16:10:56.553542
748	103	ZA_PBSI82U47	\N	South Africa 1GB/Day	1	1	3.4		t	6.8	2025-04-23 16:10:56.553548
749	103	ZA_PJ91RFXJL	\N	South Africa 100MB 7Days	0.1	7	0.68		t	1.36	2025-04-23 16:10:56.553554
750	104	SD_CKH388	\N	Sudan 1GB 7Days	1	7	11.2	Sudan 1GB 7Days	t	22.4	2025-04-23 16:11:07.084972
751	104	SD_CKH417	\N	Sudan 3GB 15Days	3	15	27	Sudan 3GB 15Days	t	54	2025-04-23 16:11:07.084999
752	104	SD_CKH446	\N	Sudan 5GB 30Days	5	30	41	Sudan 5GB 30Days	t	82	2025-04-23 16:11:07.085008
753	105	SZ_CKH389	\N	Swaziland 1GB 7Days	1	7	7.1	Swaziland 1GB 7Days	t	14.2	2025-04-23 16:11:22.144104
754	105	SZ_CKH418	\N	Swaziland 3GB 15Days	3	15	17.6	Swaziland 3GB 15Days	t	35.2	2025-04-23 16:11:22.144124
755	106	TZ_MB027	\N	Tanzania 1GB 7Days	1	7	3.6	Tanzania 1GB 7Days	t	7.2	2025-04-23 16:11:37.617225
756	106	TZ_MB032	\N	Tanzania 3GB 15Days	3	15	8.9	Tanzania 3GB 15Days	t	17.8	2025-04-23 16:11:37.617247
757	106	TZ_P1W5NQVN1	\N	Tanzania 100MB 7Days	0.1	7	0.68		t	1.36	2025-04-23 16:11:37.617254
758	107	TN_KR001	\N	Tunisia 1GB 7Days	1	7	1.8	Tunisia 1GB 7Days	t	3.6	2025-04-23 16:11:53.193258
759	107	TN_KR003	\N	Tunisia 5GB 30Days	5	30	7	Tunisia 5GB 30Days	t	14	2025-04-23 16:11:53.193281
760	107	TN_KR004	\N	Tunisia 10GB 30Days	10	30	12.2	Tunisia 10GB 30Days	t	24.4	2025-04-23 16:11:53.193287
761	107	TN_PXX3PDGRD	\N	Tunisia 3GB 30Days	3	30	4.7	Tunisia 3GB 30Days	t	9.4	2025-04-23 16:11:53.193293
764	108	UG_CKH392	\N	Uganda 1GB 7Days	1	7	5.7	Uganda 1GB 7Days	t	11.4	2025-04-23 16:12:08.124052
765	108	UG_CKH421	\N	Uganda 3GB 15Days	3	15	14.1	Uganda 3GB 15Days	t	28.2	2025-04-23 16:12:08.124069
769	110	KH_JC109	\N	Cambodia 1GB 7Days	1	7	2.3	Cambodia 1GB 7Days	t	4.6	2025-04-23 16:12:36.410914
770	110	KH_JC115	\N	Cambodia 3GB 15Days	3	15	5.7	Cambodia 3GB 15Days	t	11.4	2025-04-23 16:12:36.410937
774	111	DZ_CKH515	\N	Algeria 1GB 7Days	1	7	1.1	Algeria 1GB 7Days	t	2.2	2025-04-23 16:12:45.852199
775	111	DZ_CKH551	\N	Algeria 3GB 15Days	3	15	2.8	Algeria 3GB 15Days	t	5.6	2025-04-23 16:12:45.852231
776	111	DZ_CKH552	\N	Algeria 5GB 30Days	5	30	4.4	Algeria 5GB 30Days	t	8.8	2025-04-23 16:12:45.852241
777	111	DZ_CKH809	\N	Algeria 10GB 30Days	10	30	7.6	Algeria 10GB 30Days	t	15.2	2025-04-23 16:12:45.85225
779	111	DZ_PWI9OQIY7	\N	Algeria 3GB 30Days	3	30	3		t	6	2025-04-23 16:12:45.852267
781	112	BD_JC110	\N	Bangladesh 1GB 7Days	1	7	2.9	Bangladesh 1GB 7Days	t	5.8	2025-04-23 16:12:56.447156
782	112	BD_JC112	\N	Bangladesh 3GB 15Days	3	15	7.2	Bangladesh 3GB 15Days	t	14.4	2025-04-23 16:12:56.447191
783	112	BD_JC113	\N	Bangladesh 5GB 30Days	5	30	11	Bangladesh 5GB 30Days	t	22	2025-04-23 16:12:56.447201
784	112	BD_JC156	\N	Bangladesh 20GB 30Days	20	30	32	Bangladesh 20GB 30Days	t	64	2025-04-23 16:12:56.447209
785	113	CA_CKH516	\N	Canada 1GB 7Days	1	7	2.3	Canada 1GB 7Days	t	4.6	2025-04-23 16:13:11.825126
786	113	CA_CKH578	\N	Canada 3GB 15Days	3	15	5.7	Canada 3GB 15Days	t	11.4	2025-04-23 16:13:11.825148
787	113	CA_CKH579	\N	Canada 5GB 30Days	5	30	8.8	Canada 5GB 30Days	t	17.6	2025-04-23 16:13:11.825155
788	113	CA_CKH778	\N	Canada 10GB 30Days	10	30	15.2	Canada 10GB 30Days	t	30.4	2025-04-23 16:13:11.825162
789	113	CA_CKH779	\N	Canada 20GB 30Days	20	30	25	Canada 20GB 30Days	t	50	2025-04-23 16:13:11.825168
801	114	MK_CKH517	\N	North Macedonia of  1GB 7Days	1	7	2.3	North Macedonia of  1GB 7Days	t	4.6	2025-04-23 16:13:28.436517
802	114	MK_CKH637	\N	North Macedonia of  3GB 15Days	3	15	5.7	North Macedonia of  3GB 15Days	t	11.4	2025-04-23 16:13:28.436535
803	114	MK_CKH638	\N	North Macedonia of  5GB 30Days	5	30	8.8	North Macedonia of  5GB 30Days	t	17.6	2025-04-23 16:13:28.436541
804	115	MX_CKH518	\N	Mexico 1GB 7Days	1	7	2.3	Mexico 1GB 7Days	t	4.6	2025-04-23 16:13:43.143166
805	115	MX_CKH644	\N	Mexico 3GB 15Days	3	15	5.7	Mexico 3GB 15Days	t	11.4	2025-04-23 16:13:43.143183
806	115	MX_CKH645	\N	Mexico 5GB 30Days	5	30	8.8	Mexico 5GB 30Days	t	17.6	2025-04-23 16:13:43.143189
807	115	MX_CKH798	\N	Mexico 20GB 30Days	20	30	25	Mexico 20GB 30Days	t	50	2025-04-23 16:13:43.143196
808	115	MX_P8DKZK30Q	\N	Mexico 3GB 30Days	3	30	5.9	Mexico 3GB 30Days	t	11.8	2025-04-23 16:13:43.143202
809	115	MX_P84BJ7UTL	\N	Mexico 10GB 30Days	10	30	15.2	Mexico 10GB 30Days	t	30.4	2025-04-23 16:13:43.143208
810	115	MX_PF4COP483	\N	Mexico 100MB 7Days	0.1	7	0.24		t	0.48	2025-04-23 16:13:43.143219
811	116	MZ_MB043	\N	Mozambique 1GB 7Days	1	7	5.7	Mozambique 1GB 7Days	t	11.4	2025-04-23 16:13:46.676969
812	116	MZ_MB047	\N	Mozambique 3GB 15Days	3	15	14.1	Mozambique 3GB 15Days	t	28.2	2025-04-23 16:13:46.677008
813	116	MZ_MB055	\N	Mozambique 20GB 30Days	20	30	63	Mozambique 20GB 30Days	t	126	2025-04-23 16:13:46.677025
814	117	PK_JC111	\N	Pakistan 1GB 7Days	1	7	1.8	Pakistan 1GB 7Days	t	3.6	2025-04-23 16:14:02.29359
815	117	PK_JC129	\N	Pakistan 3GB 15Days	3	15	4.6	Pakistan 3GB 15Days	t	9.2	2025-04-23 16:14:02.293621
816	117	PK_JC130	\N	Pakistan 5GB 30Days	5	30	7	Pakistan 5GB 30Days	t	14	2025-04-23 16:14:02.293628
817	117	PK_JC152	\N	Pakistan 10GB 30Days	10	30	12.2	Pakistan 10GB 30Days	t	24.4	2025-04-23 16:14:02.293642
818	117	PK_JC153	\N	Pakistan 20GB 30Days	20	30	20	Pakistan 20GB 30Days	t	40	2025-04-23 16:14:02.293648
819	117	PK_P70ZZFLRP	\N	Pakistan 3GB 30Days	3	30	4.7		t	9.4	2025-04-23 16:14:02.293658
820	117	PK_P96CDAE48	\N	Pakistan 100MB 7Days	0.1	7	0.19		t	0.38	2025-04-23 16:14:02.293664
821	118	BF_CKH521	\N	Burkina Faso 1GB 7Days	1	7	7.1	Burkina Faso 1GB 7Days	t	14.2	2025-04-23 16:14:12.554496
822	118	BF_CKH572	\N	Burkina Faso 3GB 15Days	3	15	17.6	Burkina Faso 3GB 15Days	t	35.2	2025-04-23 16:14:12.554516
823	118	BF_CKH573	\N	Burkina Faso 5GB 30Days	5	30	26	Burkina Faso 5GB 30Days	t	52	2025-04-23 16:14:12.554524
824	119	MD_CKH523	\N	Moldova 1GB 7Days	1	7	1.8	Moldova 1GB 7Days	t	3.6	2025-04-23 16:14:27.433665
825	119	MD_CKH647	\N	Moldova 3GB 15Days	3	15	4.6	Moldova 3GB 15Days	t	9.2	2025-04-23 16:14:27.433689
826	120	MC_CKH524	\N	Monaco 1GB 7Days	1	7	7.1	Monaco 1GB 7Days	t	14.2	2025-04-23 16:14:42.443164
827	120	MC_CKH650	\N	Monaco 3GB 15Days	3	15	17.6	Monaco 3GB 15Days	t	35.2	2025-04-23 16:14:42.443209
828	120	MC_CKH651	\N	Monaco 5GB 30Days	5	30	26	Monaco 5GB 30Days	t	52	2025-04-23 16:14:42.443216
829	121	AL_CKH525	\N	Albania 1GB 7Days	1	7	2.9	Albania 1GB 7Days	t	5.8	2025-04-23 16:14:57.603278
830	121	AL_CKH548	\N	Albania 3GB 15Days	3	15	6	Albania 3GB 15Days	t	12	2025-04-23 16:14:57.603299
839	122	CM_CKH526	\N	Cameroon 1GB 7Days	1	7	7.1	Cameroon 1GB 7Days	t	14.2	2025-04-23 16:15:11.847831
840	122	CM_CKH575	\N	Cameroon 3GB 15Days	3	15	17.6	Cameroon 3GB 15Days	t	35.2	2025-04-23 16:15:11.847856
841	123	UZ_CKH1017	\N	Uzbekistan 1GB 7Days	1	7	1.5	Uzbekistan 1GB 7Days	t	3	2025-04-23 16:15:27.616329
842	123	UZ_CKH1029	\N	Uzbekistan 5GB 30Days	5	30	5.7	Uzbekistan 5GB 30Days	t	11.4	2025-04-23 16:15:27.616362
843	123	UZ_CKH766	\N	Uzbekistan 10GB 30Days	10	30	9.9	Uzbekistan 10GB 30Days	t	19.8	2025-04-23 16:15:27.61637
844	123	UZ_PCHMVSA0P	\N	Uzbekistan 3GB 30Days	3	30	3.8	Uzbekistan 3GB 30Days	t	7.6	2025-04-23 16:15:27.616377
845	123	UZ_P5N4RG08H	\N	Uzbekistan 100MB 7Days	0.1	7	0.15		t	0.3	2025-04-23 16:15:27.616383
846	124	NP_MB003	\N	Nepal 1GB 7Days	1	7	8.9	Nepal 1GB 7Days	t	17.8	2025-04-23 16:15:32.472343
847	124	NP_MB013	\N	Nepal 3GB 15Days	3	15	21	Nepal 3GB 15Days	t	42	2025-04-23 16:15:32.472388
848	125	XK_CKH530	\N	Kosovo 1GB 7Days	1	7	5.7	Kosovo 1GB 7Days	t	11.4	2025-04-23 16:15:46.640478
849	125	XK_CKH625	\N	Kosovo 3GB 15Days	3	15	14.1	Kosovo 3GB 15Days	t	28.2	2025-04-23 16:15:46.640516
850	125	XK_CKH626	\N	Kosovo 5GB 30Days	5	30	21	Kosovo 5GB 30Days	t	42	2025-04-23 16:15:46.640524
851	126	MN_MB004	\N	Mongolia 1GB 7Days	1	7	14	Mongolia 1GB 7Days	t	28	2025-04-23 16:15:51.265563
852	126	MN_MB010	\N	Mongolia 3GB 15Days	3	15	34	Mongolia 3GB 15Days	t	68	2025-04-23 16:15:51.265581
853	127	BA_CKH531	\N	Bosnia and Herzegovina 1GB 7Days	1	7	4.6	Bosnia and Herzegovina 1GB 7Days	t	9.2	2025-04-23 16:16:07.725711
854	127	BA_CKH563	\N	Bosnia and Herzegovina 3GB 15Days	3	15	11.2	Bosnia and Herzegovina 3GB 15Days	t	22.4	2025-04-23 16:16:07.725732
855	128	ME_CKH1023	\N	Montenegro 1GB 7Days	1	7	2.3	Montenegro 1GB 7Days	t	4.6	2025-04-23 16:16:22.480909
856	128	ME_CKH1024	\N	Montenegro 3GB 15Days	3	15	5.7	Montenegro 3GB 15Days	t	11.4	2025-04-23 16:16:22.48093
857	129	KZ_CKH1030	\N	Kazakhstan 1GB 7Days	1	7	1.5	Kazakhstan 1GB 7Days	t	3	2025-04-23 16:16:37.224221
858	129	KZ_CKH1031	\N	Kazakhstan 3GB 15Days	3	15	3.7	Kazakhstan 3GB 15Days	t	7.4	2025-04-23 16:16:37.224237
859	129	KZ_CKH1032	\N	Kazakhstan 5GB 30Days	5	30	5.7	Kazakhstan 5GB 30Days	t	11.4	2025-04-23 16:16:37.224243
860	129	KZ_CKH750	\N	Kazakhstan 10GB 30Days	10	30	9.9	Kazakhstan 10GB 30Days	t	19.8	2025-04-23 16:16:37.224254
863	130	KG_CKH755	\N	Kyrgyzstan 1GB 7Days	1	7	2.3	Kyrgyzstan 1GB 7Days	t	4.6	2025-04-23 16:16:52.427232
864	130	KG_CKH756	\N	Kyrgyzstan 3GB 15Days	3	15	5.9	Kyrgyzstan 3GB 15Days	t	11.8	2025-04-23 16:16:52.427257
865	130	KG_CKH759	\N	Kyrgyzstan 20GB 30Days	20	30	39	Kyrgyzstan 20GB 30Days	t	78	2025-04-23 16:16:52.427264
866	131	DO_JC158	\N	Dominican Republic 1GB 7Days	1	7	5.7	Dominican Republic 1GB 7Days	t	11.4	2025-04-23 16:16:58.45906
867	131	DO_JC159	\N	Dominican Republic 3GB 15Days	3	15	14.1	Dominican Republic 3GB 15Days	t	28.2	2025-04-23 16:16:58.459082
868	131	DO_JC160	\N	Dominican Republic 5GB 30Days	5	30	21	Dominican Republic 5GB 30Days	t	42	2025-04-23 16:16:58.459089
869	131	DO_JC162	\N	Dominican Republic 20GB 30Days	20	30	63	Dominican Republic 20GB 30Days	t	126	2025-04-23 16:16:58.459096
871	132	GP_CKH812	\N	Guadeloupe 1GB 7Days	1	7	2.9	Guadeloupe 1GB 7Days	t	5.8	2025-04-23 16:17:03.176156
872	132	GP_CKH813	\N	Guadeloupe 3GB 15Days	3	15	7.2	Guadeloupe 3GB 15Days	t	14.4	2025-04-23 16:17:03.176189
873	132	GP_CKH816	\N	Guadeloupe 20GB 30Days	20	30	32	Guadeloupe 20GB 30Days	t	64	2025-04-23 16:17:03.176204
874	133	BN_CKH833	\N	Brunei Darussalam 1GB 7Days	1	7	4.6	Brunei Darussalam 1GB 7Days	t	9.2	2025-04-23 16:17:13.523426
875	133	BN_CKH834	\N	Brunei Darussalam 3GB 15Days	3	15	11.2	Brunei Darussalam 3GB 15Days	t	22.4	2025-04-23 16:17:13.523496
876	133	BN_CKH837	\N	Brunei Darussalam 20GB 30Days	20	30	50	Brunei Darussalam 20GB 30Days	t	100	2025-04-23 16:17:13.523504
877	133	BN_PRWWKX908	\N	Brunei Darussalam 500MB/Day	0.49	1	9.3	Brunei Darussalam 500MB/Day	t	18.6	2025-04-23 16:17:13.523512
879	134	BY_EF4MLC10	\N	Belarus 1GB 7Days	1	7	2.1	Belarus 1GB 7Days	t	4.2	2025-04-23 16:17:23.668427
880	134	BY_ALL95F6M	\N	Belarus 3GB 15Days	3	15	6.3	Belarus 3GB 15Days	t	12.6	2025-04-23 16:17:23.668445
881	134	BY_G9EDN4W6	\N	Belarus 5GB 30Days	5	30	10.5	Belarus 5GB 30Days	t	21	2025-04-23 16:17:23.668452
882	135	US_P1HAXMKHP	\N	United States 20GB 90Days	20	90	10.8	United States 20GB 90Days	t	21.6	2025-04-23 16:17:39.297451
883	135	US_P3ICIKSE8	\N	United States 50GB 180Days	50	180	35	United States 50GB 180Days	t	70	2025-04-23 16:17:39.297479
884	135	US_PCRKRUHIL	\N	United States 10GB 30Days	10	30	6.1	United States 10GB 30Days	t	12.2	2025-04-23 16:17:39.297487
885	135	US_PGDINBJBY	\N	United States 3GB 15Days	3	15	2.2	United States 3GB 15Days	t	4.4	2025-04-23 16:17:39.29751
1	1	ES_CKH002	\N	Spain 3GB 30Days	3	30	2.3	Spain 3GB 30Days	t	4.6	2025-04-23 15:45:33.950256
2	1	ES_CKH003	\N	Spain 5GB 30Days	5	30	3.4	Spain 5GB 30Days	t	6.8	2025-04-23 15:45:33.950279
3	1	ES_CKH245	\N	Spain 1GB 7Days	1	7	0.9	Spain 1GB 7Days	t	1.8	2025-04-23 15:45:33.950285
4	1	ES_CKH246	\N	Spain 3GB 15Days	3	15	2.2	Spain 3GB 15Days	t	4.4	2025-04-23 15:45:33.950292
5	1	ES_CKH506	\N	Spain 10GB 30Days	10	30	6.1	Spain 10GB 30Days	t	12.2	2025-04-23 15:45:33.950299
6	1	ES_CKH507	\N	Spain 20GB 30Days	20	30	10.6	Spain 20GB 30Days	t	21.2	2025-04-23 15:45:33.950304
7	1	ES_PSUZGLKSQ	\N	Spain 50GB 180Days	50	180	22	Spain 50GB 180Days	t	44	2025-04-23 15:45:33.95031
8	1	ES_P6WL2RRH5	\N	Spain 500MB/Day	0.49	1	0.45	Spain 500MB/Day	t	0.9	2025-04-23 15:45:33.950315
9	1	ES_PZBY51PX0	\N	Spain 1GB/Day	1	1	0.8	Spain 1GB/Day	t	1.6	2025-04-23 15:45:33.950321
10	1	ES_P1BF5HDU2	\N	Spain 2GB/Day	2	1	1	Spain 2GB/Day	t	2	2025-04-23 15:45:33.950325
19	2	HK_PJHK9ATRD	\N	Hong Kong 2GB/Day	2	1	1.6	Hong Kong 2GB/Day	t	3.2	2025-04-23 15:45:48.021257
20	2	HK_PG9WP0YY6	\N	Hong Kong 10GB/Day	10	1	4.6		t	9.2	2025-04-23 15:45:48.021263
21	2	HK_P6SW3B9NG	\N	Hong Kong (China) 500MB/Day	0.49	1	0.45	Hong Kong (China) 500MB/Day	t	0.9	2025-04-23 15:45:48.021268
22	2	HK_P8TY7BI5M	\N	Hong Kong (China) 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 15:45:48.021273
23	2	HK_PE3UHN6BJ	\N	Hong Kong 3GB/Day	3	1	2.25		t	4.5	2025-04-23 15:45:48.021279
35	3	MO_PYY68S4KT	\N	Macao 20GB 30Days (nonhkip)	20	30	12	Macao 20GB 30Days (nonhkip)	t	24	2025-04-23 15:46:01.735282
36	3	MO_P06DPM5ME	\N	Macao 500MB/Day (nonhkip)	0.49	1	0.65	Macao 500MB/Day (nonhkip)	t	1.3	2025-04-23 15:46:01.735288
37	3	MO_P0EA95AKM	\N	Macao 1GB/Day (nonhkip)	1	1	1.05	Macao 1GB/Day (nonhkip)	t	2.1	2025-04-23 15:46:01.735293
38	3	MO_PMC972NJJ	\N	Macao 2GB/Day (nonhkip)	2	1	2	Macao 2GB/Day (nonhkip)	t	4	2025-04-23 15:46:01.735299
52	4	TH_PH1M5M9DL	\N	Thailand 1GB 7Days (nonhkip)	1	7	1.3	Thailand 1GB 7Days (nonhkip)	t	2.6	2025-04-23 15:46:16.122284
53	4	TH_PV67L3JSU	\N	Thailand 3GB 15Days (nonhkip)	3	15	2.6	Thailand 3GB 15Days (nonhkip)	t	5.2	2025-04-23 15:46:16.12229
54	4	TH_PUX3JWK41	\N	Thailand 5GB 30Days (nonhkip)	5	30	4	Thailand 5GB 30Days (nonhkip)	t	8	2025-04-23 15:46:16.122301
55	4	TH_P4MBRSL75	\N	Thailand 10GB 30Days (nonhkip)	10	30	6.3	Thailand 10GB 30Days (nonhkip)	t	12.6	2025-04-23 15:46:16.122312
56	4	TH_PZXY42KN5	\N	Thailand 20GB 30Days (nonhkip)	20	30	10	Thailand 20GB 30Days (nonhkip)	t	20	2025-04-23 15:46:16.122318
57	4	TH_PZH4CF30G	\N	Thailand 500MB/Day (nonhkip)	0.49	1	0.75	Thailand 500MB/Day (nonhkip)	t	1.5	2025-04-23 15:46:16.122325
59	4	TH_PR73YYZN4	\N	Thailand 2GB/Day (nonhkip)	2	1	2	Thailand 2GB/Day (nonhkip)	t	4	2025-04-23 15:46:16.122337
64	5	NL_CKH235	\N	Netherlands 10GB 30Days	10	30	6.1	Netherlands 10GB 30Days	t	12.2	2025-04-23 15:46:33.264002
65	5	NL_CKH724	\N	Netherlands 20GB 30Days	20	30	10.6	Netherlands 20GB 30Days	t	21.2	2025-04-23 15:46:33.264007
66	5	NL_P6D7MCOBF	\N	Netherlands 50GB 180Days	50	180	30	Netherlands 50GB 180Days	t	60	2025-04-23 15:46:33.264012
70	6	IL_CKH225	\N	Israel 5GB 30Days	5	30	5.7	Israel 5GB 30Days	t	11.4	2025-04-23 15:46:47.625595
71	6	IL_CKH226	\N	Israel 10GB 30Days	10	30	9.9	Israel 10GB 30Days	t	19.8	2025-04-23 15:46:47.625601
72	6	IL_CKH722	\N	Israel 20GB 30Days	20	30	16.8	Israel 20GB 30Days	t	33.6	2025-04-23 15:46:47.625606
73	6	IL_PWCDVUQGM	\N	Israel 50GB 180Days	50	180	37	Israel 50GB 180Days	t	74	2025-04-23 15:46:47.625612
899	135	US_P3YTYXBRV	\N	United States 100MB 7Days	0.1	7	0.11		t	0.22	2025-04-23 16:17:39.297656
900	136	IQ_P6XJ4XAA1	\N	Iraq 500MB/Day	0.49	1	1.1	Iraq 500MB/Day	t	2.2	2025-04-23 16:17:44.268102
901	136	IQ_PS0TRW67Y	\N	Iraq 1GB/Day	1	1	2.2	Iraq 1GB/Day	t	4.4	2025-04-23 16:17:44.268138
902	136	IQ_PQ206NZYN	\N	Iraq 2GB/Day	2	1	4.3	Iraq 2GB/Day	t	8.6	2025-04-23 16:17:44.268152
903	136	IQ_P3YAYU76M	\N	Iraq 3GB/Day	3	1	5.6	Iraq 3GB/Day	t	11.2	2025-04-23 16:17:44.268164
904	137	GU_PNCYQZAZN	\N	Guam 1GB 7Days	1	7	3.6		t	7.2	2025-04-23 16:17:55.126297
905	137	GU_PKEMRQFAC	\N	Guam 3GB 15Days	3	15	8.9		t	17.8	2025-04-23 16:17:55.126319
906	137	GU_PEOWI61PF	\N	Guam 3GB 30Days	3	30	9.1		t	18.2	2025-04-23 16:17:55.126327
907	137	GU_PIN2SHYSA	\N	Guam 5GB 30Days	5	30	13.6		t	27.2	2025-04-23 16:17:55.126334
908	137	GU_PMYQIPASB	\N	Guam 10GB 30Days	10	30	23		t	46	2025-04-23 16:17:55.126341
909	137	GU_P04857JJB	\N	Guam 20GB 30Days	20	30	40		t	80	2025-04-23 16:17:55.126348
910	138	MU_PLHCEBQDV	\N	Mauritius 2GB/Day	2	1	5.4		t	10.8	2025-04-23 16:18:05.895988
911	138	MU_PKXERFUDN	\N	Mauritius 1GB/Day	1	1	4.9		t	9.8	2025-04-23 16:18:05.896013
912	139	JM_PTFBO8IJH	\N	Jamaica 100MB 7Days	0.1	7	0.73		t	1.46	2025-04-23 16:18:10.665029
913	139	JM_P0CM6KM7E	\N	Jamaica 1GB 7Days	1	7	7.1		t	14.2	2025-04-23 16:18:10.665072
914	139	JM_P5KF3LWV4	\N	Jamaica 3GB 15Days	3	15	17.6		t	35.2	2025-04-23 16:18:10.66509
915	139	JM_PTJ9SYG69	\N	Jamaica 3GB 30Days	3	30	17.9		t	35.8	2025-04-23 16:18:10.665103
916	139	JM_PPDAG2ZLG	\N	Jamaica 5GB 30Days	5	30	26		t	52	2025-04-23 16:18:10.665116
917	139	JM_PMB6QS4ZN	\N	Jamaica 10GB 30Days	10	30	50.58		t	101.16	2025-04-23 16:18:10.665129
74	6	IL_P6EUQ8HV5	\N	Israel 500MB/Day	0.49	1	1.85	Israel 500MB/Day	t	3.7	2025-04-23 15:46:47.625619
75	6	IL_P83SJWZ7Z	\N	Israel 1GB/Day	1	1	2.9	Israel 1GB/Day	t	5.8	2025-04-23 15:46:47.625624
76	6	IL_PQSCDP235	\N	Israel 2GB/Day	2	1	5.4	Israel 2GB/Day	t	10.8	2025-04-23 15:46:47.625629
77	6	IL_PYCQ2P3E1	\N	Israel 3GB/Day	3	1	8	Israel 3GB/Day	t	16	2025-04-23 15:46:47.62564
87	7	TR_PF1K57KAZ	\N	Turkey 2GB/Day	2	1	0.8	Turkey 2GB/Day	t	1.6	2025-04-23 15:47:05.004996
88	7	TR_P3V2FT7FJ	\N	Turkey 5GB/Day	5	1	1.8	Turkey 5GB/Day	t	3.6	2025-04-23 15:47:05.005002
89	7	TR_P99PK3JV6	\N	Turkey 500MB 1Day	0.49	1	0.3		t	0.6	2025-04-23 15:47:05.005021
90	7	TR_PL0M7ICXR	\N	Turkey 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 15:47:05.005027
126	13	AE_PQHJ267ZM	\N	United Arab Emirates 10GB 30Days	10	30	14.98	United Arab Emirates 10GB 30Days	t	29.96	2025-04-23 15:48:23.135711
127	13	AE_P6P4JNC5G	\N	United Arab Emirates 1GB/Day	1	1	2	United Arab Emirates 1GB/Day	t	4	2025-04-23 15:48:23.135717
128	13	AE_PQWC3N4R1	\N	United Arab Emirates 500MB/Day	0.49	1	1.2	United Arab Emirates 500MB/Day	t	2.4	2025-04-23 15:48:23.135722
129	13	AE_PRQJ9TH03	\N	United Arab Emirates 2GB/Day	2	1	3	United Arab Emirates 2GB/Day	t	6	2025-04-23 15:48:23.135728
130	13	AE_PVA0GD3V7	\N	United Arab Emirates 5GB/Day	5	1	6.85	United Arab Emirates 5GB/Day	t	13.7	2025-04-23 15:48:23.135734
131	13	AE_PBJCBSZU1	\N	United Arab Emirates 50GB 180Days	50	180	112.55		t	225.1	2025-04-23 15:48:23.135739
132	13	AE_PFI5O971X	\N	United Arab Emirates 100MB 7Days	0.1	7	0.24		t	0.48	2025-04-23 15:48:23.135754
146	16	BH_PU3UL09EV	\N	Bahrain 1GB/Day	1	1	4.5	Bahrain 1GB/Day	t	9	2025-04-23 15:48:53.760274
147	16	BH_PCF04T9CZ	\N	Bahrain 2GB/Day	2	1	8.9	Bahrain 2GB/Day	t	17.8	2025-04-23 15:48:53.760282
148	16	BH_PX05WUEX1	\N	Bahrain 3GB/Day	3	1	11.1	Bahrain 3GB/Day	t	22.2	2025-04-23 15:48:53.760289
154	17	SA_CKH800	\N	Saudi Arabia 20GB 30Days	20	30	32	Saudi Arabia 20GB 30Days	t	64	2025-04-23 15:49:07.472261
161	18	AT_PJG7CZ02I	\N	Austria 50GB 180Days	50	180	22	Austria 50GB 180Days	t	44	2025-04-23 15:49:23.544941
168	19	BE_PJ4UJHAJC	\N	Belgium 50GB 180Days	50	180	22	Belgium 50GB 180Days	t	44	2025-04-23 15:49:39.534656
169	19	BE_PWRT10ZX4	\N	Belgium 1GB/Day	1	1	0.85	Belgium 1GB/Day	t	1.7	2025-04-23 15:49:39.534671
181	21	HR_PQCZMPBQD	\N	Croatia 50GB 180Days	50	180	28	Croatia 50GB 180Days	t	56	2025-04-23 15:50:12.396964
191	23	CZ_CKH164	\N	Czech Republic 3GB 15Days	3	15	2.2	Czech Republic 3GB 15Days	t	4.4	2025-04-23 15:50:44.727205
192	23	CZ_CKH165	\N	Czech Republic 10GB 30Days	10	30	6.1	Czech Republic 10GB 30Days	t	12.2	2025-04-23 15:50:44.72721
193	23	CZ_CKH541	\N	Czech Republic 20GB 30Days	20	30	10.6	Czech Republic 20GB 30Days	t	21.2	2025-04-23 15:50:44.727215
194	23	CZ_PVFLCUSP6	\N	Czech Republic 50GB 180Days	50	180	30	Czech Republic 50GB 180Days	t	60	2025-04-23 15:50:44.72722
199	24	DK_CKH168	\N	Denmark 10GB 30Days	10	30	6.1	Denmark 10GB 30Days	t	12.2	2025-04-23 15:51:00.664967
200	24	DK_CKH543	\N	Denmark 20GB 30Days	20	30	10.6	Denmark 20GB 30Days	t	21.2	2025-04-23 15:51:00.664972
201	24	DK_PJJEKFZJ0	\N	Denmark 50GB 180Days	50	180	22	Denmark 50GB 180Days	t	44	2025-04-23 15:51:00.664978
208	25	EE_PF1EBHZY5	\N	Estonia 50GB 180Days	50	180	30	Estonia 50GB 180Days	t	60	2025-04-23 15:51:16.953524
220	27	FR_CKH1005	\N	France 20GB 30Days	20	30	10.6	France 20GB 30Days	t	21.2	2025-04-23 15:51:49.56509
221	27	FR_P5ML89XJG	\N	France 50GB 180Days	50	180	22	France 50GB 180Days	t	44	2025-04-23 15:51:49.565096
222	27	FR_PG0H26XJA	\N	France 1GB/Day	1	1	0.85	France 1GB/Day	t	1.7	2025-04-23 15:51:49.565101
223	27	FR_PL2WG7K9D	\N	France 500MB/Day	0.49	1	0.45	France 500MB/Day	t	0.9	2025-04-23 15:51:49.565117
224	27	FR_P05WBGPG2	\N	France 2GB/Day	2	1	1.2	France 2GB/Day	t	2.4	2025-04-23 15:51:49.565137
225	27	FR_P2G8P5FHJ	\N	France 5GB/Day	5	1	2.3	France 5GB/Day	t	4.6	2025-04-23 15:51:49.565142
235	28	DE_PQ6VQPJ28	\N	Germany 2GB/Day	2	1	1.5	Germany 2GB/Day	t	3	2025-04-23 15:52:05.620856
236	28	DE_P241WBSZG	\N	Germany 5GB/Day	5	1	2.5	Germany 5GB/Day	t	5	2025-04-23 15:52:05.620861
256	31	IS_CKH714	\N	Iceland 20GB 30Days	20	30	16.8	Iceland 20GB 30Days	t	33.6	2025-04-23 15:52:54.869721
257	31	IS_PKK3BVKVF	\N	Iceland 50GB 180Days	50	180	37	Iceland 50GB 180Days	t	74	2025-04-23 15:52:54.869727
260	32	IE_CKH220	\N	Ireland 1GB 7Days	1	7	0.9	Ireland 1GB 7Days	t	1.8	2025-04-23 15:53:11.237853
261	32	IE_CKH221	\N	Ireland 3GB 15Days	3	15	2.2	Ireland 3GB 15Days	t	4.4	2025-04-23 15:53:11.237859
262	32	IE_CKH222	\N	Ireland 10GB 30Days	10	30	6.1	Ireland 10GB 30Days	t	12.2	2025-04-23 15:53:11.237865
263	32	IE_CKH720	\N	Ireland 20GB 30Days	20	30	10.6	Ireland 20GB 30Days	t	21.2	2025-04-23 15:53:11.237871
264	32	IE_PJVVSY6IR	\N	Ireland 50GB 180Days	50	180	22	Ireland 50GB 180Days	t	44	2025-04-23 15:53:11.237877
265	32	IE_PC3TTT87P	\N	Ireland 500MB 3Days	0.49	3	0.6	Ireland 500MB 3Days	t	1.2	2025-04-23 15:53:11.237883
266	32	IE_PC0TA4B6L	\N	Ireland 1GB/Day	1	1	0.85	Ireland 1GB/Day	t	1.7	2025-04-23 15:53:11.237894
275	33	IT_P79VVN4GK	\N	Italy 500MB/Day	0.49	1	0.45	Italy 500MB/Day	t	0.9	2025-04-23 15:53:29.022853
276	33	IT_PMMQ41F5S	\N	Italy 2GB/Day	2	1	1.5	Italy 2GB/Day	t	3	2025-04-23 15:53:29.022862
277	33	IT_P9Z3HQ8HG	\N	Italy 5GB/Day	5	1	2.3	Italy 5GB/Day	t	4.6	2025-04-23 15:53:29.022867
310	38	PL_PZMKJMCWN	\N	Poland 50GB 180Days	50	180	28	Poland 50GB 180Days	t	56	2025-04-23 15:54:56.713746
316	39	PT_CKH1011	\N	Portugal 20GB 30Days	20	30	10.6	Portugal 20GB 30Days	t	21.2	2025-04-23 15:55:14.202743
317	39	PT_P7R54NBNC	\N	Portugal 1GB/Day	1	1	0.85	Portugal 1GB/Day	t	1.7	2025-04-23 15:55:14.202748
321	40	RO_CKH240	\N	Romania 3GB 15Days	3	15	1.7	Romania 3GB 15Days	t	3.4	2025-04-23 15:55:31.816108
322	40	RO_CKH241	\N	Romania 10GB 30Days	10	30	4.7	Romania 10GB 30Days	t	9.4	2025-04-23 15:55:31.816113
323	40	RO_CKH728	\N	Romania 20GB 30Days	20	30	8.2	Romania 20GB 30Days	t	16.4	2025-04-23 15:55:31.816119
324	40	RO_PBOG35WTO	\N	Romania 50GB 180Days	50	180	30	Romania 50GB 180Days	t	60	2025-04-23 15:55:31.816124
328	41	SK_CKH197	\N	Slovakia 3GB 15Days	3	15	2.2	Slovakia 3GB 15Days	t	4.4	2025-04-23 15:55:50.843854
329	41	SK_CKH198	\N	Slovakia 10GB 30Days	10	30	6.1	Slovakia 10GB 30Days	t	12.2	2025-04-23 15:55:50.843859
330	41	SK_CKH730	\N	Slovakia 20GB 30Days	20	30	10.6	Slovakia 20GB 30Days	t	21.2	2025-04-23 15:55:50.843864
331	41	SK_PG4XMKAYQ	\N	Slovakia 50GB 180Days	50	180	30	Slovakia 50GB 180Days	t	60	2025-04-23 15:55:50.843871
338	42	SI_PCMQJGTVB	\N	Slovenia 50GB 180Days	50	180	30	Slovenia 50GB 180Days	t	60	2025-04-23 15:56:07.71854
350	44	CH_CKH736	\N	Switzerland 20GB 30Days	20	30	10.6	Switzerland 20GB 30Days	t	21.2	2025-04-23 15:56:40.602576
351	44	CH_PUOG8W99P	\N	Switzerland 50GB 180Days	50	180	22	Switzerland 50GB 180Days	t	44	2025-04-23 15:56:40.602582
352	44	CH_P4PQQ616Q	\N	Switzerland 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 15:56:40.602587
365	46	GB_PLLWT4O6B	\N	United Kingdom 50GB 180Days	50	180	28	United Kingdom 50GB 180Days	t	56	2025-04-23 15:57:13.00478
366	46	GB_PF527KUIR	\N	United Kingdom 500MB/Day	0.49	1	0.6	United Kingdom 500MB/Day	t	1.2	2025-04-23 15:57:13.004785
367	46	GB_P0YFEWXGN	\N	United Kingdom 1GB/Day	1	1	0.8	United Kingdom 1GB/Day	t	1.6	2025-04-23 15:57:13.00479
368	46	GB_P9XKTG7UW	\N	United Kingdom 2GB/Day	2	1	1.55	United Kingdom 2GB/Day	t	3.1	2025-04-23 15:57:13.004825
369	46	GB_PBV0LO9CW	\N	United Kingdom 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 15:57:13.00483
384	49	JE_CKH753	\N	Jersey 20GB 30Days	20	30	8.2	Jersey 20GB 30Days	t	16.4	2025-04-23 15:57:44.56856
386	50	RU_JC069	\N	Russia 5GB 30Days	5	30	11	Russia 5GB 30Days	t	22	2025-04-23 15:57:58.530656
387	50	RU_JC070	\N	Russia 1GB 7Days	1	7	2.9	Russia 1GB 7Days	t	5.8	2025-04-23 15:57:58.530662
388	50	RU_JC071	\N	Russia 3GB 15Days	3	15	7.2	Russia 3GB 15Days	t	14.4	2025-04-23 15:57:58.530668
389	50	RU_PVP4RSUMR	\N	Russia 100MB 7Days	0.1	7	0.4		t	0.8	2025-04-23 15:57:58.530681
394	51	GG_CKH788	\N	Guernsey 20GB 30Days	20	30	50	Guernsey 20GB 30Days	t	100	2025-04-23 15:58:09.153047
402	53	NO_CKH1001	\N	Norway 10GB 30Days	10	30	4.7	Norway 10GB 30Days	t	9.4	2025-04-23 15:58:40.806071
403	53	NO_CKH1009	\N	Norway 20GB 30Days	20	30	8.2	Norway 20GB 30Days	t	16.4	2025-04-23 15:58:40.806076
404	53	NO_PDUMILX5C	\N	Norway 50GB 180Days	50	180	28	Norway 50GB 180Days	t	56	2025-04-23 15:58:40.806082
405	53	NO_PL6FJ9N2A	\N	Norway 1GB/Day	1	1	0.65	Norway 1GB/Day	t	1.3	2025-04-23 15:58:40.806087
419	56	AU_POU9P9TSZ	\N	Australia 50GB 180Days	50	180	28	Australia 50GB 180Days	t	56	2025-04-23 15:59:19.993152
420	56	AU_PBLAOUJHR	\N	Australia 500MB/Day	0.49	1	0.5	Australia 500MB/Day	t	1	2025-04-23 15:59:19.993158
421	56	AU_PKAECJYPB	\N	Australia 1GB/Day	1	1	1	Australia 1GB/Day	t	2	2025-04-23 15:59:19.993163
422	56	AU_PM2ZWH3G5	\N	Australia 3GB 30Days	3	30	1.9	Australia 3GB 30Days	t	3.8	2025-04-23 15:59:19.99317
423	56	AU_PRUQ8T3B2	\N	Australia 2GB/Day	2	1	2	Australia 2GB/Day	t	4	2025-04-23 15:59:19.99318
424	56	AU_P4GHU52FZ	\N	Australia 3GB/Day	3	1	2.85	Australia 3GB/Day	t	5.7	2025-04-23 15:59:19.993186
425	56	AU_PWV71AAT5	\N	Australia 10GB/Day	10	1	9.3	Australia 10GB/Day	t	18.6	2025-04-23 15:59:19.993192
426	56	AU_PGWEQ1CSB	\N	Australia 100MB 7Days	0.1	7	0.11		t	0.22	2025-04-23 15:59:19.993198
438	57	MY_P1UL34KDX	\N	Malaysia 3GB 15Days (nonhkip)	3	15	2.6	Malaysia 3GB 15Days (nonhkip)	t	5.2	2025-04-23 15:59:33.528258
439	57	MY_PSG213EBL	\N	Malaysia 5GB 30Days (nonhkip)	5	30	4	Malaysia 5GB 30Days (nonhkip)	t	8	2025-04-23 15:59:33.528263
440	57	MY_PLDG73P5E	\N	Malaysia 10GB 30Days (nonhkip)	10	30	7	Malaysia 10GB 30Days (nonhkip)	t	14	2025-04-23 15:59:33.528268
441	57	MY_P04JBY6XN	\N	Malaysia 20GB 30Days (nonhkip)	20	30	12	Malaysia 20GB 30Days (nonhkip)	t	24	2025-04-23 15:59:33.528277
442	57	MY_PJJ7HCK42	\N	Malaysia 500MB/Day (nonhkip)	0.49	1	0.5	Malaysia 500MB/Day (nonhkip)	t	1	2025-04-23 15:59:33.528282
443	57	MY_PKFR059MT	\N	Malaysia 1GB/Day (nonhkip)	1	1	0.9	Malaysia 1GB/Day (nonhkip)	t	1.8	2025-04-23 15:59:33.528287
444	57	MY_P9BPF41DU	\N	Malaysia 2GB/Day (nonhkip)	2	1	1.7	Malaysia 2GB/Day (nonhkip)	t	3.4	2025-04-23 15:59:33.528292
448	58	NZ_JC082	\N	New Zealand 10GB 30Days	10	30	12.2	New Zealand 10GB 30Days	t	24.4	2025-04-23 15:59:46.49816
449	58	NZ_JC083	\N	New Zealand 20GB 30Days	20	30	20	New Zealand 20GB 30Days	t	40	2025-04-23 15:59:46.498166
450	58	NZ_PEIHJAQVY	\N	New Zealand 50GB 180Days	50	180	45	New Zealand 50GB 180Days	t	90	2025-04-23 15:59:46.498172
451	58	NZ_PN7CXKOWL	\N	New Zealand 500MB/Day	0.49	1	0.8	New Zealand 500MB/Day	t	1.6	2025-04-23 15:59:46.498195
452	58	NZ_PDLIRFGHE	\N	New Zealand 1GB/Day	1	1	1.5	New Zealand 1GB/Day	t	3	2025-04-23 15:59:46.498202
453	58	NZ_P7L62ZCMR	\N	New Zealand 2GB/Day	2	1	2.9	New Zealand 2GB/Day	t	5.8	2025-04-23 15:59:46.498207
454	58	NZ_P65ZSJGC3	\N	New Zealand 3GB/Day	3	1	4.2	New Zealand 3GB/Day	t	8.4	2025-04-23 15:59:46.498213
455	58	NZ_PLTOJ7B6Z	\N	New Zealand 100MB 7Days	0.1	7	0.19		t	0.38	2025-04-23 15:59:46.498219
463	59	PH_PKOY9TRDZ	\N	Philippines 1GB/Day	1	1	1.5	Philippines 1GB/Day	t	3	2025-04-23 16:00:00.448326
464	59	PH_PYKASRYFN	\N	Philippines 2GB/Day	2	1	3	Philippines 2GB/Day	t	6	2025-04-23 16:00:00.448332
465	59	PH_P7H5ESZX4	\N	Philippine 3GB/Day	3	1	4.5	Philippine 3GB/Day	t	9	2025-04-23 16:00:00.448337
466	59	PH_P08FIDBBQ	\N	Philippines 10GB/Day	10	1	15		t	30	2025-04-23 16:00:00.448343
467	59	PH_PXB3QI9EJ	\N	Philippines 100MB 7Days	0.1	7	0.19		t	0.38	2025-04-23 16:00:00.448349
478	60	SG_PS67RZTVO	\N	Singapore 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 16:00:16.223417
479	60	SG_PMYUL0A89	\N	Singapore 1GB 7Days (nonhkip)	1	7	1	Singapore 1GB 7Days (nonhkip)	t	2	2025-04-23 16:00:16.223422
480	60	SG_P8FS5BQQ7	\N	Singapore 3GB 15Days (nonhkip)	3	15	2.8	Singapore 3GB 15Days (nonhkip)	t	5.6	2025-04-23 16:00:16.223428
481	60	SG_P74SEFQ1M	\N	Singapore 5GB 30Days (nonhkip)	5	30	4	Singapore 5GB 30Days (nonhkip)	t	8	2025-04-23 16:00:16.223438
482	60	SG_PWX40HHM7	\N	Singapore 10GB 30Days (nonhkip)	10	30	7	Singapore 10GB 30Days (nonhkip)	t	14	2025-04-23 16:00:16.223444
483	60	SG_PN0S4RKN6	\N	Singapore 20GB 30Days (nonhkip)	20	30	12	Singapore 20GB 30Days (nonhkip)	t	24	2025-04-23 16:00:16.223449
484	60	SG_P07TJRC8Y	\N	Singapore 500MB/Day (nonhkip)	0.49	1	0.55	Singapore 500MB/Day (nonhkip)	t	1.1	2025-04-23 16:00:16.223455
485	60	SG_P2B5NQ3VH	\N	Singapore 1GB/Day (nonhkip)	1	1	0.95	Singapore 1GB/Day (nonhkip)	t	1.9	2025-04-23 16:00:16.22346
486	60	SG_PHDQJ3J94	\N	Singapore 2GB/Day (nonhkip)	2	1	1.8	Singapore 2GB/Day (nonhkip)	t	3.6	2025-04-23 16:00:16.223465
511	62	VN_P06VBPU3J	\N	Vietnam 1GB 7Days (nonhkip)	1	7	1.8	Vietnam 1GB 7Days (nonhkip)	t	3.6	2025-04-23 16:00:42.998129
512	62	VN_P41ERHYB6	\N	Vietnam 3GB 15Days (nonhkip)	3	15	4.6	Vietnam 3GB 15Days (nonhkip)	t	9.2	2025-04-23 16:00:42.998135
513	62	VN_PEB708QBF	\N	Vietnam 5GB 30Days (nonhkip)	5	30	7	Vietnam 5GB 30Days (nonhkip)	t	14	2025-04-23 16:00:42.998144
514	62	VN_P2UWBW9F4	\N	Vietnam 10GB 30Days (nonhkip)	10	30	12.2	Vietnam 10GB 30Days (nonhkip)	t	24.4	2025-04-23 16:00:42.998199
515	62	VN_PTNY9DB82	\N	Vietnam 20GB 30Days (nonhkip)	20	30	20	Vietnam 20GB 30Days (nonhkip)	t	40	2025-04-23 16:00:42.998206
516	62	VN_P9JL3S1GG	\N	Vietnam 500MB/Day (nonhkip)	0.49	1	0.58	Vietnam 500MB/Day (nonhkip)	t	1.16	2025-04-23 16:00:42.99822
517	62	VN_PP9NT7XP0	\N	Vietnam 1GB/Day (nonhkip)	1	1	1.46	Vietnam 1GB/Day (nonhkip)	t	2.92	2025-04-23 16:00:42.998226
518	62	VN_PSCA610LL	\N	Vietnam 2GB/Day (nonhkip)	2	1	2.8	Vietnam 2GB/Day (nonhkip)	t	5.6	2025-04-23 16:00:42.998244
528	63	CN_PBUK9LV51	\N	China mainland 2GB/Day	2	1	1.2	China mainland 2GB/Day	t	2.4	2025-04-23 16:00:59.205346
529	63	CN_P78LXV6UX	\N	China mainland 5GB/Day	5	1	2.4	China mainland 5GB/Day	t	4.8	2025-04-23 16:00:59.205352
530	63	CN_PLSSSXN2L	\N	China mainland 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 16:00:59.205366
531	63	CN_PW3XK1K7U	\N	China mainland 1GB 7Days (nonhkip)	1	7	1.15	China mainland 1GB 7Days (nonhkip)	t	2.3	2025-04-23 16:00:59.205372
532	63	CN_PG2YTC5T6	\N	China mainland 3GB 15Days (nonhkip)	3	15	2.75	China mainland 3GB 15Days (nonhkip)	t	5.5	2025-04-23 16:00:59.205384
533	63	CN_PJ21HG5FJ	\N	China mainland 5GB 30Days (nonhkip)	5	30	4	China mainland 5GB 30Days (nonhkip)	t	8	2025-04-23 16:00:59.20539
534	63	CN_PYEJ62J8F	\N	China mainland 10GB 30Days (nonhkip)	10	30	7.7	China mainland 10GB 30Days (nonhkip)	t	15.4	2025-04-23 16:00:59.205395
535	63	CN_P0XPU6NY1	\N	China mainland 20GB 30Days (nonhkip)	20	30	15.7	China mainland 20GB 30Days (nonhkip)	t	31.4	2025-04-23 16:00:59.205401
536	63	CN_PBA7XW0H5	\N	China mainland 500MB/Day (nonhkip)	0.49	1	0.6	China mainland 500MB/Day (nonhkip)	t	1.2	2025-04-23 16:00:59.205406
537	63	CN_P6JDSP39N	\N	China mainland 1GB/Day (nonhkip)	1	1	1.1	China mainland 1GB/Day (nonhkip)	t	2.2	2025-04-23 16:00:59.205412
538	63	CN_PYWR9L63K	\N	China mainland 2GB/Day (nonhkip)	2	1	2	China mainland 2GB/Day (nonhkip)	t	4	2025-04-23 16:00:59.205418
556	64	ID_PC374AFNY	\N	Indonesia 500MB/Day (nonhkip)	0.49	1	0.76	Indonesia 500MB/Day (nonhkip)	t	1.52	2025-04-23 16:01:14.755977
557	64	ID_P2TU7X1XJ	\N	Indonesia 1GB/Day (nonhkip)	1	1	1.2	Indonesia 1GB/Day (nonhkip)	t	2.4	2025-04-23 16:01:14.755982
558	64	ID_P09WQCRL3	\N	Indonesia 2GB/Day (nonhkip)	2	1	2.05	Indonesia 2GB/Day (nonhkip)	t	4.1	2025-04-23 16:01:14.755988
572	66	JP_JC145	\N	Japan 20GB 30Days	20	30	8.2	Japan 20GB 30Days	t	16.4	2025-04-23 16:01:45.484499
573	66	JP_PL4E7JOWX	\N	Japan 50GB 180Days	50	180	28	Japan 50GB 180Days	t	56	2025-04-23 16:01:45.484505
574	66	JP_P9JS074W4	\N	Japan 500MB/Day	0.49	1	0.5	Japan 500MB/Day	t	1	2025-04-23 16:01:45.484511
575	66	JP_P9TF1FXDA	\N	Japan 1GB/Day	1	1	1	Japan 1GB/Day	t	2	2025-04-23 16:01:45.484516
576	66	JP_PPWBVT0BF	\N	Japan 2GB/Day	2	1	2	Japan 2GB/Day	t	4	2025-04-23 16:01:45.484522
577	66	JP_P2AJZD4YX	\N	Japan 3GB 30Days	3	30	1.8	Japan 3GB 30Days	t	3.6	2025-04-23 16:01:45.484527
578	66	JP_P0GTZA81N	\N	Japan 3GB/Day	3	1	2.2	Japan 3GB/Day	t	4.4	2025-04-23 16:01:45.484533
579	66	JP_PFFM6ED75	\N	Japan 5GB/Day	5	1	4.4		t	8.8	2025-04-23 16:01:45.484538
580	66	JP_PGURVYHQ1	\N	Japan 10GB/Day	10	1	7.3		t	14.6	2025-04-23 16:01:45.484544
581	66	JP_P6ZMSDS1G	\N	Japan 100MB 7Days	0.1	7	0.1		t	0.2	2025-04-23 16:01:45.48455
582	66	JP_P94JA3ZNK	\N	Japan 1GB 7Days (nonhkip)	1	7	1.2	Japan 1GB 7Days (nonhkip)	t	2.4	2025-04-23 16:01:45.484555
583	66	JP_PYA70JN8W	\N	Japan 3GB 15Days (nonhkip)	3	15	3.25	Japan 3GB 15Days (nonhkip)	t	6.5	2025-04-23 16:01:45.484561
584	66	JP_PCUVF4Y91	\N	Japan 5GB 30Days (nonhkip)	5	30	4.5	Japan 5GB 30Days (nonhkip)	t	9	2025-04-23 16:01:45.484566
585	66	JP_PR2V54EPD	\N	Japan 10GB 30Days (nonhkip)	10	30	7.5	Japan 10GB 30Days (nonhkip)	t	15	2025-04-23 16:01:45.48458
586	66	JP_P7U1JSX2H	\N	Japan 20GB 30Days (nonhkip)	20	30	12.5	Japan 20GB 30Days (nonhkip)	t	25	2025-04-23 16:01:45.48459
587	66	JP_PLVVS2N87	\N	Japan 500MB/Day (nonhkip)	0.49	1	0.6	Japan 500MB/Day (nonhkip)	t	1.2	2025-04-23 16:01:45.484596
588	66	JP_P1GCN5FS9	\N	Japan 1GB/Day (nonhkip)	1	1	1.1	Japan 1GB/Day (nonhkip)	t	2.2	2025-04-23 16:01:45.484601
589	66	JP_P2H1DV6JP	\N	Japan 2GB/Day (nonhkip)	2	1	2.1	Japan 2GB/Day (nonhkip)	t	4.2	2025-04-23 16:01:45.484607
605	67	KR_PRT9KC28R	\N	South Korea 10GB 30Days (nonhkip)	10	30	7.5	South Korea 10GB 30Days (nonhkip)	t	15	2025-04-23 16:02:01.520333
606	67	KR_PXYKK106H	\N	South Korea 20GB 30Days (nonhkip)	20	30	12.5	South Korea 20GB 30Days (nonhkip)	t	25	2025-04-23 16:02:01.520339
607	67	KR_PZ2UCMK37	\N	South Korea 500MB/Day (nonhkip)	0.49	1	0.55	South Korea 500MB/Day (nonhkip)	t	1.1	2025-04-23 16:02:01.520353
608	67	KR_P20PMGJQ5	\N	South Korea 1GB/Day (nonhkip)	1	1	0.95	South Korea 1GB/Day (nonhkip)	t	1.9	2025-04-23 16:02:01.520359
609	67	KR_PLF859LWP	\N	South Korea 2GB/Day (nonhkip)	2	1	1.65	South Korea 2GB/Day (nonhkip)	t	3.3	2025-04-23 16:02:01.520364
610	67	KR_P0VZY58TB	\N	South Korea 3GB/Day (nonhkip)	3	1	2.1	South Korea 3GB/Day (nonhkip)	t	4.2	2025-04-23 16:02:01.52037
634	72	CL_CKH302	\N	Chile 1GB 7Days	1	7	5.7	Chile 1GB 7Days	t	11.4	2025-04-23 16:03:12.989649
635	72	CL_CKH318	\N	Chile 3GB 15Days	3	15	14.1	Chile 3GB 15Days	t	28.2	2025-04-23 16:03:12.989668
636	72	CL_PMQYGG8GO	\N	Chile 100MB 7Days	0.1	7	0.57		t	1.14	2025-04-23 16:03:12.989675
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_messages (id, ticket_id, sender_type, text, created_at) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, user_id, subject, message, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, telegram_id, username, first_name, last_name, language_code, is_admin, created_at, updated_at) FROM stdin;
1	855277058	topotun85	Vadim	Black	ru	f	2025-04-23 08:57:37.993496	2025-04-23 08:57:37.993508
\.


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.countries_id_seq', 139, true);


--
-- Name: esims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.esims_id_seq', 1, false);


--
-- Name: faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faqs_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, true);


--
-- Name: packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packages_id_seq', 918, true);


--
-- Name: support_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_messages_id_seq', 1, false);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: countries countries_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_code_key UNIQUE (code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: esims esims_order_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.esims
    ADD CONSTRAINT esims_order_id_key UNIQUE (order_id);


--
-- Name: esims esims_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.esims
    ADD CONSTRAINT esims_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_no_key UNIQUE (order_no);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_transaction_id_key UNIQUE (transaction_id);


--
-- Name: packages packages_package_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_package_code_key UNIQUE (package_code);


--
-- Name: packages packages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_pkey PRIMARY KEY (id);


--
-- Name: packages packages_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_slug_key UNIQUE (slug);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: esims esims_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.esims
    ADD CONSTRAINT esims_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: orders orders_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id);


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: packages packages_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: support_messages support_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

