--
-- PostgreSQL database dump
--

-- Dumped from database version 15.12 (Debian 15.12-1.pgdg120+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(255) NOT NULL,
    flag_emoji character varying(10),
    is_available boolean
);


ALTER TABLE public.countries OWNER TO postgres;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.countries_id_seq OWNER TO postgres;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: esims; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.esims (
    id integer NOT NULL,
    order_id integer NOT NULL,
    esim_tran_no character varying(255),
    iccid character varying(255),
    imsi character varying(255),
    msisdn character varying(255),
    activation_code character varying(1024),
    qr_code_url character varying(1024),
    short_url character varying(512),
    smdp_status character varying(50),
    esim_status character varying(50),
    active_type integer,
    expired_time timestamp without time zone,
    total_volume bigint,
    total_duration integer,
    duration_unit character varying(20),
    order_usage bigint,
    pin character varying(50),
    puk character varying(50),
    apn character varying(255),
    raw_data json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.esims OWNER TO postgres;

--
-- Name: esims_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.esims_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.esims_id_seq OWNER TO postgres;

--
-- Name: esims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.esims_id_seq OWNED BY public.esims.id;


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faqs (
    id integer NOT NULL,
    question_en text NOT NULL,
    answer_en text NOT NULL,
    question_ru text,
    answer_ru text,
    "order" integer,
    is_active boolean
);


ALTER TABLE public.faqs OWNER TO postgres;

--
-- Name: faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faqs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faqs_id_seq OWNER TO postgres;

--
-- Name: faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faqs_id_seq OWNED BY public.faqs.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    user_id integer NOT NULL,
    package_id integer NOT NULL,
    transaction_id character varying(255) NOT NULL,
    order_no character varying(255),
    status character varying(50),
    payment_method character varying(50),
    payment_id character varying(255),
    amount double precision NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    invoice_id character varying(255),
    payment_details text,
    paid_at timestamp without time zone,
    order_type character varying(50)
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: packages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packages (
    id integer NOT NULL,
    country_id integer NOT NULL,
    package_code character varying(255) NOT NULL,
    slug character varying(255),
    name character varying(255) NOT NULL,
    data_amount double precision NOT NULL,
    duration integer NOT NULL,
    price double precision NOT NULL,
    description text,
    is_available boolean
);


ALTER TABLE public.packages OWNER TO postgres;

--
-- Name: packages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.packages_id_seq OWNER TO postgres;

--
-- Name: packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packages_id_seq OWNED BY public.packages.id;


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_messages (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    sender_type character varying(20) NOT NULL,
    text text NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.support_messages OWNER TO postgres;

--
-- Name: support_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_messages_id_seq OWNER TO postgres;

--
-- Name: support_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_messages_id_seq OWNED BY public.support_messages.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    status character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_id bigint NOT NULL,
    username character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    language_code character varying(10),
    is_admin boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: esims id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.esims ALTER COLUMN id SET DEFAULT nextval('public.esims_id_seq'::regclass);


--
-- Name: faqs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs ALTER COLUMN id SET DEFAULT nextval('public.faqs_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: packages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages ALTER COLUMN id SET DEFAULT nextval('public.packages_id_seq'::regclass);


--
-- Name: support_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_messages ALTER COLUMN id SET DEFAULT nextval('public.support_messages_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
472779a6e53a
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.countries (id, code, name, flag_emoji, is_available) FROM stdin;
7	CA	Canada	🇨🇦	t
10	CN	China	🇨🇳	t
4	FR	France	🇫🇷	t
3	DE	Germany	🇩🇪	t
13	IN	India	🇮🇳	t
5	IT	Italy	🇮🇹	t
9	JP	Japan	🇯🇵	t
264	RE	Réunion	🇷🇪	t
265	KN	Saint Kitts and Nevis	🇰🇳	t
266	LC	Saint Lucia	🇱🇨	t
267	VC	Saint Vincent and the Grenadines	🇻🇨	t
268	WS	Samoa	🇼🇸	t
269	SM	San Marino	🇸🇲	t
270	SA	Saudi Arabia	🇸🇦	t
271	SN	Senegal	🇸🇳	t
272	RS	Serbia	🇷🇸	t
273	SC	Seychelles	🇸🇨	t
274	SG	Singapore	🇸🇬	t
275	SK	Slovakia	🇸🇰	t
276	SI	Slovenia	🇸🇮	t
277	SB	Solomon Islands	🇸🇧	t
278	ZA	South Africa	🇿🇦	t
6	ES	Spain	🇪🇸	t
279	LK	Sri Lanka	🇱🇰	t
280	SD	Sudan	🇸🇩	t
281	SJ	Svalbard and Jan Mayen	🇸🇯	t
282	SE	Sweden	🇸🇪	t
283	CH	Switzerland	🇨🇭	t
284	TW	Taiwan, Province of China	🇹🇼	t
285	TJ	Tajikistan	🇹🇯	t
286	TZ	Tanzania, United Republic of	🇹🇿	t
15	TH	Thailand	🇹🇭	t
287	TO	Tonga	🇹🇴	t
288	TN	Tunisia	🇹🇳	t
289	TC	Turks and Caicos Islands	🇹🇨	t
291	UG	Uganda	🇺🇬	t
292	UA	Ukraine	🇺🇦	t
14	AE	United Arab Emirates	🇦🇪	t
2	GB	United Kingdom	🇬🇧	t
1	US	United States	🇺🇸	t
293	UY	Uruguay	🇺🇾	t
294	UZ	Uzbekistan	🇺🇿	t
295	VN	Viet Nam	🇻🇳	t
296	VG	Virgin Islands, British	🇻🇬	t
297	YE	Yemen	🇾🇪	t
298	ZM	Zambia	🇿🇲	t
299	ZW	Zimbabwe	🇿🇼	t
300	AX	Åland Islands	🇦🇽	t
290	TR	Turkey	🇹🇷	t
11	RU	Russia	🇷🇺	t
139	!RG	Regional Packages	🌍	t
140	AF	Afghanistan	🇦🇫	t
141	AL	Albania	🇦🇱	t
142	DZ	Algeria	🇩🇿	t
143	AI	Anguilla	🇦🇮	t
144	AG	Antigua and Barbuda	🇦🇬	t
145	AR	Argentina	🇦🇷	t
146	AM	Armenia	🇦🇲	t
8	AU	Australia	🇦🇺	t
147	AT	Austria	🇦🇹	t
148	AZ	Azerbaijan	🇦🇿	t
149	BH	Bahrain	🇧🇭	t
150	BD	Bangladesh	🇧🇩	t
151	BB	Barbados	🇧🇧	t
152	BY	Belarus	🇧🇾	t
153	BE	Belgium	🇧🇪	t
154	BT	Bhutan	🇧🇹	t
12	BR	Brazil	🇧🇷	t
155	BO	Bolivia, Plurinational State of	🇧🇴	t
156	BA	Bosnia and Herzegovina	🇧🇦	t
157	BW	Botswana	🇧🇼	t
158	BN	Brunei Darussalam	🇧🇳	t
159	BG	Bulgaria	🇧🇬	t
160	BF	Burkina Faso	🇧🇫	t
161	KH	Cambodia	🇰🇭	t
162	CM	Cameroon	🇨🇲	t
163	KY	Cayman Islands	🇰🇾	t
164	CF	Central African Republic	🇨🇫	t
165	TD	Chad	🇹🇩	t
166	CL	Chile	🇨🇱	t
167	CO	Colombia	🇨🇴	t
168	CG	Congo	🇨🇬	t
169	CD	Congo, The Democratic Republic of the	🇨🇩	t
170	CR	Costa Rica	🇨🇷	t
171	HR	Croatia	🇭🇷	t
172	CY	Cyprus	🇨🇾	t
173	CZ	Czechia	🇨🇿	t
174	CI	Côte d'Ivoire	🇨🇮	t
175	DK	Denmark	🇩🇰	t
176	DM	Dominica	🇩🇲	t
177	DO	Dominican Republic	🇩🇴	t
178	EC	Ecuador	🇪🇨	t
179	EG	Egypt	🇪🇬	t
180	SV	El Salvador	🇸🇻	t
181	EE	Estonia	🇪🇪	t
182	SZ	Eswatini	🇸🇿	t
183	FO	Faroe Islands	🇫🇴	t
184	FJ	Fiji	🇫🇯	t
185	FI	Finland	🇫🇮	t
186	GF	French Guiana	🇬🇫	t
187	GA	Gabon	🇬🇦	t
188	GE	Georgia	🇬🇪	t
189	GH	Ghana	🇬🇭	t
190	GI	Gibraltar	🇬🇮	t
191	GR	Greece	🇬🇷	t
192	GL	Greenland	🇬🇱	t
193	GD	Grenada	🇬🇩	t
194	GP	Guadeloupe	🇬🇵	t
195	GU	Guam	🇬🇺	t
196	GT	Guatemala	🇬🇹	t
197	GG	Guernsey	🇬🇬	t
198	GW	Guinea-Bissau	🇬🇼	t
199	VA	Holy See (Vatican City State)	🇻🇦	t
200	HN	Honduras	🇭🇳	t
201	HK	Hong Kong	🇭🇰	t
202	HU	Hungary	🇭🇺	t
203	IS	Iceland	🇮🇸	t
204	ID	Indonesia	🇮🇩	t
205	IR	Iran, Islamic Republic of	🇮🇷	t
206	IQ	Iraq	🇮🇶	t
207	IE	Ireland	🇮🇪	t
208	IM	Isle of Man	🇮🇲	t
209	IL	Israel	🇮🇱	t
210	JM	Jamaica	🇯🇲	t
211	JE	Jersey	🇯🇪	t
212	JO	Jordan	🇯🇴	t
213	KZ	Kazakhstan	🇰🇿	t
214	KE	Kenya	🇰🇪	t
215	KI	Kiribati	🇰🇮	t
216	KR	Korea, Republic of	🇰🇷	t
217	KW	Kuwait	🇰🇼	t
218	KG	Kyrgyzstan	🇰🇬	t
219	LA	Lao People's Democratic Republic	🇱🇦	t
220	LV	Latvia	🇱🇻	t
221	LR	Liberia	🇱🇷	t
222	LI	Liechtenstein	🇱🇮	t
223	LT	Lithuania	🇱🇹	t
224	LU	Luxembourg	🇱🇺	t
225	MO	Macao	🇲🇴	t
226	MG	Madagascar	🇲🇬	t
227	MW	Malawi	🇲🇼	t
228	MY	Malaysia	🇲🇾	t
229	MV	Maldives	🇲🇻	t
230	ML	Mali	🇲🇱	t
231	MT	Malta	🇲🇹	t
232	MQ	Martinique	🇲🇶	t
233	MU	Mauritius	🇲🇺	t
234	MX	Mexico	🇲🇽	t
235	MD	Moldova, Republic of	🇲🇩	t
236	MC	Monaco	🇲🇨	t
237	MN	Mongolia	🇲🇳	t
238	ME	Montenegro	🇲🇪	t
239	MS	Montserrat	🇲🇸	t
240	MA	Morocco	🇲🇦	t
241	MZ	Mozambique	🇲🇿	t
242	NR	Nauru	🇳🇷	t
243	NP	Nepal	🇳🇵	t
244	NL	Netherlands	🇳🇱	t
245	NZ	New Zealand	🇳🇿	t
246	NI	Nicaragua	🇳🇮	t
247	NE	Niger	🇳🇪	t
248	NG	Nigeria	🇳🇬	t
249	MK	North Macedonia	🇲🇰	t
250	NO	Norway	🇳🇴	t
251	OM	Oman	🇴🇲	t
252	PK	Pakistan	🇵🇰	t
253	PS	Palestine, State of	🇵🇸	t
254	PA	Panama	🇵🇦	t
255	PG	Papua New Guinea	🇵🇬	t
256	PY	Paraguay	🇵🇾	t
257	PE	Peru	🇵🇪	t
258	PH	Philippines	🇵🇭	t
259	PL	Poland	🇵🇱	t
260	PT	Portugal	🇵🇹	t
261	PR	Puerto Rico	🇵🇷	t
262	QA	Qatar	🇶🇦	t
263	RO	Romania	🇷🇴	t
\.


--
-- Data for Name: esims; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.esims (id, order_id, esim_tran_no, iccid, imsi, msisdn, activation_code, qr_code_url, short_url, smdp_status, esim_status, active_type, expired_time, total_volume, total_duration, duration_unit, order_usage, pin, puk, apn, raw_data, created_at, updated_at) FROM stdin;
3	37		8943108170001280689	\N	\N	LPA:1$rsp-eu.simlessly.com$957158519D7D4E428B917D4B65D7A8D3	https://p.qrsim.net/7b96fd00dd8a4cf7b58679917d079e5d.png	\N	\N	CANCELED	\N	2025-04-15 14:06:59	\N	\N	\N	0	\N	\N	\N	"{\\"success\\": true, \\"order_no\\": \\"B25031614060016\\", \\"iccid\\": \\"8943108170001280689\\", \\"imsi\\": \\"232104070128068\\", \\"msisdn\\": \\"436789040128068\\", \\"activation_code\\": \\"LPA:1$rsp-eu.simlessly.com$957158519D7D4E428B917D4B65D7A8D3\\", \\"qr_code\\": \\"https://p.qrsim.net/7b96fd00dd8a4cf7b58679917d079e5d.png\\", \\"short_url\\": \\"https://p.qrsim.net/7b96fd00dd8a4cf7b58679917d079e5d\\", \\"esim_status\\": \\"GOT_RESOURCE\\", \\"active_type\\": 2, \\"expired_time\\": \\"2025-04-15T14:06:59+0000\\", \\"total_volume\\": 314572800, \\"total_duration\\": 1, \\"duration_unit\\": \\"DAY\\", \\"order_usage\\": 0, \\"pin\\": \\"3337\\", \\"puk\\": \\"67294810\\", \\"apn\\": \\"drei.at\\", \\"esim_list\\": [{\\"esimTranNo\\": \\"25031614060016\\", \\"orderNo\\": \\"B25031614060016\\", \\"transactionId\\": \\"37\\", \\"imsi\\": \\"232104070128068\\", \\"iccid\\": \\"8943108170001280689\\", \\"smsStatus\\": 1, \\"msisdn\\": \\"436789040128068\\", \\"ac\\": \\"LPA:1$rsp-eu.simlessly.com$957158519D7D4E428B917D4B65D7A8D3\\", \\"qrCodeUrl\\": \\"https://p.qrsim.net/7b96fd00dd8a4cf7b58679917d079e5d.png\\", \\"shortUrl\\": \\"https://p.qrsim.net/7b96fd00dd8a4cf7b58679917d079e5d\\", \\"smdpStatus\\": \\"RELEASED\\", \\"eid\\": \\"\\", \\"activeType\\": 2, \\"dataType\\": 2, \\"activateTime\\": null, \\"expiredTime\\": \\"2025-04-15T14:06:59+0000\\", \\"totalVolume\\": 314572800, \\"totalDuration\\": 1, \\"durationUnit\\": \\"DAY\\", \\"orderUsage\\": 0, \\"esimStatus\\": \\"GOT_RESOURCE\\", \\"pin\\": \\"3337\\", \\"puk\\": \\"67294810\\", \\"apn\\": \\"drei.at\\", \\"ipExport\\": \\"UK/NO\\", \\"supportTopUpType\\": 1, \\"fupPolicy\\": \\"\\", \\"packageList\\": [{\\"packageName\\": \\"Europe(30+ areas) 300MB/Day\\", \\"packageCode\\": \\"P82Y6VYRL\\", \\"slug\\": \\"EU-30_0.3_Daily\\", \\"duration\\": 1, \\"volume\\": 314572800, \\"locationCode\\": \\"NO,DE,BE,FI,PT,BG,DK,LT,LU,LV,HR,UA,FR,HU,SE,SI,SK,GB,IE,EE,CH,MT,IS,IT,GR,ES,AT,CY,CZ,PL,RO,LI,NL,TR\\", \\"createTime\\": \\"2025-03-16T14:06:56+0000\\"}]}], \\"raw_response\\": {\\"success\\": true, \\"errorCode\\": \\"0\\", \\"errorMsg\\": null, \\"obj\\": {\\"esimList\\": [{\\"esimTranNo\\": \\"25031614060016\\", \\"orderNo\\": \\"B25031614060016\\", \\"transactionId\\": \\"37\\", \\"imsi\\": \\"232104070128068\\", \\"iccid\\": \\"8943108170001280689\\", \\"smsStatus\\": 1, \\"msisdn\\": \\"436789040128068\\", \\"ac\\": \\"LPA:1$rsp-eu.simlessly.com$957158519D7D4E428B917D4B65D7A8D3\\", \\"qrCodeUrl\\": \\"https://p.qrsim.net/7b96fd00dd8a4cf7b58679917d079e5d.png\\", \\"shortUrl\\": \\"https://p.qrsim.net/7b96fd00dd8a4cf7b58679917d079e5d\\", \\"smdpStatus\\": \\"RELEASED\\", \\"eid\\": \\"\\", \\"activeType\\": 2, \\"dataType\\": 2, \\"activateTime\\": null, \\"expiredTime\\": \\"2025-04-15T14:06:59+0000\\", \\"totalVolume\\": 314572800, \\"totalDuration\\": 1, \\"durationUnit\\": \\"DAY\\", \\"orderUsage\\": 0, \\"esimStatus\\": \\"GOT_RESOURCE\\", \\"pin\\": \\"3337\\", \\"puk\\": \\"67294810\\", \\"apn\\": \\"drei.at\\", \\"ipExport\\": \\"UK/NO\\", \\"supportTopUpType\\": 1, \\"fupPolicy\\": \\"\\", \\"packageList\\": [{\\"packageName\\": \\"Europe(30+ areas) 300MB/Day\\", \\"packageCode\\": \\"P82Y6VYRL\\", \\"slug\\": \\"EU-30_0.3_Daily\\", \\"duration\\": 1, \\"volume\\": 314572800, \\"locationCode\\": \\"NO,DE,BE,FI,PT,BG,DK,LT,LU,LV,HR,UA,FR,HU,SE,SI,SK,GB,IE,EE,CH,MT,IS,IT,GR,ES,AT,CY,CZ,PL,RO,LI,NL,TR\\", \\"createTime\\": \\"2025-03-16T14:06:56+0000\\"}]}], \\"pager\\": {\\"pageSize\\": 20, \\"pageNum\\": 1, \\"total\\": 1}}}}"	2025-03-16 14:21:27.385788	2025-03-20 10:36:11.834421
1	36		8943108170001180830	\N	\N	LPA:1$rsp-eu.simlessly.com$7FD942DFC363463E9774ED63ECF683B7	https://p.qrsim.net/c6d575e6d554485995d09c5a3727c450.png	\N	\N	CANCEL	\N	\N	\N	\N	\N	0	\N	\N	\N	"{\\"success\\": true, \\"order_no\\": \\"B25031614060008\\", \\"iccid\\": \\"8943108170001180830\\", \\"imsi\\": \\"232104070118083\\", \\"msisdn\\": \\"436789040118083\\", \\"activation_code\\": \\"LPA:1$rsp-eu.simlessly.com$7FD942DFC363463E9774ED63ECF683B7\\", \\"qr_code\\": \\"https://p.qrsim.net/c6d575e6d554485995d09c5a3727c450.png\\", \\"short_url\\": \\"https://p.qrsim.net/c6d575e6d554485995d09c5a3727c450\\", \\"esim_status\\": \\"GOT_RESOURCE\\", \\"active_type\\": 2, \\"expired_time\\": \\"2025-04-15T14:06:50+0000\\", \\"total_volume\\": 314572800, \\"total_duration\\": 1, \\"duration_unit\\": \\"DAY\\", \\"order_usage\\": 0, \\"pin\\": \\"6182\\", \\"puk\\": \\"13569244\\", \\"apn\\": \\"drei.at\\", \\"esim_list\\": [{\\"esimTranNo\\": \\"25031614060008\\", \\"orderNo\\": \\"B25031614060008\\", \\"transactionId\\": \\"36\\", \\"imsi\\": \\"232104070118083\\", \\"iccid\\": \\"8943108170001180830\\", \\"smsStatus\\": 1, \\"msisdn\\": \\"436789040118083\\", \\"ac\\": \\"LPA:1$rsp-eu.simlessly.com$7FD942DFC363463E9774ED63ECF683B7\\", \\"qrCodeUrl\\": \\"https://p.qrsim.net/c6d575e6d554485995d09c5a3727c450.png\\", \\"shortUrl\\": \\"https://p.qrsim.net/c6d575e6d554485995d09c5a3727c450\\", \\"smdpStatus\\": \\"RELEASED\\", \\"eid\\": \\"\\", \\"activeType\\": 2, \\"dataType\\": 2, \\"activateTime\\": null, \\"expiredTime\\": \\"2025-04-15T14:06:50+0000\\", \\"totalVolume\\": 314572800, \\"totalDuration\\": 1, \\"durationUnit\\": \\"DAY\\", \\"orderUsage\\": 0, \\"esimStatus\\": \\"GOT_RESOURCE\\", \\"pin\\": \\"6182\\", \\"puk\\": \\"13569244\\", \\"apn\\": \\"drei.at\\", \\"ipExport\\": \\"UK/NO\\", \\"supportTopUpType\\": 1, \\"fupPolicy\\": \\"\\", \\"packageList\\": [{\\"packageName\\": \\"Europe(30+ areas) 300MB/Day\\", \\"packageCode\\": \\"P82Y6VYRL\\", \\"slug\\": \\"EU-30_0.3_Daily\\", \\"duration\\": 1, \\"volume\\": 314572800, \\"locationCode\\": \\"NO,DE,BE,FI,PT,BG,DK,LT,LU,LV,HR,UA,FR,HU,SE,SI,SK,GB,IE,EE,CH,MT,IS,IT,GR,ES,AT,CY,CZ,PL,RO,LI,NL,TR\\", \\"createTime\\": \\"2025-03-16T14:06:47+0000\\"}]}], \\"raw_response\\": {\\"success\\": true, \\"errorCode\\": \\"0\\", \\"errorMsg\\": null, \\"obj\\": {\\"esimList\\": [{\\"esimTranNo\\": \\"25031614060008\\", \\"orderNo\\": \\"B25031614060008\\", \\"transactionId\\": \\"36\\", \\"imsi\\": \\"232104070118083\\", \\"iccid\\": \\"8943108170001180830\\", \\"smsStatus\\": 1, \\"msisdn\\": \\"436789040118083\\", \\"ac\\": \\"LPA:1$rsp-eu.simlessly.com$7FD942DFC363463E9774ED63ECF683B7\\", \\"qrCodeUrl\\": \\"https://p.qrsim.net/c6d575e6d554485995d09c5a3727c450.png\\", \\"shortUrl\\": \\"https://p.qrsim.net/c6d575e6d554485995d09c5a3727c450\\", \\"smdpStatus\\": \\"RELEASED\\", \\"eid\\": \\"\\", \\"activeType\\": 2, \\"dataType\\": 2, \\"activateTime\\": null, \\"expiredTime\\": \\"2025-04-15T14:06:50+0000\\", \\"totalVolume\\": 314572800, \\"totalDuration\\": 1, \\"durationUnit\\": \\"DAY\\", \\"orderUsage\\": 0, \\"esimStatus\\": \\"GOT_RESOURCE\\", \\"pin\\": \\"6182\\", \\"puk\\": \\"13569244\\", \\"apn\\": \\"drei.at\\", \\"ipExport\\": \\"UK/NO\\", \\"supportTopUpType\\": 1, \\"fupPolicy\\": \\"\\", \\"packageList\\": [{\\"packageName\\": \\"Europe(30+ areas) 300MB/Day\\", \\"packageCode\\": \\"P82Y6VYRL\\", \\"slug\\": \\"EU-30_0.3_Daily\\", \\"duration\\": 1, \\"volume\\": 314572800, \\"locationCode\\": \\"NO,DE,BE,FI,PT,BG,DK,LT,LU,LV,HR,UA,FR,HU,SE,SI,SK,GB,IE,EE,CH,MT,IS,IT,GR,ES,AT,CY,CZ,PL,RO,LI,NL,TR\\", \\"createTime\\": \\"2025-03-16T14:06:47+0000\\"}]}], \\"pager\\": {\\"pageSize\\": 20, \\"pageNum\\": 1, \\"total\\": 1}}}}"	2025-03-16 14:13:31.592075	2025-03-17 18:47:02.012653
2	38		8943108170005796102	\N	\N	LPA:1$rsp-eu.simlessly.com$EFC1961A8AFE4CB48F06C5126C463DBC	https://p.qrsim.net/c050c18c1fc749da94b8849c64bcc746.png	\N	\N	CANCELED	\N	2025-04-15 14:06:57	\N	\N	\N	0	\N	\N	\N	"{\\"success\\": true, \\"order_no\\": \\"B25031614060015\\", \\"iccid\\": \\"8943108170005796102\\", \\"imsi\\": \\"232104070579610\\", \\"msisdn\\": \\"4367844400610\\", \\"activation_code\\": \\"LPA:1$rsp-eu.simlessly.com$EFC1961A8AFE4CB48F06C5126C463DBC\\", \\"qr_code\\": \\"https://p.qrsim.net/c050c18c1fc749da94b8849c64bcc746.png\\", \\"short_url\\": \\"https://p.qrsim.net/c050c18c1fc749da94b8849c64bcc746\\", \\"esim_status\\": \\"GOT_RESOURCE\\", \\"active_type\\": 2, \\"expired_time\\": \\"2025-04-15T14:06:57+0000\\", \\"total_volume\\": 314572800, \\"total_duration\\": 1, \\"duration_unit\\": \\"DAY\\", \\"order_usage\\": 0, \\"pin\\": \\"8878\\", \\"puk\\": \\"61889945\\", \\"apn\\": \\"drei.at\\", \\"esim_list\\": [{\\"esimTranNo\\": \\"25031614060015\\", \\"orderNo\\": \\"B25031614060015\\", \\"transactionId\\": \\"38\\", \\"imsi\\": \\"232104070579610\\", \\"iccid\\": \\"8943108170005796102\\", \\"smsStatus\\": 1, \\"msisdn\\": \\"4367844400610\\", \\"ac\\": \\"LPA:1$rsp-eu.simlessly.com$EFC1961A8AFE4CB48F06C5126C463DBC\\", \\"qrCodeUrl\\": \\"https://p.qrsim.net/c050c18c1fc749da94b8849c64bcc746.png\\", \\"shortUrl\\": \\"https://p.qrsim.net/c050c18c1fc749da94b8849c64bcc746\\", \\"smdpStatus\\": \\"RELEASED\\", \\"eid\\": \\"\\", \\"activeType\\": 2, \\"dataType\\": 2, \\"activateTime\\": null, \\"expiredTime\\": \\"2025-04-15T14:06:57+0000\\", \\"totalVolume\\": 314572800, \\"totalDuration\\": 1, \\"durationUnit\\": \\"DAY\\", \\"orderUsage\\": 0, \\"esimStatus\\": \\"GOT_RESOURCE\\", \\"pin\\": \\"8878\\", \\"puk\\": \\"61889945\\", \\"apn\\": \\"drei.at\\", \\"ipExport\\": \\"UK/NO\\", \\"supportTopUpType\\": 1, \\"fupPolicy\\": \\"\\", \\"packageList\\": [{\\"packageName\\": \\"Europe(30+ areas) 300MB/Day\\", \\"packageCode\\": \\"P82Y6VYRL\\", \\"slug\\": \\"EU-30_0.3_Daily\\", \\"duration\\": 1, \\"volume\\": 314572800, \\"locationCode\\": \\"NO,DE,BE,FI,PT,BG,DK,LT,LU,LV,HR,UA,FR,HU,SE,SI,SK,GB,IE,EE,CH,MT,IS,IT,GR,ES,AT,CY,CZ,PL,RO,LI,NL,TR\\", \\"createTime\\": \\"2025-03-16T14:06:54+0000\\"}]}], \\"raw_response\\": {\\"success\\": true, \\"errorCode\\": \\"0\\", \\"errorMsg\\": null, \\"obj\\": {\\"esimList\\": [{\\"esimTranNo\\": \\"25031614060015\\", \\"orderNo\\": \\"B25031614060015\\", \\"transactionId\\": \\"38\\", \\"imsi\\": \\"232104070579610\\", \\"iccid\\": \\"8943108170005796102\\", \\"smsStatus\\": 1, \\"msisdn\\": \\"4367844400610\\", \\"ac\\": \\"LPA:1$rsp-eu.simlessly.com$EFC1961A8AFE4CB48F06C5126C463DBC\\", \\"qrCodeUrl\\": \\"https://p.qrsim.net/c050c18c1fc749da94b8849c64bcc746.png\\", \\"shortUrl\\": \\"https://p.qrsim.net/c050c18c1fc749da94b8849c64bcc746\\", \\"smdpStatus\\": \\"RELEASED\\", \\"eid\\": \\"\\", \\"activeType\\": 2, \\"dataType\\": 2, \\"activateTime\\": null, \\"expiredTime\\": \\"2025-04-15T14:06:57+0000\\", \\"totalVolume\\": 314572800, \\"totalDuration\\": 1, \\"durationUnit\\": \\"DAY\\", \\"orderUsage\\": 0, \\"esimStatus\\": \\"GOT_RESOURCE\\", \\"pin\\": \\"8878\\", \\"puk\\": \\"61889945\\", \\"apn\\": \\"drei.at\\", \\"ipExport\\": \\"UK/NO\\", \\"supportTopUpType\\": 1, \\"fupPolicy\\": \\"\\", \\"packageList\\": [{\\"packageName\\": \\"Europe(30+ areas) 300MB/Day\\", \\"packageCode\\": \\"P82Y6VYRL\\", \\"slug\\": \\"EU-30_0.3_Daily\\", \\"duration\\": 1, \\"volume\\": 314572800, \\"locationCode\\": \\"NO,DE,BE,FI,PT,BG,DK,LT,LU,LV,HR,UA,FR,HU,SE,SI,SK,GB,IE,EE,CH,MT,IS,IT,GR,ES,AT,CY,CZ,PL,RO,LI,NL,TR\\", \\"createTime\\": \\"2025-03-16T14:06:54+0000\\"}]}], \\"pager\\": {\\"pageSize\\": 20, \\"pageNum\\": 1, \\"total\\": 1}}}}"	2025-03-16 14:17:24.002339	2025-04-02 20:29:45.982716
4	39	B25031618430002	8943108170005743815	\N	\N	LPA:1$rsp-eu.simlessly.com$A03683F4CE9F440D87D4A74378EE9370	https://p.qrsim.net/ca770157bf214a89baf81c40dd866cdd.png	\N	\N	ACTIVATED	\N	2025-04-15 18:43:16	\N	\N	\N	0	\N	\N	\N	"{\\"success\\": true, \\"errorCode\\": \\"0\\", \\"errorMsg\\": null, \\"obj\\": {\\"esimList\\": [{\\"esimTranNo\\": \\"25031618430002\\", \\"orderNo\\": \\"B25031618430002\\", \\"transactionId\\": \\"order-39-deb66bb6\\", \\"imsi\\": \\"232104070574381\\", \\"iccid\\": \\"8943108170005743815\\", \\"smsStatus\\": 1, \\"msisdn\\": \\"4367844395381\\", \\"ac\\": \\"LPA:1$rsp-eu.simlessly.com$A03683F4CE9F440D87D4A74378EE9370\\", \\"qrCodeUrl\\": \\"https://p.qrsim.net/ca770157bf214a89baf81c40dd866cdd.png\\", \\"shortUrl\\": \\"https://p.qrsim.net/ca770157bf214a89baf81c40dd866cdd\\", \\"smdpStatus\\": \\"RELEASED\\", \\"eid\\": \\"\\", \\"activeType\\": 2, \\"dataType\\": 2, \\"activateTime\\": null, \\"expiredTime\\": \\"2025-04-15T18:43:16+0000\\", \\"totalVolume\\": 314572800, \\"totalDuration\\": 1, \\"durationUnit\\": \\"DAY\\", \\"orderUsage\\": 0, \\"esimStatus\\": \\"GOT_RESOURCE\\", \\"pin\\": \\"2899\\", \\"puk\\": \\"71515599\\", \\"apn\\": \\"drei.at\\", \\"ipExport\\": \\"UK/NO\\", \\"supportTopUpType\\": 1, \\"fupPolicy\\": \\"\\", \\"packageList\\": [{\\"packageName\\": \\"Europe(30+ areas) 300MB/Day\\", \\"packageCode\\": \\"P82Y6VYRL\\", \\"slug\\": \\"EU-30_0.3_Daily\\", \\"duration\\": 1, \\"volume\\": 314572800, \\"locationCode\\": \\"NO,DE,BE,FI,PT,BG,DK,LT,LU,LV,HR,UA,FR,HU,SE,SI,SK,GB,IE,EE,CH,MT,IS,IT,GR,ES,AT,CY,CZ,PL,RO,LI,NL,TR\\", \\"createTime\\": \\"2025-03-16T18:43:13+0000\\"}]}], \\"pager\\": {\\"pageSize\\": 20, \\"pageNum\\": 1, \\"total\\": 1}}}"	2025-03-16 18:43:35.801085	2025-04-02 20:29:33.479297
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faqs (id, question_en, answer_en, question_ru, answer_ru, "order", is_active) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, user_id, package_id, transaction_id, order_no, status, payment_method, payment_id, amount, created_at, updated_at, invoice_id, payment_details, paid_at, order_type) FROM stdin;
1	1	1182	a309919b-27ad-476b-ae18-1ee5888cbdde	\N	canceled	\N	\N	2.9	2025-03-10 14:34:12.466323	2025-03-10 14:34:22.278775	\N	\N	\N	\N
2	1	1182	a174ee31-8c1b-4235-8260-6ee44ead0b9f	\N	paid	\N	\N	2.9	2025-03-10 14:34:37.600999	2025-03-10 14:34:39.680538	\N	\N	\N	\N
3	1	886	c8e6d8a4-f1c6-452b-83b5-4604963b70a2	\N	paid	\N	\N	0.9	2025-03-10 14:34:57.2581	2025-03-10 14:35:27.608976	\N	\N	\N	\N
4	1	886	9c3787b0-149d-4771-a02b-b1ef271d6f23	\N	canceled	\N	\N	0.9	2025-03-10 14:35:37.795793	2025-03-10 14:35:43.375039	\N	\N	\N	\N
5	1	886	f1818df0-4837-47ac-a86c-5c5be4fee592	\N	canceled	\N	\N	0.9	2025-03-10 14:47:29.575518	2025-03-10 14:47:59.267466	\N	\N	\N	\N
6	1	886	1eae9b13-8183-45cd-8c21-72d48bc9201e	\N	canceled	\N	\N	0.9	2025-03-10 14:52:15.111062	2025-03-10 14:52:23.207275	\N	\N	\N	\N
7	1	886	81751619-7562-4d76-8095-04ce96b13028	\N	canceled	\N	\N	0.9	2025-03-10 14:52:48.520131	2025-03-10 15:01:24.105056	\N	\N	\N	\N
8	1	886	456eb89b-5b8f-4975-bfd4-ccde4246acab	\N	canceled	\N	\N	0.9	2025-03-10 15:21:07.545244	2025-03-10 15:21:10.583644	\N	\N	\N	\N
9	1	886	57a4a14a-d72c-4981-9ed9-84ac536d3342	\N	canceled	\N	\N	0.9	2025-03-10 15:25:38.105173	2025-03-10 15:25:40.706202	\N	\N	\N	\N
10	1	886	260af842-ebe0-4ba8-b0f1-9d0a3d8802cd	\N	canceled	\N	\N	0.9	2025-03-10 15:29:17.986979	2025-03-10 15:29:21.795285	\N	\N	\N	\N
11	1	879	4511c9a6-a344-4ade-abd2-bed5fef2b2c6	\N	canceled	\N	\N	7.1	2025-03-10 15:31:40.961192	2025-03-10 15:31:44.127759	\N	\N	\N	\N
12	1	886	41984068-f3b0-4439-b086-71de6491b2d0	\N	canceled	\N	\N	0.9	2025-03-10 15:34:04.549243	2025-03-10 15:34:07.174311	\N	\N	\N	\N
13	1	886	842df0ca-8466-4b68-aea5-0e3ac2242d30	\N	canceled	\N	\N	0.9	2025-03-10 15:42:08.185667	2025-03-10 15:42:10.680349	\N	\N	\N	\N
14	1	886	b221642b-4d95-4eab-9abc-e42613a90ac1	\N	canceled	\N	\N	0.9	2025-03-10 15:45:30.171419	2025-03-10 15:45:33.063863	\N	\N	\N	\N
15	1	886	0fecfddd-a5ed-4579-99d5-08841ba9f65c	\N	canceled	\N	\N	0.9	2025-03-10 15:47:59.786081	2025-03-10 15:48:02.549154	\N	\N	\N	\N
16	1	886	295acadf-a851-45ab-99dc-916ef9523f5d	\N	awaiting_payment	\N	\N	0.9	2025-03-10 15:52:01.056274	2025-03-10 15:52:01.058496	\N	\N	\N	\N
17	1	871	1758f616-4e14-44b0-b0a5-bdefc4cb8dde	\N	canceled	\N	\N	1.8	2025-03-11 07:22:48.09888	2025-03-11 07:33:34.848793	\N	\N	\N	\N
18	1	886	bf311b53-3951-45d0-a919-bb9f4dd2b287	\N	awaiting_payment	\N	\N	0.9	2025-03-11 07:33:39.227822	2025-03-11 07:33:39.228959	\N	\N	\N	\N
19	1	886	744f01b1-6d33-42e2-92fa-e50119c92150	\N	awaiting_payment	\N	\N	0.9	2025-03-11 07:49:07.224864	2025-03-11 07:49:07.230767	\N	\N	\N	\N
20	1	886	ec392d04-d3af-4fd0-bda3-e57aea1e67a0	\N	awaiting_payment	\N	\N	0.9	2025-03-11 08:08:45.999101	2025-03-11 08:08:46.004664	\N	\N	\N	\N
27	1	1307	f6903640-1dc2-4333-9ac0-60e0ec2cbbea	\N	paid	ton	\N	0.45	2025-03-11 14:30:36.255131	2025-03-11 14:35:33.513791	22126933	{'paid': True, 'status': 'paid', 'amount': '0.18', 'fee': 0, 'payload': 'order_27_f56f497e', 'asset': 'TON'}	2025-03-11 14:35:33.506736	\N
21	1	886	2d73fd7f-af8d-4b74-9517-451209aae5c9	\N	canceled	ton	\N	0.9	2025-03-11 09:02:22.492079	2025-03-11 09:03:06.994366	22109892	\N	\N	\N
22	1	886	8b762064-a0af-4f8b-80ca-8b94d013fcf3	\N	canceled	ton	\N	0.9	2025-03-11 09:03:33.157472	2025-03-11 09:03:42.178872	22109961	\N	\N	\N
33	1	1307	4814b550-46aa-4cb4-a196-9ef9ae1500b8	\N	awaiting_payment	ton	\N	0.45	2025-03-13 21:01:49.581673	2025-03-13 21:01:50.662538	22260127	\N	\N	\N
23	1	886	d29a5d3e-6d50-4649-86bd-062235c4039b	\N	canceled	ton	\N	0.9	2025-03-11 09:03:54.873953	2025-03-11 09:29:45.592379	22109987	\N	\N	\N
24	1	886	9c21fb0e-bb28-45a2-b124-f886ee411533	\N	awaiting_payment	ton	\N	0.9	2025-03-11 09:52:38.959964	2025-03-11 09:52:40.195117	22112245	\N	\N	\N
28	1	1307	49b86d2b-0968-4bc3-93cc-0dde66f38985	\N	paid	ton	\N	0.45	2025-03-11 14:43:17.791281	2025-03-11 14:45:51.183348	22127549	{'paid': True, 'status': 'paid', 'amount': '0.18', 'fee': 0, 'payload': 'order_28_f249c688', 'asset': 'TON'}	2025-03-11 14:45:51.177358	\N
25	1	2127	2f453d23-29b3-4119-8f6e-88c4f27b1def	\N	canceled	ton	\N	0.01	2025-03-11 11:28:25.636182	2025-03-11 11:30:39.285563	fallback_ae2e8545	\N	\N	\N
26	1	1307	ae11e993-db16-4935-9752-3cdf2cd2c27e	\N	paid	ton	\N	0.45	2025-03-11 11:31:33.111694	2025-03-11 11:34:03.850692	22117385	{'paid': True, 'status': 'paid', 'amount': '0.17', 'fee': 0, 'payload': 'order_26_2ba61212', 'asset': 'TON'}	2025-03-11 11:34:03.838813	\N
32	1	1307	d0198bc6-d229-44a4-bf8c-84a89bfa0ae9	\N	awaiting_payment	ton	\N	0.45	2025-03-13 20:25:35.583906	2025-03-13 20:27:28.9334	22258571	{'paid': True, 'status': 'paid', 'amount': '0.16', 'fee': 0, 'payload': 'order_32_13848f5e', 'asset': 'TON'}	2025-03-13 20:27:24.818883	\N
31	1	1307	c9715f8a-8e53-45c3-825b-39d8a4bcf2f6	\N	awaiting_payment	ton	\N	0.45	2025-03-13 19:52:33.566428	2025-03-13 19:54:32.523929	22256804	{'paid': True, 'status': 'paid', 'amount': '0.17', 'fee': 0, 'payload': 'order_31_99335887', 'asset': 'TON'}	2025-03-13 19:54:31.332297	\N
30	1	1307	576184f4-5389-4dad-bbd3-c62eac5fb3b6	\N	canceled	ton	\N	0.45	2025-03-13 19:51:55.289297	2025-03-13 19:52:25.030964	22256771	\N	\N	\N
29	1	1307	0f891b62-b17b-4ab3-a008-e8136aa655c9	\N	awaiting_payment	ton	\N	0.45	2025-03-13 19:40:22.782356	2025-03-13 19:42:58.097369	22256168	{'paid': True, 'status': 'paid', 'amount': '0.17', 'fee': 0, 'payload': 'order_29_a9c10105', 'asset': 'TON'}	2025-03-13 19:42:56.813643	\N
39	1	1307	f2719397-6f28-48c5-ba30-b5ab0d7a1ec7	B25031618430002	completed	ton	\N	0.45	2025-03-16 17:31:26.980279	2025-03-16 18:43:35.781915	22408519	{'paid': True, 'status': 'paid', 'amount': '0.13', 'fee': 0, 'payload': 'order_39_2a44406a', 'asset': 'TON'}	2025-03-16 17:37:25.962371	\N
38	1	1307	ec47efaa-2f04-4f6d-88d8-0dc2b27e8da4	\N	completed	ton	\N	0.45	2025-03-16 12:27:19.366771	2025-03-16 14:17:23.98646	22392217	{'paid': True, 'status': 'paid', 'amount': '0.13', 'fee': 0, 'payload': 'order_38_4dfa5e0d', 'asset': 'TON'}	2025-03-16 12:30:49.761755	\N
35	1	1307	f238341d-fc71-46f3-95ad-a290c34e80de	\N	canceled	ton	\N	0.45	2025-03-16 11:26:54.110335	2025-03-16 11:27:07.890816	22389131	\N	\N	\N
41	1	1307	TOPUP-1742464360-1	\N	created	\N	\N	0.45	2025-03-20 09:52:40.499783	2025-03-20 09:52:40.509501	\N	{"topup_for_esim_id": 4, "topup_for_esim_iccid": "8943108170005743815", "original_order_id": 39}	\N	\N
40	1	1027	656c7893-6928-4c0f-8680-97742d41ca8c	\N	canceled	ton	\N	2.9	2025-03-18 10:12:30.121553	2025-03-18 10:12:46.88086	22497633	\N	\N	\N
36	1	1307	5b02279b-847d-49e9-a444-7dd7952e7d3d	\N	completed	ton	\N	0.45	2025-03-16 11:34:36.469538	2025-03-16 14:13:31.564433	22389497	{'paid': True, 'status': 'paid', 'amount': '0.13', 'fee': 0, 'payload': 'order_36_4a30ffbe', 'asset': 'TON'}	2025-03-16 11:37:49.061766	\N
37	1	1307	b8ca87ba-995a-4da9-8152-b92adc1b0ed0	\N	completed	ton	\N	0.45	2025-03-16 12:02:47.766897	2025-03-16 14:21:27.376623	22390866	{'paid': True, 'status': 'paid', 'amount': '0.13', 'fee': 0, 'payload': 'order_37_62b84341', 'asset': 'TON'}	2025-03-16 12:04:59.477782	\N
34	1	1307	3777db0c-bf8f-40b9-bce6-8374652fd28f	\N	awaiting_payment	ton	\N	0.45	2025-03-16 11:16:10.075708	2025-03-16 11:18:06.171423	22388631	{'paid': True, 'status': 'paid', 'amount': '0.13', 'fee': 0, 'payload': 'order_34_c02fba05', 'asset': 'TON'}	2025-03-16 11:18:06.000594	\N
42	1	1307	TOPUP-1742464776-1	\N	created	\N	\N	0.45	2025-03-20 09:59:36.338008	2025-03-20 09:59:36.348065	\N	{"topup_for_esim_id": 4, "topup_for_esim_iccid": "8943108170005743815", "original_order_id": 39}	\N	\N
43	1	1270	TOPUP-1742465089-1	\N	created	\N	\N	0.9	2025-03-20 10:04:49.179227	2025-03-20 10:04:49.202838	\N	{"topup_for_esim_id": 4, "topup_for_esim_iccid": "8943108170005743815", "original_order_id": 39}	\N	\N
44	1	1307	TOPUP-1742465722-1	\N	created	\N	\N	0.45	2025-03-20 10:15:22.66583	2025-03-20 10:15:22.678001	\N	{"topup_for_esim_id": 4, "topup_for_esim_iccid": "8943108170005743815", "original_order_id": 39}	\N	\N
45	1	1280	TOPUP-1742467023-1	\N	created	\N	\N	0.01	2025-03-20 10:37:03.636184	2025-03-20 10:37:03.65529	\N	{"topup_for_esim_id": 3, "topup_for_esim_iccid": "8943108170001280689", "original_order_id": 37}	\N	\N
46	1	1307	topup-8943108170005743815-1742468882	\N	created	\N	\N	0.45	2025-03-20 11:08:02.446898	2025-03-20 11:08:02.454325	\N	\N	\N	\N
47	1	1307	b675b405-da8a-47a1-bc78-3278dcfcbefb	\N	canceled	ton	\N	0.45	2025-03-20 11:37:55.66612	2025-03-20 11:38:22.475237	22613684	\N	\N	\N
48	1	1307	topup-8943108170005743815-1742470756	\N	created	\N	\N	0.45	2025-03-20 11:39:16.82094	2025-03-20 11:39:16.822393	\N	\N	\N	\N
49	1	1307	topup-8943108170005743815-1742642761	\N	created	\N	\N	0.45	2025-03-22 11:26:01.232002	2025-03-22 11:26:01.240305	\N	\N	\N	topup
50	1	1307	topup-8943108170005743815-1742642926	\N	created	\N	\N	0.45	2025-03-22 11:28:46.412156	2025-03-22 11:28:46.419773	\N	\N	\N	topup
51	1	1307	topup-8943108170005743815-1742642970	\N	created	\N	\N	0.45	2025-03-22 11:29:30.273223	2025-03-22 11:29:30.27504	\N	\N	\N	topup
52	1	1307	topup-8943108170005743815-1742643127	\N	created	\N	\N	0.45	2025-03-22 11:32:07.719566	2025-03-22 11:32:07.724317	\N	\N	\N	topup
53	1	1307	topup-8943108170005743815-1742643461	\N	created	\N	\N	0.45	2025-03-22 11:37:41.414378	2025-03-22 11:37:41.422301	\N	\N	\N	topup
54	1	1307	topup-8943108170005743815-1742644192	\N	created	\N	\N	0.45	2025-03-22 11:49:52.590862	2025-03-22 11:49:52.597776	\N	\N	\N	topup
55	1	1307	topup-8943108170005743815-1742644514	\N	created	\N	\N	0.45	2025-03-22 11:55:14.400141	2025-03-22 11:55:14.421169	\N	\N	\N	topup
56	1	1307	topup-8943108170005743815-1742644948	\N	created	\N	\N	0.45	2025-03-22 12:02:28.478179	2025-03-22 12:02:28.48181	\N	\N	\N	topup
57	1	1307	topup-8943108170005743815-1742644964	\N	created	\N	\N	0.45	2025-03-22 12:02:44.586081	2025-03-22 12:02:44.587609	\N	\N	\N	topup
58	1	1307	topup-8943108170005743815-1742645023	\N	created	\N	\N	0.45	2025-03-22 12:03:43.837262	2025-03-22 12:03:43.838896	\N	\N	\N	topup
59	1	1307	topup-8943108170005743815-1742645043	\N	created	\N	\N	0.45	2025-03-22 12:04:03.209702	2025-03-22 12:04:03.210984	\N	\N	\N	topup
60	1	1307	topup-8943108170005743815-1742645782	\N	created	\N	\N	0.45	2025-03-22 12:16:22.250327	2025-03-22 12:16:22.261038	\N	\N	\N	topup
61	1	1307	topup-8943108170005743815-1742645817	\N	created	\N	\N	0.45	2025-03-22 12:16:57.484263	2025-03-22 12:16:57.48834	\N	\N	\N	topup
62	1	1307	topup-8943108170005743815-1742645929	\N	created	\N	\N	0.45	2025-03-22 12:18:49.399313	2025-03-22 12:18:49.406291	\N	\N	\N	topup
63	1	1307	topup-8943108170005743815-1742645954	\N	created	\N	\N	0.45	2025-03-22 12:19:14.483451	2025-03-22 12:19:14.485922	\N	\N	\N	topup
64	1	1307	topup-8943108170005743815-1742647059	\N	created	\N	\N	0.45	2025-03-22 12:37:39.36132	2025-03-22 12:37:39.36995	\N	\N	\N	topup
65	1	1307	topup-8943108170005743815-1742647097	\N	created	\N	\N	0.45	2025-03-22 12:38:17.151786	2025-03-22 12:38:17.153128	\N	\N	\N	topup
66	1	1307	topup-8943108170005743815-1742647199	\N	created	\N	\N	0.45	2025-03-22 12:39:59.593294	2025-03-22 12:39:59.596785	\N	\N	\N	topup
67	1	1307	topup-8943108170005743815-1743026645	\N	created	\N	\N	0.45	2025-03-26 22:04:05.448748	2025-03-26 22:04:05.458081	\N	\N	\N	topup
68	1	1307	topup-8943108170005743815-1743027199	\N	created	\N	\N	0.45	2025-03-26 22:13:19.847448	2025-03-26 22:13:19.852868	\N	\N	\N	topup
69	1	1307	topup-8943108170005743815-1743027661	\N	created	\N	\N	0.45	2025-03-26 22:21:01.702397	2025-03-26 22:21:01.717134	\N	\N	\N	topup
70	1	1307	8f0b7dc7-cd87-43bf-9c03-f61dae84db1d	\N	canceled	ton	\N	0.45	2025-03-26 22:24:38.518758	2025-03-26 22:28:33.049348	22978013	\N	\N	new
71	1	1307	topup-8943108170005743815-1743028771	\N	created	\N	\N	0.45	2025-03-26 22:39:31.519873	2025-03-26 22:39:31.523817	\N	\N	\N	topup
72	1	1307	topup-8943108170005743815-1743029233	\N	created	\N	\N	0.45	2025-03-26 22:47:13.635456	2025-03-26 22:47:13.63767	\N	\N	\N	topup
73	1	1307	topup-8943108170005743815-1743029734	\N	created	\N	\N	0.45	2025-03-26 22:55:34.976608	2025-03-26 22:55:34.981373	\N	\N	\N	topup
74	1	1307	topup-8943108170005743815-1743029989	\N	created	\N	\N	0.45	2025-03-26 22:59:49.661533	2025-03-26 22:59:49.665063	\N	\N	\N	topup
75	1	1307	topup-8943108170005743815-1743030196	\N	created	\N	\N	0.45	2025-03-26 23:03:16.585927	2025-03-26 23:03:16.590464	\N	\N	\N	topup
76	1	1307	topup-8943108170005743815-1743030289	\N	created	\N	\N	0.45	2025-03-26 23:04:49.209434	2025-03-26 23:04:49.216846	\N	\N	\N	topup
77	1	1307	topup-8943108170005743815-1743031047	\N	created	\N	\N	0.45	2025-03-26 23:17:27.718502	2025-03-26 23:17:27.720045	\N	\N	\N	topup
78	1	1307	topup-8943108170005743815-1743031389	\N	created	\N	\N	0.45	2025-03-26 23:23:09.893103	2025-03-26 23:23:09.913701	\N	\N	\N	topup
79	1	1307	topup-8943108170005743815-1743063329	\N	created	\N	\N	0.45	2025-03-27 08:15:29.646367	2025-03-27 08:15:29.653112	\N	\N	\N	topup
80	1	1307	a98fb58f-7527-4acb-8fd8-d58388a4b1a5	\N	canceled	ton	\N	0.45	2025-04-02 20:46:16.059005	2025-04-02 20:47:39.793326	23369138	\N	\N	new
81	1	1307	78ccbe57-3cb6-424b-9fa0-821fc02f7f5d	\N	canceled	ton	\N	0.45	2025-04-02 20:54:40.072813	2025-04-02 20:57:07.569617	23369496	\N	\N	new
82	1	1307	60b2df74-370b-4dee-8e9d-431642ebc056	\N	canceled	ton	\N	0.45	2025-04-02 20:58:26.27937	2025-04-02 21:03:23.874225	23369652	\N	\N	new
83	1	1307	1f016731-67c0-436f-81ca-a2f27613f01b	\N	awaiting_payment	ton	\N	0.45	2025-04-02 21:19:10.900326	2025-04-02 21:19:12.166461	23370528	\N	\N	new
84	1	1307	20f45ce2-d7a0-4053-8950-c344c282c10b	\N	canceled	ton	\N	0.45	2025-04-02 21:29:10.264772	2025-04-02 21:32:42.889964	23370895	\N	\N	new
85	1	1307	a8cbac36-69dd-4565-b27e-7f4947647046	\N	awaiting_payment	ton	\N	0.45	2025-04-02 21:33:43.390789	2025-04-02 21:33:44.233276	23371050	\N	\N	new
86	1	1307	5a0c3507-46b8-4d96-9922-8133405dca43	\N	awaiting_payment	ton	\N	0.45	2025-04-02 21:37:26.200915	2025-04-02 21:37:26.985483	23371189	\N	\N	new
\.


--
-- Data for Name: packages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.packages (id, country_id, package_code, slug, name, data_amount, duration, price, description, is_available) FROM stdin;
2122	156	BA-6.0GB-15D-AIS002	ba-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2123	156	CKH531	ba-ckh531	1.0GB / 7 дней	1	7	4.6	Bosnia and Herzegovina 1GB 7Days	t
2124	156	CKH563	ba-ckh563	3.0GB / 15 дней	3	15	11.2	Bosnia and Herzegovina 3GB 15Days	t
2125	156	BA-1.0GB-7D-CKH823	ba-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2142	157	BW-1.0GB-7D-CKH823	bw-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2143	157	BW-5.0GB-30D-CKH825	bw-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2144	157	BW-10.0GB-30D-CKH826	bw-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2145	157	BW-3.0GB-30D-P1XXDOD0C	bw-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2146	157	BW-3.0GB-30D-PHD8GZ2VN	bw-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2147	157	BW-20.0GB-90D-PG3K0LHBC	bw-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2148	157	BW-1.0GB-365D-PCQXBW5UJ	bw-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2149	157	BW-1.0GB-7D-PHS30M6EZ	bw-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2150	157	BW-1.0GB-365D-PYMC5N31Z	bw-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2151	157	BW-5.0GB-30D-PEW54FVD9	bw-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2152	157	BW-3.0GB-30D-PW6P3DX2G	bw-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2153	157	BW-20.0GB-90D-PB83STJL6	bw-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2192	159	BG-10.0GB-30D-P50GVS8GN	bg-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2206	159	BG-3.0GB-1D-PE01DJZS7	bg-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
2207	159	BG-0.5GB-1D-P61RQP7ZW	bg-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2208	159	BG-0.3GB-1D-P82Y6VYRL	bg-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2209	160	BF-1.0GB-7D-CKH495	bf-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2210	160	BF-5.0GB-30D-CKH497	bf-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2211	160	CKH521	bf-ckh521	1.0GB / 7 дней	1	7	7.1	Burkina Faso 1GB 7Days	t
2212	160	CKH572	bf-ckh572	3.0GB / 15 дней	3	15	17.6	Burkina Faso 3GB 15Days	t
2213	160	CKH573	bf-ckh573	5.0GB / 30 дней	5	30	26	Burkina Faso 5GB 30Days	t
2214	160	BF-1.0GB-7D-CKH823	bf-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2215	160	BF-5.0GB-30D-CKH825	bf-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2216	160	BF-10.0GB-30D-CKH826	bf-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2217	160	BF-3.0GB-30D-P1XXDOD0C	bf-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2218	160	BF-3.0GB-30D-PHD8GZ2VN	bf-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2219	160	BF-20.0GB-90D-PG3K0LHBC	bf-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2220	160	BF-1.0GB-365D-PCQXBW5UJ	bf-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2233	161	KH-10.0GB-30D-JC168	kh-jc168	10.0GB / 30 дней	10	30	12.2	Asia (7 areas) 10GB 30Days	t
2234	161	KH-20.0GB-30D-JC169	kh-jc169	20.0GB / 30 дней	20	30	20	Asia (7 areas) 20GB 30Days	t
2235	161	KH-1.0GB-30D-JC177	kh-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
2251	161	KH-0.5GB-1D-PX5NT8Z4K	kh-px5nt8z4k	0.49GB / 1 дней	0.49	1	0.9	Asia (7 areas) 500MB/Day	t
1690	298	ZM-20.0GB-90D-PG3K0LHBC	zm-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1691	298	ZM-1.0GB-365D-PCQXBW5UJ	zm-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1692	298	ZM-1.0GB-7D-PHS30M6EZ	zm-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1693	298	ZM-1.0GB-365D-PYMC5N31Z	zm-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1694	298	ZM-5.0GB-30D-PEW54FVD9	zm-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1695	298	ZM-3.0GB-30D-PW6P3DX2G	zm-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1696	298	ZM-20.0GB-90D-PB83STJL6	zm-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1697	298	ZM-20.0GB-30D-PR3JZMC20	zm-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1698	298	ZM-10.0GB-30D-P34FHRF8J	zm-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1718	300	AX-1.0GB-365D-PCQXBW5UJ	ax-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1722	139	!RG-10.0GB-30D-CKH486	!rg-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1723	139	!RG-1.0GB-7D-CKH487	!rg-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
1724	139	!RG-3.0GB-15D-CKH488	!rg-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
1725	139	!RG-5.0GB-30D-CKH489	!rg-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
1726	139	!RG-10.0GB-30D-CKH490	!rg-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
1727	139	!RG-1.0GB-7D-CKH491	!rg-ckh491	1.0GB / 7 дней	1	7	2.3	North America 1GB 7Days	t
1728	139	!RG-5.0GB-30D-CKH493	!rg-ckh493	5.0GB / 30 дней	5	30	8.8	North America 5GB 30Days	t
1729	139	!RG-10.0GB-30D-CKH494	!rg-ckh494	10.0GB / 30 дней	10	30	15.2	North America 10GB 30Days	t
1730	139	!RG-1.0GB-7D-CKH495	!rg-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1731	139	!RG-5.0GB-30D-CKH497	!rg-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1732	139	!RG-6.0GB-8D-AIS001	!rg-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
2252	161	KH-2.0GB-1D-PBZUB2S60	kh-pbzub2s60	2.0GB / 1 дней	2	1	3	Asia (7 areas) 2GB/Day	t
2253	161	KH-5.0GB-1D-PJ2W7KTJ4	kh-pj2w7ktj4	5.0GB / 1 дней	5	1	6	Asia (7 areas) 5GB/Day	t
2254	162	CKH526	cm-ckh526	1.0GB / 7 дней	1	7	7.1	Cameroon 1GB 7Days	t
2255	162	CKH575	cm-ckh575	3.0GB / 15 дней	3	15	17.6	Cameroon 3GB 15Days	t
2256	162	CM-1.0GB-7D-CKH823	cm-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2257	162	CM-5.0GB-30D-CKH825	cm-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2258	162	CM-10.0GB-30D-CKH826	cm-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2259	162	CM-3.0GB-30D-PHD8GZ2VN	cm-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2260	162	CM-20.0GB-90D-PG3K0LHBC	cm-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2261	162	CM-1.0GB-365D-PCQXBW5UJ	cm-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2262	162	CM-1.0GB-7D-PHS30M6EZ	cm-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2263	162	CM-1.0GB-365D-PYMC5N31Z	cm-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2264	162	CM-5.0GB-30D-PEW54FVD9	cm-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2265	162	CM-3.0GB-30D-PW6P3DX2G	cm-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2266	162	CM-20.0GB-90D-PB83STJL6	cm-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2267	162	CM-20.0GB-30D-PR3JZMC20	cm-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2268	162	CM-10.0GB-30D-P34FHRF8J	cm-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2309	166	CKH302	cl-ckh302	1.0GB / 7 дней	1	7	5.7	Chile 1GB 7Days	t
2310	166	CKH318	cl-ckh318	3.0GB / 15 дней	3	15	14.1	Chile 3GB 15Days	t
2311	166	CL-1.0GB-7D-CKH487	cl-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
2312	166	CL-3.0GB-15D-CKH488	cl-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
2313	166	CL-5.0GB-30D-CKH489	cl-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2314	166	CL-10.0GB-30D-CKH490	cl-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
2315	166	CL-6.0GB-15D-AIS002	cl-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2316	166	CL-1.0GB-7D-CKH823	cl-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2317	166	CL-5.0GB-30D-CKH825	cl-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2318	166	CL-10.0GB-30D-CKH826	cl-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2319	166	CL-3.0GB-30D-P6FNJUAP4	cl-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
2320	166	CL-3.0GB-30D-PHD8GZ2VN	cl-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2321	166	CL-20.0GB-90D-PG3K0LHBC	cl-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2322	166	CL-1.0GB-365D-PCQXBW5UJ	cl-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2344	167	CO-1.0GB-7D-PHS30M6EZ	co-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1757	139	!RG-50.0GB-180D-PGXJN6W2T	!rg-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1758	139	!RG-20.0GB-90D-PVF7RTI3Y	!rg-pvf7rti3y	20.0GB / 90 дней	20	90	27	North America 20GB 90Days	t
1759	139	!RG-50.0GB-180D-POGTY0THV	!rg-pogty0thv	50.0GB / 180 дней	50	180	58	North America 50GB 180Days	t
1760	139	!RG-3.0GB-30D-PNEKXVZKV	!rg-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
1761	139	!RG-50.0GB-180D-PJKYY3QTL	!rg-pjkyy3qtl	50.0GB / 180 дней	50	180	37	China (mainland HK Macao) 50GB 180Days	t
1762	139	!RG-50.0GB-180D-P4GNDNA36	!rg-p4gndna36	50.0GB / 180 дней	50	180	45	Asia (7 areas) 50GB 180Days	t
1763	139	!RG-1.0GB-1D-PCTEPKHJW	!rg-pctepkhjw	1.0GB / 1 дней	1	1	2.2	North America 1GB/Day	t
1764	139	!RG-1.5GB-1D-P5SQ1FXCQ	!rg-p5sq1fxcq	1.5GB / 1 дней	1.5	1	3.2	North America 1.5GB/Day	t
1765	139	!RG-2.0GB-1D-PWTRNZF6E	!rg-pwtrnzf6e	2.0GB / 1 дней	2	1	4.3	North America 2GB/Day	t
1766	139	!RG-1.0GB-30D-PWTE0W1Q4	!rg-pwte0w1q4	1.0GB / 30 дней	1	30	2.5	North America 1GB 30Days	t
1767	139	!RG-3.0GB-30D-PZ8NV3QK9	!rg-pz8nv3qk9	3.0GB / 30 дней	3	30	3	Singapore & Malaysia & Thailand 3GB 30Days	t
1768	139	!RG-5.0GB-30D-PYX2W95MR	!rg-pyx2w95mr	5.0GB / 30 дней	5	30	4.4	Singapore & Malaysia & Thailand 5GB 30Days	t
1769	139	!RG-10.0GB-30D-PY5TK3XX6	!rg-py5tk3xx6	10.0GB / 30 дней	10	30	7.6	Singapore & Malaysia & Thailand 10GB 30Days	t
1770	139	!RG-20.0GB-30D-P9NV1LJN6	!rg-p9nv1ljn6	20.0GB / 30 дней	20	30	12.9	Singapore & Malaysia & Thailand 20GB 30Days	t
1771	139	!RG-1.0GB-30D-PM1HX6ES9	!rg-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
1772	139	!RG-3.0GB-30D-PJK6T8JT2	!rg-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
1773	139	!RG-5.0GB-30D-P87F6RTKY	!rg-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
1774	139	!RG-1.0GB-7D-PV048NCRG	!rg-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
1775	139	!RG-10.0GB-30D-P50GVS8GN	!rg-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
1776	139	!RG-20.0GB-30D-PHC4X21NC	!rg-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
1777	139	!RG-20.0GB-90D-P5NWWU08G	!rg-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
1778	139	!RG-50.0GB-180D-PE70MYRZ5	!rg-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
1779	139	!RG-1.0GB-1D-PUDV52A3R	!rg-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
1780	139	!RG-1.5GB-1D-P34CJYA6C	!rg-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
430	5	IT-3.0GB-30D-CKH006	it-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
431	5	IT-5.0GB-30D-CKH007	it-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
432	5	CKH091	it-ckh091	3.0GB / 30 дней	3	30	2.3	Italy 3GB 30Days	t
433	5	CKH130	it-ckh130	5.0GB / 30 дней	5	30	3.4	Italy 5GB 30Days	t
434	5	CKH227	it-ckh227	1.0GB / 7 дней	1	7	0.9	Italy 1GB 7Days	t
435	5	CKH228	it-ckh228	3.0GB / 15 дней	3	15	2.2	Italy 3GB 15Days	t
445	5	IT-20.0GB-90D-P7VCE7FKY	it-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
446	5	IT-50.0GB-180D-PGXJN6W2T	it-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
447	5	PX1CNITSE	it-px1cnitse	50.0GB / 180 дней	50	180	22	Italy 50GB 180Days	t
448	5	IT-3.0GB-30D-PHD8GZ2VN	it-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
449	5	IT-20.0GB-90D-PG3K0LHBC	it-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
450	5	IT-1.0GB-365D-PCQXBW5UJ	it-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
451	5	IT-1.0GB-30D-PM1HX6ES9	it-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
452	5	IT-3.0GB-30D-PJK6T8JT2	it-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
453	5	IT-5.0GB-30D-P87F6RTKY	it-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
454	5	IT-1.0GB-7D-PV048NCRG	it-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
455	5	IT-10.0GB-30D-P50GVS8GN	it-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
456	5	IT-20.0GB-30D-PHC4X21NC	it-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
457	5	IT-20.0GB-90D-P5NWWU08G	it-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2345	167	CO-1.0GB-365D-PYMC5N31Z	co-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2346	167	CO-5.0GB-30D-PEW54FVD9	co-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2347	167	CO-3.0GB-30D-PW6P3DX2G	co-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2348	167	CO-20.0GB-90D-PB83STJL6	co-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2349	167	CO-20.0GB-30D-PR3JZMC20	co-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2350	167	CO-10.0GB-30D-P34FHRF8J	co-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2358	168	MB023	cg-mb023	1.0GB / 7 дней	1	7	5.7	Congo 1GB 7Days	t
2359	168	MB028	cg-mb028	3.0GB / 15 дней	3	15	14.1	Congo 3GB 15Days	t
2360	168	MB033	cg-mb033	5.0GB / 30 дней	5	30	21	Congo 5GB 30Days	t
2361	168	CG-1.0GB-7D-CKH495	cg-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2362	168	CG-5.0GB-30D-CKH497	cg-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2363	168	CG-6.0GB-15D-AIS002	cg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3959	239	MS-3.0GB-30D-PQB69VW8U	ms-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
3960	239	MS-1.0GB-7D-PUSHF5X80	ms-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
3970	240	MA-3.0GB-30D-PHD8GZ2VN	ma-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3971	240	MA-20.0GB-90D-PG3K0LHBC	ma-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4036	245	JC031	nz-jc031	1.0GB / 7 дней	1	7	1.8	New Zealand 1GB 7Days	t
4037	245	JC032	nz-jc032	3.0GB / 15 дней	3	15	4.6	New Zealand 3GB 15Days	t
4038	245	JC033	nz-jc033	5.0GB / 30 дней	5	30	7	New Zealand 5GB 30Days	t
4039	245	JC082	nz-jc082	10.0GB / 30 дней	10	30	12.2	New Zealand 10GB 30Days	t
4040	245	NZ-6.0GB-15D-AIS002	nz-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4041	245	NZ-1.0GB-7D-CKH823	nz-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4042	245	NZ-5.0GB-30D-CKH825	nz-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4043	245	NZ-10.0GB-30D-CKH826	nz-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4044	245	NZ-1.0GB-30D-JC177	nz-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
4045	245	NZ-5.0GB-30D-JC178	nz-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
4046	245	NZ-3.0GB-15D-JC179	nz-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
4047	245	NZ-10.0GB-30D-JC180	nz-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
4048	245	NZ-20.0GB-90D-JC181	nz-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
4049	245	NZ-50.0GB-180D-JC182	nz-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
4050	245	NZ-1.0GB-7D-JC183	nz-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
4051	245	NZ-3.0GB-30D-PHD8GZ2VN	nz-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4052	245	NZ-20.0GB-90D-PG3K0LHBC	nz-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4053	245	P0FPKFWXZ	nz-p0fpkfwxz	20.0GB / 30 дней	20	30	20	New Zealand 20GB 30Days	t
4054	245	PEIHJAQVY	nz-peihjaqvy	50.0GB / 180 дней	50	180	45	New Zealand 50GB 180Days	t
4055	245	NZ-1.0GB-365D-PCQXBW5UJ	nz-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4056	245	PN7CXKOWL	nz-pn7cxkowl	0.49GB / 1 дней	0.49	1	0.8	New Zealand 500MB/Day	t
4057	245	PDLIRFGHE	nz-pdlirfghe	1.0GB / 1 дней	1	1	1.5	New Zealand 1GB/Day	t
4058	245	NZ-1.0GB-7D-PHS30M6EZ	nz-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4059	245	NZ-1.0GB-365D-PYMC5N31Z	nz-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2384	169	CD-3.0GB-30D-P1XXDOD0C	cd-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2385	169	CD-3.0GB-30D-PHD8GZ2VN	cd-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2386	169	CD-20.0GB-90D-PG3K0LHBC	cd-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2387	169	CD-1.0GB-365D-PCQXBW5UJ	cd-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2388	169	CD-1.0GB-7D-PHS30M6EZ	cd-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2389	169	CD-1.0GB-365D-PYMC5N31Z	cd-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2390	169	CD-5.0GB-30D-PEW54FVD9	cd-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2391	169	CD-3.0GB-30D-PW6P3DX2G	cd-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2392	169	CD-20.0GB-90D-PB83STJL6	cd-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2393	169	CD-20.0GB-30D-PR3JZMC20	cd-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2394	169	CD-10.0GB-30D-P34FHRF8J	cd-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2411	170	CR-5.0GB-30D-PEW54FVD9	cr-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2416	171	HR-3.0GB-30D-CKH006	hr-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2417	171	HR-5.0GB-30D-CKH007	hr-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2418	171	CKH079	hr-ckh079	3.0GB / 30 дней	3	30	2.3	Croatia 3GB 30Days	t
2419	171	CKH118	hr-ckh118	5.0GB / 30 дней	5	30	3.4	Croatia 5GB 30Days	t
2436	171	HR-1.0GB-365D-PCQXBW5UJ	hr-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
476	6	CKH002	es-ckh002	3.0GB / 30 дней	3	30	2.3	Spain 3GB 30Days	t
477	6	CKH003	es-ckh003	5.0GB / 30 дней	5	30	3.4	Spain 5GB 30Days	t
478	6	ES-3.0GB-30D-CKH006	es-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
479	6	ES-5.0GB-30D-CKH007	es-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2437	171	HR-1.0GB-30D-PM1HX6ES9	hr-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2443	171	HR-20.0GB-90D-P5NWWU08G	hr-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
480	6	CKH245	es-ckh245	1.0GB / 7 дней	1	7	0.9	Spain 1GB 7Days	t
481	6	CKH246	es-ckh246	3.0GB / 15 дней	3	15	2.2	Spain 3GB 15Days	t
1820	139	!RG-1.0GB-1D-P0N8SUBG5	!rg-p0n8subg5	1.0GB / 1 дней	1	1	1.7	Asia (7 areas) 1GB/Day	t
1821	139	!RG-0.5GB-1D-PX5NT8Z4K	!rg-px5nt8z4k	0.49GB / 1 дней	0.49	1	0.9	Asia (7 areas) 500MB/Day	t
1822	139	!RG-2.0GB-1D-PBZUB2S60	!rg-pbzub2s60	2.0GB / 1 дней	2	1	3	Asia (7 areas) 2GB/Day	t
1823	139	!RG-5.0GB-1D-PJ2W7KTJ4	!rg-pj2w7ktj4	5.0GB / 1 дней	5	1	6	Asia (7 areas) 5GB/Day	t
1824	139	!RG-1.0GB-7D-P86Y3TMFZ	!rg-p86y3tmfz	1.0GB / 7 дней	1	7	1.1	Singapore & Malaysia & Thailand 1GB 7Days	t
1825	139	!RG-3.0GB-15D-P71Q4REAB	!rg-p71q4reab	3.0GB / 15 дней	3	15	2.8	Singapore & Malaysia & Thailand 3GB 15Days	t
1826	139	!RG-0.5GB-1D-PB9B7RVL0	!rg-pb9b7rvl0	0.49GB / 1 дней	0.49	1	0.6	Singapore & Malaysia & Thailand 500MB/Day	t
1850	141	AL-1.0GB-365D-PYMC5N31Z	al-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1851	141	AL-5.0GB-30D-PEW54FVD9	al-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1852	141	AL-3.0GB-30D-PW6P3DX2G	al-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1853	141	AL-20.0GB-90D-PB83STJL6	al-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1854	141	AL-20.0GB-30D-PR3JZMC20	al-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1855	141	AL-10.0GB-30D-P34FHRF8J	al-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1884	145	AR-1.0GB-7D-CKH487	ar-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
1885	145	AR-3.0GB-15D-CKH488	ar-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
1886	145	AR-5.0GB-30D-CKH489	ar-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
1887	145	AR-10.0GB-30D-CKH490	ar-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
1888	145	AR-1.0GB-7D-CKH823	ar-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1889	145	AR-5.0GB-30D-CKH825	ar-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1890	145	AR-10.0GB-30D-CKH826	ar-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1891	145	CKH858	ar-ckh858	20.0GB / 30 дней	20	30	40	Argentina 20GB 30Days	t
1892	145	AR-3.0GB-30D-P6FNJUAP4	ar-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
1893	145	AR-3.0GB-30D-PHD8GZ2VN	ar-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1894	145	AR-20.0GB-90D-PG3K0LHBC	ar-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1895	145	AR-1.0GB-365D-PCQXBW5UJ	ar-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1896	145	AR-1.0GB-7D-PHS30M6EZ	ar-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1897	145	AR-1.0GB-365D-PYMC5N31Z	ar-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1898	145	AR-5.0GB-30D-PEW54FVD9	ar-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1899	145	AR-3.0GB-30D-PW6P3DX2G	ar-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1900	145	AR-20.0GB-90D-PB83STJL6	ar-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1901	145	AR-20.0GB-30D-PR3JZMC20	ar-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2444	171	HR-50.0GB-180D-PE70MYRZ5	hr-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
2445	171	HR-1.0GB-1D-PUDV52A3R	hr-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
1902	145	AR-10.0GB-30D-P34FHRF8J	ar-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1903	145	AR-5.0GB-1D-PX18HJ4XW	ar-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1904	145	AR-1.0GB-1D-P8JCL47FC	ar-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
1905	145	AR-0.5GB-1D-PX2WSA7L1	ar-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1906	145	AR-10.0GB-30D-PCHZ59M2J	ar-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1907	145	AR-5.0GB-30D-P7GA02CZP	ar-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1908	145	AR-3.0GB-30D-PQB69VW8U	ar-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1909	145	AR-1.0GB-7D-PUSHF5X80	ar-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1910	145	P0VDPD9F2	ar-p0vdpd9f2	1.0GB / 1 дней	1	1	3.4		t
1944	147	AT-1.0GB-7D-CKH823	at-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1945	147	AT-5.0GB-30D-CKH825	at-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1946	147	AT-10.0GB-30D-CKH826	at-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1947	147	AT-20.0GB-90D-P7VCE7FKY	at-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1948	147	AT-50.0GB-180D-PGXJN6W2T	at-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1949	147	PJG7CZ02I	at-pjg7cz02i	50.0GB / 180 дней	50	180	22	Austria 50GB 180Days	t
2446	171	HR-1.5GB-1D-P34CJYA6C	hr-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2447	171	HR-1.0GB-7D-PHS30M6EZ	hr-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2448	171	HR-1.0GB-365D-PYMC5N31Z	hr-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2449	171	HR-5.0GB-30D-PEW54FVD9	hr-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2450	171	HR-3.0GB-30D-PW6P3DX2G	hr-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2451	171	HR-20.0GB-90D-PB83STJL6	hr-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2462	172	CKH208	cy-ckh208	1.0GB / 7 дней	1	7	0.9	Cyprus 1GB 7Days	t
2463	172	CKH209	cy-ckh209	3.0GB / 15 дней	3	15	2.2	Cyprus 3GB 15Days	t
2464	172	CKH210	cy-ckh210	10.0GB / 30 дней	10	30	6.1	Cyprus 10GB 30Days	t
2465	172	CY-1.0GB-7D-CKH484	cy-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2466	172	CY-10.0GB-30D-CKH486	cy-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2467	172	CY-20.0GB-30D-CKH500	cy-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2468	172	CY-6.0GB-15D-AIS002	cy-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2469	172	CY-1.0GB-7D-CKH823	cy-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2470	172	CY-5.0GB-30D-CKH825	cy-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2499	173	CZ-3.0GB-30D-CKH006	cz-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2500	173	CZ-5.0GB-30D-CKH007	cz-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2501	173	CKH081	cz-ckh081	3.0GB / 30 дней	3	30	2.3	Czech Republic 3GB 30Days	t
2502	173	CKH120	cz-ckh120	5.0GB / 30 дней	5	30	3.4	Czech Republic 5GB 30Days	t
2503	173	CKH163	cz-ckh163	1.0GB / 7 дней	1	7	0.9	Czech Republic 1GB 7Days	t
2504	173	CKH164	cz-ckh164	3.0GB / 15 дней	3	15	2.2	Czech Republic 3GB 15Days	t
2505	173	CKH165	cz-ckh165	10.0GB / 30 дней	10	30	6.1	Czech Republic 10GB 30Days	t
4060	245	NZ-5.0GB-30D-PEW54FVD9	nz-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4061	245	NZ-3.0GB-30D-PW6P3DX2G	nz-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4067	246	CKH311	ni-ckh311	1.0GB / 7 дней	1	7	4.6	Nicaragua 1GB 7Days	t
4068	246	CKH327	ni-ckh327	3.0GB / 15 дней	3	15	11.2	Nicaragua 3GB 15Days	t
4069	246	NI-1.0GB-7D-CKH487	ni-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
4070	246	NI-3.0GB-15D-CKH488	ni-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
4071	246	NI-5.0GB-30D-CKH489	ni-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
4084	246	NI-3.0GB-30D-PW6P3DX2G	ni-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4085	246	NI-20.0GB-90D-PB83STJL6	ni-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4086	246	NI-20.0GB-30D-PR3JZMC20	ni-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4087	246	NI-10.0GB-30D-P34FHRF8J	ni-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4093	247	NE-5.0GB-30D-CKH825	ne-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4094	247	NE-10.0GB-30D-CKH826	ne-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4095	247	NE-3.0GB-30D-P1XXDOD0C	ne-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
4096	247	NE-3.0GB-30D-PHD8GZ2VN	ne-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4097	247	NE-20.0GB-90D-PG3K0LHBC	ne-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4098	247	NE-1.0GB-365D-PCQXBW5UJ	ne-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4099	247	NE-1.0GB-7D-PHS30M6EZ	ne-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4100	247	NE-1.0GB-365D-PYMC5N31Z	ne-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4101	247	NE-5.0GB-30D-PEW54FVD9	ne-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4102	247	NE-3.0GB-30D-PW6P3DX2G	ne-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4103	247	NE-20.0GB-90D-PB83STJL6	ne-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2506	173	CZ-1.0GB-7D-CKH484	cz-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2507	173	CZ-10.0GB-30D-CKH486	cz-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2508	173	CZ-20.0GB-30D-CKH500	cz-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2509	173	CZ-6.0GB-15D-AIS002	cz-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2510	173	CKH541	cz-ckh541	20.0GB / 30 дней	20	30	10.6	Czech Republic 20GB 30Days	t
2511	173	CZ-1.0GB-7D-CKH823	cz-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2512	173	CZ-5.0GB-30D-CKH825	cz-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2513	173	CZ-10.0GB-30D-CKH826	cz-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2514	173	CZ-20.0GB-90D-P7VCE7FKY	cz-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2515	173	CZ-50.0GB-180D-PGXJN6W2T	cz-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2516	173	PVFLCUSP6	cz-pvflcusp6	50.0GB / 180 дней	50	180	30	Czech Republic 50GB 180Days	t
2517	173	CZ-3.0GB-30D-PHD8GZ2VN	cz-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2518	173	CZ-20.0GB-90D-PG3K0LHBC	cz-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2519	173	CZ-1.0GB-365D-PCQXBW5UJ	cz-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2520	173	CZ-1.0GB-30D-PM1HX6ES9	cz-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2521	173	CZ-3.0GB-30D-PJK6T8JT2	cz-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2522	173	CZ-5.0GB-30D-P87F6RTKY	cz-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2523	173	CZ-1.0GB-7D-PV048NCRG	cz-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2524	173	CZ-10.0GB-30D-P50GVS8GN	cz-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2525	173	CZ-20.0GB-30D-PHC4X21NC	cz-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2541	174	CKH374	ci-ckh374	1.0GB / 7 дней	1	7	7.1	Cote d'Ivoire 1GB 7Days	t
2542	174	CKH403	ci-ckh403	3.0GB / 15 дней	3	15	17.6	Cote d'Ivoire 3GB 15Days	t
2543	174	CKH432	ci-ckh432	5.0GB / 30 дней	5	30	26	Cote d'Ivoire 5GB 30Days	t
2544	174	CI-1.0GB-7D-CKH495	ci-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2545	174	CI-5.0GB-30D-CKH497	ci-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2546	174	CI-1.0GB-7D-CKH823	ci-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4104	247	NE-20.0GB-30D-PR3JZMC20	ne-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1950	147	AT-3.0GB-30D-PHD8GZ2VN	at-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1951	147	AT-20.0GB-90D-PG3K0LHBC	at-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1952	147	AT-1.0GB-365D-PCQXBW5UJ	at-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1953	147	AT-1.0GB-30D-PM1HX6ES9	at-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
1954	147	AT-3.0GB-30D-PJK6T8JT2	at-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
1955	147	AT-5.0GB-30D-P87F6RTKY	at-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
1956	147	AT-1.0GB-7D-PV048NCRG	at-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
1957	147	AT-10.0GB-30D-P50GVS8GN	at-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
1958	147	AT-20.0GB-30D-PHC4X21NC	at-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
1959	147	AT-20.0GB-90D-P5NWWU08G	at-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
1960	147	AT-50.0GB-180D-PE70MYRZ5	at-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
1961	147	AT-1.0GB-1D-PUDV52A3R	at-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
1962	147	AT-1.5GB-1D-P34CJYA6C	at-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
1963	147	AT-1.0GB-7D-PHS30M6EZ	at-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1964	147	AT-1.0GB-365D-PYMC5N31Z	at-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1965	147	AT-5.0GB-30D-PEW54FVD9	at-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1966	147	AT-3.0GB-30D-PW6P3DX2G	at-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1967	147	AT-20.0GB-90D-PB83STJL6	at-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1968	147	AT-20.0GB-30D-PR3JZMC20	at-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1969	147	AT-10.0GB-30D-P34FHRF8J	at-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1970	147	AT-2.0GB-1D-PZ6R8ASH9	at-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
1971	147	AT-3.0GB-1D-PE01DJZS7	at-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
1972	147	AT-0.5GB-1D-P61RQP7ZW	at-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
1973	147	AT-0.3GB-1D-P82Y6VYRL	at-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2003	149	BH-5.0GB-30D-CKH850	bh-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
2004	149	BH-3.0GB-30D-PHD8GZ2VN	bh-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2005	149	BH-20.0GB-90D-PG3K0LHBC	bh-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2006	149	BH-3.0GB-30D-PNEKXVZKV	bh-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
2007	149	BH-1.0GB-365D-PCQXBW5UJ	bh-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2008	149	PS4XW6D9Y	bh-ps4xw6d9y	0.49GB / 1 дней	0.49	1	2.25	Bahrain 500MB/Day	t
2547	174	CI-5.0GB-30D-CKH825	ci-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2548	174	CI-10.0GB-30D-CKH826	ci-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2549	174	CI-3.0GB-30D-P1XXDOD0C	ci-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2550	174	CI-3.0GB-30D-PHD8GZ2VN	ci-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2551	174	CI-20.0GB-90D-PG3K0LHBC	ci-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2552	174	CI-1.0GB-365D-PCQXBW5UJ	ci-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2553	174	CI-1.0GB-7D-PHS30M6EZ	ci-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2573	175	DK-5.0GB-30D-CKH825	dk-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2574	175	DK-10.0GB-30D-CKH826	dk-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2575	175	DK-20.0GB-90D-P7VCE7FKY	dk-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2576	175	DK-50.0GB-180D-PGXJN6W2T	dk-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2577	175	PJJEKFZJ0	dk-pjjekfzj0	50.0GB / 180 дней	50	180	22	Denmark 50GB 180Days	t
2602	176	DM-5.0GB-1D-PX18HJ4XW	dm-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2603	176	DM-1.0GB-1D-P8JCL47FC	dm-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2604	176	DM-0.5GB-1D-PX2WSA7L1	dm-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
2605	176	DM-10.0GB-30D-PCHZ59M2J	dm-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
2606	176	DM-5.0GB-30D-P7GA02CZP	dm-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2607	176	DM-3.0GB-30D-PQB69VW8U	dm-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2608	176	DM-1.0GB-7D-PUSHF5X80	dm-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2617	177	DO-10.0GB-30D-PCHZ59M2J	do-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
2618	177	DO-5.0GB-30D-P7GA02CZP	do-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2619	177	DO-3.0GB-30D-PQB69VW8U	do-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2620	177	DO-1.0GB-7D-PUSHF5X80	do-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2634	178	EC-1.0GB-365D-PCQXBW5UJ	ec-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
997	179	PK564ELYK	eg-pk564elyk	1.0GB / 1 дней	1	1	1.9	Egypt 1GB/Day	t
998	179	P6XTH0M8D	eg-p6xth0m8d	0.49GB / 1 дней	0.49	1	1.1	Egypt 500MB/Day	t
2663	181	EE-3.0GB-30D-CKH006	ee-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2664	181	EE-5.0GB-30D-CKH007	ee-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2665	181	CKH083	ee-ckh083	3.0GB / 30 дней	3	30	2.3	Estonia 3GB 30Days	t
2666	181	CKH122	ee-ckh122	5.0GB / 30 дней	5	30	3.4	Estonia 5GB 30Days	t
4105	247	NE-10.0GB-30D-P34FHRF8J	ne-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4125	249	MK-3.0GB-30D-CKH006	mk-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
4126	249	MK-5.0GB-30D-CKH007	mk-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
4142	249	MK-1.0GB-7D-PHS30M6EZ	mk-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4143	249	MK-1.0GB-365D-PYMC5N31Z	mk-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4144	249	MK-5.0GB-30D-PEW54FVD9	mk-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4145	249	MK-3.0GB-30D-PW6P3DX2G	mk-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4151	250	CKH982	no-ckh982	3.0GB / 30 дней	3	30	1.8	Norway 3GB 30Days	t
4152	250	CKH988	no-ckh988	5.0GB / 30 дней	5	30	2.7	Norway 5GB 30Days	t
4153	250	CKH999	no-ckh999	1.0GB / 7 дней	1	7	0.7	Norway 1GB 7Days	t
4154	250	CKH1000	no-ckh1000	3.0GB / 15 дней	3	15	1.7	Norway 3GB 15Days	t
2009	149	PU3UL09EV	bh-pu3ul09ev	1.0GB / 1 дней	1	1	4.5	Bahrain 1GB/Day	t
2010	149	PCF04T9CZ	bh-pcf04t9cz	2.0GB / 1 дней	2	1	8.9	Bahrain 2GB/Day	t
2011	149	PX05WUEX1	bh-px05wuex1	3.0GB / 1 дней	3	1	11.1	Bahrain 3GB/Day	t
2012	149	BH-10.0GB-1D-PLR26GSE7	bh-plr26gse7	10.0GB / 1 дней	10	1	22	Gulf Region 10GB/Day	t
2013	149	BH-5.0GB-1D-PLK713DWL	bh-plk713dwl	5.0GB / 1 дней	5	1	10.8	Gulf Region 5GB/Day	t
2061	153	BE-1.0GB-7D-CKH823	be-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2062	153	BE-5.0GB-30D-CKH825	be-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2063	153	BE-10.0GB-30D-CKH826	be-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2064	153	BE-20.0GB-90D-P7VCE7FKY	be-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2065	153	BE-50.0GB-180D-PGXJN6W2T	be-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2066	153	PJ4UJHAJC	be-pj4ujhajc	50.0GB / 180 дней	50	180	22	Belgium 50GB 180Days	t
2067	153	BE-3.0GB-30D-PHD8GZ2VN	be-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2068	153	BE-20.0GB-90D-PG3K0LHBC	be-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2069	153	BE-1.0GB-365D-PCQXBW5UJ	be-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2070	153	BE-1.0GB-30D-PM1HX6ES9	be-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2071	153	BE-3.0GB-30D-PJK6T8JT2	be-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2126	156	BA-5.0GB-30D-CKH825	ba-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2127	156	BA-10.0GB-30D-CKH826	ba-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2128	156	BA-3.0GB-30D-PHD8GZ2VN	ba-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2129	156	BA-20.0GB-90D-PG3K0LHBC	ba-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2130	156	BA-1.0GB-365D-PCQXBW5UJ	ba-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2131	156	BA-1.0GB-7D-PHS30M6EZ	ba-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2132	156	BA-1.0GB-365D-PYMC5N31Z	ba-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2133	156	BA-5.0GB-30D-PEW54FVD9	ba-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2134	156	BA-3.0GB-30D-PW6P3DX2G	ba-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2135	156	BA-20.0GB-90D-PB83STJL6	ba-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2136	156	BA-20.0GB-30D-PR3JZMC20	ba-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2137	156	BA-10.0GB-30D-P34FHRF8J	ba-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2154	157	BW-20.0GB-30D-PR3JZMC20	bw-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2155	157	BW-10.0GB-30D-P34FHRF8J	bw-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2178	159	BG-6.0GB-15D-AIS002	bg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2179	159	BG-1.0GB-7D-CKH823	bg-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
944	12	BR-1.0GB-7D-CKH823	br-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
945	12	BR-5.0GB-30D-CKH825	br-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
946	12	BR-10.0GB-30D-CKH826	br-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
947	12	CKH860	br-ckh860	20.0GB / 30 дней	20	30	25	Brazil 20GB 30Days	t
948	12	P6FNJUAP4	br-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
949	12	BR-3.0GB-30D-PHD8GZ2VN	br-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
950	12	BR-20.0GB-90D-PG3K0LHBC	br-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
951	12	BR-1.0GB-365D-PCQXBW5UJ	br-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
952	12	BR-1.0GB-7D-PHS30M6EZ	br-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
967	12	PQB69VW8U	br-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2119	155	BO-5.0GB-30D-P7GA02CZP	bo-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2120	155	BO-3.0GB-30D-PQB69VW8U	bo-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2121	155	BO-1.0GB-7D-PUSHF5X80	bo-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2180	159	BG-5.0GB-30D-CKH825	bg-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2181	159	BG-10.0GB-30D-CKH826	bg-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2182	159	BG-20.0GB-90D-P7VCE7FKY	bg-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2183	159	BG-50.0GB-180D-PGXJN6W2T	bg-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2184	159	PQQINSIX3	bg-pqqinsix3	50.0GB / 180 дней	50	180	30	Bulgaria 50GB 180Days	t
2185	159	BG-3.0GB-30D-PHD8GZ2VN	bg-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2186	159	BG-20.0GB-90D-PG3K0LHBC	bg-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2187	159	BG-1.0GB-365D-PCQXBW5UJ	bg-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2188	159	BG-1.0GB-30D-PM1HX6ES9	bg-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2189	159	BG-3.0GB-30D-PJK6T8JT2	bg-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2190	159	BG-5.0GB-30D-P87F6RTKY	bg-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2191	159	BG-1.0GB-7D-PV048NCRG	bg-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2667	181	CKH211	ee-ckh211	1.0GB / 7 дней	1	7	0.9	Estonia 1GB 7Days	t
2668	181	CKH212	ee-ckh212	3.0GB / 15 дней	3	15	2.2	Estonia 3GB 15Days	t
2669	181	CKH213	ee-ckh213	10.0GB / 30 дней	10	30	6.1	Estonia 10GB 30Days	t
2670	181	EE-1.0GB-7D-CKH484	ee-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2671	181	EE-10.0GB-30D-CKH486	ee-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2672	181	EE-20.0GB-30D-CKH500	ee-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2673	181	EE-6.0GB-15D-AIS002	ee-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2674	181	CKH710	ee-ckh710	20.0GB / 30 дней	20	30	10.6	Estonia 20GB 30Days	t
2675	181	EE-1.0GB-7D-CKH823	ee-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2676	181	EE-5.0GB-30D-CKH825	ee-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2677	181	EE-10.0GB-30D-CKH826	ee-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2678	181	EE-20.0GB-90D-P7VCE7FKY	ee-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2679	181	EE-50.0GB-180D-PGXJN6W2T	ee-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2680	181	PF1EBHZY5	ee-pf1ebhzy5	50.0GB / 180 дней	50	180	30	Estonia 50GB 180Days	t
2681	181	EE-3.0GB-30D-PHD8GZ2VN	ee-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2698	181	EE-20.0GB-90D-PB83STJL6	ee-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2193	159	BG-20.0GB-30D-PHC4X21NC	bg-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2194	159	BG-20.0GB-90D-P5NWWU08G	bg-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2195	159	BG-50.0GB-180D-PE70MYRZ5	bg-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
2196	159	BG-1.0GB-1D-PUDV52A3R	bg-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
2197	159	BG-1.5GB-1D-P34CJYA6C	bg-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2198	159	BG-1.0GB-7D-PHS30M6EZ	bg-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2199	159	BG-1.0GB-365D-PYMC5N31Z	bg-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2200	159	BG-5.0GB-30D-PEW54FVD9	bg-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2201	159	BG-3.0GB-30D-PW6P3DX2G	bg-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2202	159	BG-20.0GB-90D-PB83STJL6	bg-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2203	159	BG-20.0GB-30D-PR3JZMC20	bg-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2204	159	BG-10.0GB-30D-P34FHRF8J	bg-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2205	159	BG-2.0GB-1D-PZ6R8ASH9	bg-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2236	161	KH-5.0GB-30D-JC178	kh-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
2237	161	KH-3.0GB-15D-JC179	kh-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
2238	161	KH-10.0GB-30D-JC180	kh-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
2239	161	KH-20.0GB-90D-JC181	kh-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
2240	161	KH-50.0GB-180D-JC182	kh-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
2241	161	KH-1.0GB-7D-JC183	kh-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
2242	161	KH-3.0GB-30D-PHD8GZ2VN	kh-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2243	161	KH-20.0GB-90D-PG3K0LHBC	kh-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2244	161	KH-50.0GB-180D-P4GNDNA36	kh-p4gndna36	50.0GB / 180 дней	50	180	45	Asia (7 areas) 50GB 180Days	t
2245	161	KH-1.0GB-365D-PCQXBW5UJ	kh-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2246	161	KH-0.5GB-1D-PACK04L3R	kh-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
2247	161	KH-1.0GB-1D-PXJ8HG40S	kh-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
2248	161	KH-2.0GB-1D-PVBKS19B4	kh-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
2249	161	KH-3.0GB-1D-PM5T3Z4UM	kh-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
2250	161	KH-1.0GB-1D-P0N8SUBG5	kh-p0n8subg5	1.0GB / 1 дней	1	1	1.7	Asia (7 areas) 1GB/Day	t
2294	165	TD-6.0GB-15D-AIS002	td-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2295	165	TD-1.0GB-7D-CKH823	td-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2296	165	TD-5.0GB-30D-CKH825	td-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2297	165	TD-10.0GB-30D-CKH826	td-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2298	165	TD-3.0GB-30D-P1XXDOD0C	td-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2299	165	TD-3.0GB-30D-PHD8GZ2VN	td-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2300	165	TD-20.0GB-90D-PG3K0LHBC	td-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2301	165	TD-1.0GB-365D-PCQXBW5UJ	td-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2302	165	TD-1.0GB-7D-PHS30M6EZ	td-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2303	165	TD-1.0GB-365D-PYMC5N31Z	td-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2304	165	TD-5.0GB-30D-PEW54FVD9	td-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2699	181	EE-20.0GB-30D-PR3JZMC20	ee-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2700	181	EE-10.0GB-30D-P34FHRF8J	ee-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2701	181	EE-2.0GB-1D-PZ6R8ASH9	ee-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2702	181	EE-3.0GB-1D-PE01DJZS7	ee-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
2703	181	EE-0.5GB-1D-P61RQP7ZW	ee-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2704	181	EE-0.3GB-1D-P82Y6VYRL	ee-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2705	182	CKH389	sz-ckh389	1.0GB / 7 дней	1	7	7.1	Swaziland 1GB 7Days	t
2706	182	CKH418	sz-ckh418	3.0GB / 15 дней	3	15	17.6	Swaziland 3GB 15Days	t
2722	182	SZ-20.0GB-30D-PR3JZMC20	sz-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2723	182	SZ-10.0GB-30D-P34FHRF8J	sz-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2728	185	CKH084	fi-ckh084	3.0GB / 30 дней	3	30	1.8	Finland 3GB 30Days	t
2729	185	CKH123	fi-ckh123	5.0GB / 30 дней	5	30	2.7	Finland 5GB 30Days	t
2730	185	CKH214	fi-ckh214	1.0GB / 7 дней	1	7	0.7	Finland 1GB 7Days	t
2731	185	CKH215	fi-ckh215	3.0GB / 15 дней	3	15	1.7	Finland 3GB 15Days	t
2732	185	CKH216	fi-ckh216	10.0GB / 30 дней	10	30	4.7	Finland 10GB 30Days	t
2733	185	FI-1.0GB-7D-CKH484	fi-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2734	185	FI-10.0GB-30D-CKH486	fi-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2735	185	FI-20.0GB-30D-CKH500	fi-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2736	185	FI-6.0GB-15D-AIS002	fi-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2305	165	TD-3.0GB-30D-PW6P3DX2G	td-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2306	165	TD-20.0GB-90D-PB83STJL6	td-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2307	165	TD-20.0GB-30D-PR3JZMC20	td-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2308	165	TD-10.0GB-30D-P34FHRF8J	td-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2323	166	CL-1.0GB-7D-PHS30M6EZ	cl-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2324	166	CL-1.0GB-365D-PYMC5N31Z	cl-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2325	166	CL-5.0GB-30D-PEW54FVD9	cl-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2326	166	CL-3.0GB-30D-PW6P3DX2G	cl-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2327	166	CL-20.0GB-90D-PB83STJL6	cl-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2328	166	CL-20.0GB-30D-PR3JZMC20	cl-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2329	166	CL-10.0GB-30D-P34FHRF8J	cl-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2351	167	CO-5.0GB-1D-PX18HJ4XW	co-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2352	167	CO-1.0GB-1D-P8JCL47FC	co-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2353	167	CO-0.5GB-1D-PX2WSA7L1	co-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
2354	167	CO-10.0GB-30D-PCHZ59M2J	co-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
2355	167	CO-5.0GB-30D-P7GA02CZP	co-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2356	167	CO-3.0GB-30D-PQB69VW8U	co-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2357	167	CO-1.0GB-7D-PUSHF5X80	co-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2364	168	CG-1.0GB-7D-CKH823	cg-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2365	168	CG-5.0GB-30D-CKH825	cg-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2366	168	CG-10.0GB-30D-CKH826	cg-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2367	168	CG-3.0GB-30D-P1XXDOD0C	cg-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2368	168	CG-3.0GB-30D-PHD8GZ2VN	cg-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2369	168	CG-20.0GB-90D-PG3K0LHBC	cg-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2370	168	CG-1.0GB-365D-PCQXBW5UJ	cg-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2371	168	CG-1.0GB-7D-PHS30M6EZ	cg-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2372	168	CG-1.0GB-365D-PYMC5N31Z	cg-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2373	168	CG-5.0GB-30D-PEW54FVD9	cg-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2737	185	FI-1.0GB-7D-CKH823	fi-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2738	185	FI-5.0GB-30D-CKH825	fi-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2739	185	FI-10.0GB-30D-CKH826	fi-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2740	185	FI-20.0GB-90D-P7VCE7FKY	fi-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
4155	250	CKH1001	no-ckh1001	10.0GB / 30 дней	10	30	4.7	Norway 10GB 30Days	t
4156	250	NO-1.0GB-7D-CKH484	no-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
4157	250	NO-10.0GB-30D-CKH486	no-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
4158	250	NO-20.0GB-30D-CKH500	no-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
4159	250	NO-6.0GB-15D-AIS002	no-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4160	250	CKH1009	no-ckh1009	20.0GB / 30 дней	20	30	8.2	Norway 20GB 30Days	t
4161	250	NO-1.0GB-7D-CKH823	no-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4162	250	NO-5.0GB-30D-CKH825	no-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2741	185	FI-50.0GB-180D-PGXJN6W2T	fi-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2742	185	PU4UANEPA	fi-pu4uanepa	50.0GB / 180 дней	50	180	28	Finland 50GB 180Days	t
2743	185	FI-3.0GB-30D-PHD8GZ2VN	fi-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2767	186	GF-5.0GB-1D-PX18HJ4XW	gf-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2768	186	GF-1.0GB-1D-P8JCL47FC	gf-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2769	186	GF-0.5GB-1D-PX2WSA7L1	gf-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
2770	186	GF-10.0GB-30D-PCHZ59M2J	gf-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
2779	187	GA-1.0GB-7D-CKH823	ga-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2780	187	GA-5.0GB-30D-CKH825	ga-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2781	187	GA-10.0GB-30D-CKH826	ga-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3470	217	KW-10.0GB-30D-P34FHRF8J	kw-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3471	217	KW-10.0GB-1D-PLR26GSE7	kw-plr26gse7	10.0GB / 1 дней	10	1	22	Gulf Region 10GB/Day	t
3472	217	KW-5.0GB-1D-PLK713DWL	kw-plk713dwl	5.0GB / 1 дней	5	1	10.8	Gulf Region 5GB/Day	t
3473	217	KW-1.0GB-1D-P40YDJ9WA	kw-p40ydj9wa	1.0GB / 1 дней	1	1	2.9	Gulf Region 1GB/Day	t
3474	217	KW-0.5GB-1D-PW9U86NGE	kw-pw9u86nge	0.49GB / 1 дней	0.49	1	1.8	Gulf Region 500MB/Day	t
4163	250	NO-10.0GB-30D-CKH826	no-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4164	250	PDUMILX5C	no-pdumilx5c	50.0GB / 180 дней	50	180	28	Norway 50GB 180Days	t
2374	168	CG-3.0GB-30D-PW6P3DX2G	cg-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2375	168	CG-20.0GB-90D-PB83STJL6	cg-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2376	168	CG-20.0GB-30D-PR3JZMC20	cg-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2377	168	CG-10.0GB-30D-P34FHRF8J	cg-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2412	170	CR-3.0GB-30D-PW6P3DX2G	cr-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2413	170	CR-20.0GB-90D-PB83STJL6	cr-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2414	170	CR-20.0GB-30D-PR3JZMC20	cr-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2415	170	CR-10.0GB-30D-P34FHRF8J	cr-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2420	171	CKH160	hr-ckh160	1.0GB / 7 дней	1	7	0.9	Croatia 1GB 7Days	t
2421	171	CKH161	hr-ckh161	3.0GB / 15 дней	3	15	2.2	Croatia 3GB 15Days	t
2422	171	CKH162	hr-ckh162	10.0GB / 30 дней	10	30	6.1	Croatia 10GB 30Days	t
2423	171	HR-1.0GB-7D-CKH484	hr-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2424	171	HR-10.0GB-30D-CKH486	hr-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2425	171	HR-20.0GB-30D-CKH500	hr-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2426	171	HR-6.0GB-15D-AIS002	hr-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2427	171	CKH539	hr-ckh539	20.0GB / 30 дней	20	30	10.6	Croatia 20GB 30Days	t
2428	171	HR-1.0GB-7D-CKH823	hr-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2429	171	HR-5.0GB-30D-CKH825	hr-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2430	171	HR-10.0GB-30D-CKH826	hr-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2431	171	HR-20.0GB-90D-P7VCE7FKY	hr-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2432	171	HR-50.0GB-180D-PGXJN6W2T	hr-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2433	171	PQCZMPBQD	hr-pqczmpbqd	50.0GB / 180 дней	50	180	28	Croatia 50GB 180Days	t
2434	171	HR-3.0GB-30D-PHD8GZ2VN	hr-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2435	171	HR-20.0GB-90D-PG3K0LHBC	hr-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2801	188	GE-5.0GB-30D-CKH825	ge-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2802	188	GE-10.0GB-30D-CKH826	ge-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2803	188	GE-3.0GB-30D-PHD8GZ2VN	ge-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2804	188	GE-20.0GB-90D-PG3K0LHBC	ge-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2805	188	GE-1.0GB-365D-PCQXBW5UJ	ge-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2819	189	GH-3.0GB-30D-PW6P3DX2G	gh-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2820	189	GH-20.0GB-90D-PB83STJL6	gh-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2823	190	GI-3.0GB-30D-CKH006	gi-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2824	190	GI-5.0GB-30D-CKH007	gi-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2849	191	CKH985	gr-ckh985	5.0GB / 30 дней	5	30	3.4	Greece 5GB 30Days	t
4165	250	NO-20.0GB-90D-P7VCE7FKY	no-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
4166	250	NO-50.0GB-180D-PGXJN6W2T	no-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
4167	250	NO-3.0GB-30D-PHD8GZ2VN	no-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4168	250	NO-20.0GB-90D-PG3K0LHBC	no-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4169	250	NO-1.0GB-365D-PCQXBW5UJ	no-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4170	250	NO-1.0GB-30D-PM1HX6ES9	no-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2850	191	CKH996	gr-ckh996	1.0GB / 7 дней	1	7	0.9	Greece 1GB 7Days	t
2851	191	CKH997	gr-ckh997	3.0GB / 15 дней	3	15	2.2	Greece 3GB 15Days	t
2852	191	CKH998	gr-ckh998	10.0GB / 30 дней	10	30	6.1	Greece 10GB 30Days	t
2853	191	GR-1.0GB-7D-CKH484	gr-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2854	191	GR-10.0GB-30D-CKH486	gr-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2855	191	GR-20.0GB-30D-CKH500	gr-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2856	191	GR-6.0GB-15D-AIS002	gr-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2857	191	CKH1007	gr-ckh1007	20.0GB / 30 дней	20	30	10.6	Greece 20GB 30Days	t
2858	191	GR-1.0GB-7D-CKH823	gr-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3193	206	IQ-5.0GB-30D-PK2BXX9B4	iq-pk2bxx9b4	5.0GB / 30 дней	5	30	10.8	Gulf Region  5GB  30Days Single Use	t
3194	206	IQ-3.0GB-30D-P8D7Q1CZY	iq-p8d7q1czy	3.0GB / 30 дней	3	30	6.8	Gulf Region  3GB  30Days Single Use	t
3195	206	IQ-1.0GB-7D-PTJX062PT	iq-ptjx062pt	1.0GB / 7 дней	1	7	2.3	Gulf Region 1GB  7Days Single Use	t
3209	207	IE-5.0GB-30D-CKH825	ie-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3210	207	IE-10.0GB-30D-CKH826	ie-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3211	207	IE-20.0GB-90D-P7VCE7FKY	ie-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3212	207	IE-50.0GB-180D-PGXJN6W2T	ie-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3213	207	PJVVSY6IR	ie-pjvvsy6ir	50.0GB / 180 дней	50	180	22	Ireland 50GB 180Days	t
3214	207	IE-3.0GB-30D-PHD8GZ2VN	ie-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2438	171	HR-3.0GB-30D-PJK6T8JT2	hr-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2439	171	HR-5.0GB-30D-P87F6RTKY	hr-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2440	171	HR-1.0GB-7D-PV048NCRG	hr-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2441	171	HR-10.0GB-30D-P50GVS8GN	hr-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2442	171	HR-20.0GB-30D-PHC4X21NC	hr-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
458	5	IT-50.0GB-180D-PE70MYRZ5	it-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
459	5	IT-1.0GB-1D-PUDV52A3R	it-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
460	5	IT-1.5GB-1D-P34CJYA6C	it-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
461	5	IT-1.0GB-7D-PHS30M6EZ	it-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
462	5	IT-1.0GB-365D-PYMC5N31Z	it-pymc5n31z	1.0GB / 365 дней	1	365	19		t
463	5	IT-5.0GB-30D-PEW54FVD9	it-pew54fvd9	5.0GB / 30 дней	5	30	26		t
464	5	IT-3.0GB-30D-PW6P3DX2G	it-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
465	5	IT-20.0GB-90D-PB83STJL6	it-pb83stjl6	20.0GB / 90 дней	20	90	95		t
466	5	IT-20.0GB-30D-PR3JZMC20	it-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
467	5	IT-10.0GB-30D-P34FHRF8J	it-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
468	5	IT-2.0GB-1D-PZ6R8ASH9	it-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
469	5	IT-3.0GB-1D-PE01DJZS7	it-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
470	5	IT-0.5GB-1D-P61RQP7ZW	it-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
471	5	IT-0.3GB-1D-P82Y6VYRL	it-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
472	5	PZARONTRP	it-pzarontrp	1.0GB / 1 дней	1	1	0.85		t
473	5	P79VVN4GK	it-p79vvn4gk	0.49GB / 1 дней	0.49	1	0.45	Italy 500MB/Day	t
474	5	PMMQ41F5S	it-pmmq41f5s	2.0GB / 1 дней	2	1	1.5	Italy 2GB/Day	t
475	5	P9Z3HQ8HG	it-p9z3hq8hg	5.0GB / 1 дней	5	1	2.3	Italy 5GB/Day	t
662	9	JC063	jp-jc063	1.0GB / 7 дней	1	7	0.7	Japan 1GB 7Days	t
663	9	JC064	jp-jc064	3.0GB / 15 дней	3	15	1.7	Japan 3GB 15Days	t
664	9	JC065	jp-jc065	5.0GB / 30 дней	5	30	2.7	Japan 5GB 30Days	t
665	9	JC066	jp-jc066	10.0GB / 30 дней	10	30	4.7	Japan 10GB 30Days	t
666	9	AIS001	jp-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
667	9	JP-6.0GB-15D-AIS002	jp-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
668	9	JC145	jp-jc145	20.0GB / 30 дней	20	30	8.2	Japan 20GB 30Days	t
669	9	JP-1.0GB-7D-CKH823	jp-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
670	9	JP-5.0GB-30D-CKH825	jp-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
671	9	JP-10.0GB-30D-CKH826	jp-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
672	9	JP-1.0GB-30D-JC177	jp-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
701	9	P4XU0X3CX	jp-p4xu0x3cx	1.0GB / 7 дней	1	7	2.3	China mainland & Japan & South Korea 1GB 7Days	t
702	9	P9Q0XP8HU	jp-p9q0xp8hu	3.0GB / 15 дней	3	15	5.7	China mainland & Japan & South Korea 3GB 15Days	t
703	9	P64BPV0PR	jp-p64bpv0pr	3.0GB / 30 дней	3	30	5.9	China mainland & Japan & South Korea 3GB 30Days	t
704	9	P5KZF2WY6	jp-p5kzf2wy6	5.0GB / 30 дней	5	30	8.8	China mainland & Japan & South Korea 5GB 30Days	t
705	9	P5JHQ39EE	jp-p5jhq39ee	10.0GB / 30 дней	10	30	15.2	China mainland & Japan & South Korea 10GB 30Days	t
706	9	P93F7ZCSY	jp-p93f7zcsy	20.0GB / 30 дней	20	30	25	China mainland & Japan & South Korea 20GB 30Days	t
707	9	PD4EBQ08R	jp-pd4ebq08r	0.49GB / 1 дней	0.49	1	1.2	China mainland & Japan & South Korea 500MB/Day	t
708	9	P8SU7BG1W	jp-p8su7bg1w	1.0GB / 1 дней	1	1	2.2	China mainland & Japan & South Korea 1GB/Day	t
709	9	P1Z74ZBVM	jp-p1z74zbvm	2.0GB / 1 дней	2	1	4.3	China mainland & Japan & South Korea 2GB/Day	t
2859	191	GR-5.0GB-30D-CKH825	gr-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2860	191	GR-10.0GB-30D-CKH826	gr-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2861	191	PGLSEATB8	gr-pglseatb8	50.0GB / 180 дней	50	180	22	Greece 50GB 180Days	t
2862	191	GR-20.0GB-90D-P7VCE7FKY	gr-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2863	191	GR-50.0GB-180D-PGXJN6W2T	gr-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2864	191	GR-3.0GB-30D-PHD8GZ2VN	gr-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2865	191	GR-20.0GB-90D-PG3K0LHBC	gr-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2866	191	GR-1.0GB-365D-PCQXBW5UJ	gr-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2867	191	GR-1.0GB-30D-PM1HX6ES9	gr-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2888	192	GL-6.0GB-15D-AIS002	gl-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2889	192	GL-1.0GB-7D-CKH823	gl-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2890	192	GL-5.0GB-30D-CKH825	gl-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2891	192	GL-10.0GB-30D-CKH826	gl-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2892	192	GL-3.0GB-30D-PHD8GZ2VN	gl-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2452	171	HR-20.0GB-30D-PR3JZMC20	hr-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2453	171	HR-10.0GB-30D-P34FHRF8J	hr-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2454	171	HR-2.0GB-1D-PZ6R8ASH9	hr-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2455	171	HR-3.0GB-1D-PE01DJZS7	hr-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
2456	171	HR-0.5GB-1D-P61RQP7ZW	hr-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2457	171	HR-0.3GB-1D-P82Y6VYRL	hr-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2471	172	CY-10.0GB-30D-CKH826	cy-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2472	172	CY-20.0GB-90D-P7VCE7FKY	cy-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2473	172	CY-50.0GB-180D-PGXJN6W2T	cy-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2474	172	PXHQDYUBO	cy-pxhqdyubo	50.0GB / 180 дней	50	180	30	Cyprus 50GB 180Days	t
2475	172	CY-3.0GB-30D-PHD8GZ2VN	cy-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2476	172	CY-20.0GB-90D-PG3K0LHBC	cy-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2477	172	CY-1.0GB-365D-PCQXBW5UJ	cy-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2478	172	CY-1.0GB-30D-PM1HX6ES9	cy-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2479	172	CY-3.0GB-30D-PJK6T8JT2	cy-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2480	172	CY-5.0GB-30D-P87F6RTKY	cy-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2481	172	CY-1.0GB-7D-PV048NCRG	cy-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2482	172	CY-10.0GB-30D-P50GVS8GN	cy-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2483	172	CY-20.0GB-30D-PHC4X21NC	cy-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2893	192	GL-20.0GB-90D-PG3K0LHBC	gl-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2894	192	GL-1.0GB-365D-PCQXBW5UJ	gl-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3475	217	KW-10.0GB-30D-P9DH2MUN5	kw-p9dh2mun5	10.0GB / 30 дней	10	30	22	Gulf Region 10GB 30Days Single Use	t
3476	217	KW-5.0GB-30D-PK2BXX9B4	kw-pk2bxx9b4	5.0GB / 30 дней	5	30	10.8	Gulf Region  5GB  30Days Single Use	t
3477	217	KW-3.0GB-30D-P8D7Q1CZY	kw-p8d7q1czy	3.0GB / 30 дней	3	30	6.8	Gulf Region  3GB  30Days Single Use	t
3478	217	KW-1.0GB-7D-PTJX062PT	kw-ptjx062pt	1.0GB / 7 дней	1	7	2.3	Gulf Region 1GB  7Days Single Use	t
3488	218	KG-1.0GB-365D-PCQXBW5UJ	kg-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3489	218	KG-1.0GB-7D-PHS30M6EZ	kg-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3490	218	KG-1.0GB-365D-PYMC5N31Z	kg-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3491	218	KG-5.0GB-30D-PEW54FVD9	kg-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3492	218	KG-3.0GB-30D-PW6P3DX2G	kg-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3493	218	KG-20.0GB-90D-PB83STJL6	kg-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3494	218	KG-20.0GB-30D-PR3JZMC20	kg-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3495	218	KG-10.0GB-30D-P34FHRF8J	kg-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3496	218	KG-10.0GB-1D-PGP9AZY26	kg-pgp9azy26	10.0GB / 1 дней	10	1	10.8	Central Asia 10GB/Day	t
3497	218	KG-5.0GB-1D-P9RS4VV0A	kg-p9rs4vv0a	5.0GB / 1 дней	5	1	6	Central Asia 5GB/Day	t
3498	218	KG-1.0GB-1D-PJA28XEA7	kg-pja28xea7	1.0GB / 1 дней	1	1	1.4	Central Asia 1GB/Day	t
3499	218	KG-0.5GB-1D-P712EDLGB	kg-p712edlgb	0.49GB / 1 дней	0.49	1	0.6	Central Asia 500MB/Day	t
3522	220	LV-1.0GB-365D-PCQXBW5UJ	lv-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3523	220	LV-1.0GB-30D-PM1HX6ES9	lv-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
3524	220	LV-3.0GB-30D-PJK6T8JT2	lv-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
3525	220	LV-5.0GB-30D-P87F6RTKY	lv-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
3526	220	LV-1.0GB-7D-PV048NCRG	lv-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
3527	220	LV-10.0GB-30D-P50GVS8GN	lv-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
3528	220	LV-20.0GB-30D-PHC4X21NC	lv-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
3529	220	LV-20.0GB-90D-P5NWWU08G	lv-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
4171	250	NO-3.0GB-30D-PJK6T8JT2	no-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
4180	250	NO-1.0GB-7D-PHS30M6EZ	no-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4192	251	CKH028	om-ckh028	3.0GB / 30 дней	3	30	14.4	Oman 3GB 30Days	t
4193	251	CKH273	om-ckh273	1.0GB / 7 дней	1	7	5.7	Oman 1GB 7Days	t
4194	251	CKH274	om-ckh274	3.0GB / 15 дней	3	15	14.1	Oman 3GB 15Days	t
4195	251	OM-6.0GB-8D-AIS001	om-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
4196	251	OM-6.0GB-15D-AIS002	om-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4197	251	CKH807	om-ckh807	20.0GB / 30 дней	20	30	63	Oman 20GB 30Days	t
4198	251	OM-1.0GB-7D-CKH823	om-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4199	251	OM-5.0GB-30D-CKH825	om-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4200	251	OM-10.0GB-30D-CKH826	om-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2484	172	CY-20.0GB-90D-P5NWWU08G	cy-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2485	172	CY-50.0GB-180D-PE70MYRZ5	cy-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
2486	172	CY-1.0GB-1D-PUDV52A3R	cy-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
2487	172	CY-1.5GB-1D-P34CJYA6C	cy-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2488	172	CY-1.0GB-7D-PHS30M6EZ	cy-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2489	172	CY-1.0GB-365D-PYMC5N31Z	cy-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2490	172	CY-5.0GB-30D-PEW54FVD9	cy-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2491	172	CY-3.0GB-30D-PW6P3DX2G	cy-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1076	264	CKH365	re-ckh365	1.0GB / 7 дней	1	7	2.9	Reunion 1GB 7Days	t
2492	172	CY-20.0GB-90D-PB83STJL6	cy-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2493	172	CY-20.0GB-30D-PR3JZMC20	cy-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2494	172	CY-10.0GB-30D-P34FHRF8J	cy-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2495	172	CY-2.0GB-1D-PZ6R8ASH9	cy-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2496	172	CY-3.0GB-1D-PE01DJZS7	cy-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
2497	172	CY-0.5GB-1D-P61RQP7ZW	cy-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2498	172	CY-0.3GB-1D-P82Y6VYRL	cy-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2526	173	CZ-20.0GB-90D-P5NWWU08G	cz-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2527	173	CZ-50.0GB-180D-PE70MYRZ5	cz-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
2528	173	CZ-1.0GB-1D-PUDV52A3R	cz-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
2529	173	CZ-1.5GB-1D-P34CJYA6C	cz-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2530	173	CZ-1.0GB-7D-PHS30M6EZ	cz-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2531	173	CZ-1.0GB-365D-PYMC5N31Z	cz-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2532	173	CZ-5.0GB-30D-PEW54FVD9	cz-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2533	173	CZ-3.0GB-30D-PW6P3DX2G	cz-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2534	173	CZ-20.0GB-90D-PB83STJL6	cz-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2535	173	CZ-20.0GB-30D-PR3JZMC20	cz-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2536	173	CZ-10.0GB-30D-P34FHRF8J	cz-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2901	193	GD-1.0GB-7D-PUSHF5X80	gd-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2921	195	PNCYQZAZN	gu-pncyqzazn	1.0GB / 7 дней	1	7	3.6		t
1021	11	RU-3.0GB-30D-CKH006	ru-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2922	195	PKEMRQFAC	gu-pkemrqfac	3.0GB / 15 дней	3	15	8.9		t
2923	195	PEOWI61PF	gu-peowi61pf	3.0GB / 30 дней	3	30	9.1		t
2948	197	GG-3.0GB-30D-CKH006	gg-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2949	197	GG-5.0GB-30D-CKH007	gg-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2950	197	CKH109	gg-ckh109	3.0GB / 30 дней	3	30	11.4	Guernsey 3GB 30Days	t
2951	197	CKH148	gg-ckh148	5.0GB / 30 дней	5	30	17.1	Guernsey 5GB 30Days	t
2952	197	GG-1.0GB-7D-CKH484	gg-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2953	197	GG-10.0GB-30D-CKH486	gg-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2954	197	GG-20.0GB-30D-CKH500	gg-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2955	197	GG-6.0GB-15D-AIS002	gg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2956	197	CKH608	gg-ckh608	1.0GB / 7 дней	1	7	4.6	Guernsey 1GB 7Days	t
4201	251	OM-1.0GB-7D-CKH848	om-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
4202	251	OM-5.0GB-30D-CKH850	om-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
4225	252	PK-5.0GB-30D-JC178	pk-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
4226	252	PK-3.0GB-15D-JC179	pk-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
4227	252	PK-10.0GB-30D-JC180	pk-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
4228	252	PK-20.0GB-90D-JC181	pk-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
4229	252	PK-50.0GB-180D-JC182	pk-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
4230	252	PK-1.0GB-7D-JC183	pk-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
4231	252	PK-3.0GB-30D-PHD8GZ2VN	pk-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1022	11	RU-5.0GB-30D-CKH007	ru-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1023	11	JC068	ru-jc068	3.0GB / 30 дней	3	30	7.3	Russia 3GB 30Days	t
1024	11	JC069	ru-jc069	5.0GB / 30 дней	5	30	11	Russia 5GB 30Days	t
1026	11	JC071	ru-jc071	3.0GB / 15 дней	3	15	7.2	Russia 3GB 15Days	t
1027	11	RU-1.0GB-7D-CKH484	ru-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1028	11	RU-10.0GB-30D-CKH486	ru-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1029	11	RU-20.0GB-30D-CKH500	ru-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
4232	252	PK-20.0GB-90D-PG3K0LHBC	pk-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4233	252	PK-1.0GB-365D-PCQXBW5UJ	pk-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2537	173	CZ-2.0GB-1D-PZ6R8ASH9	cz-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2538	173	CZ-3.0GB-1D-PE01DJZS7	cz-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
1093	265	KN-5.0GB-1D-PX18HJ4XW	kn-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2539	173	CZ-0.5GB-1D-P61RQP7ZW	cz-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2540	173	CZ-0.3GB-1D-P82Y6VYRL	cz-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2554	174	CI-1.0GB-365D-PYMC5N31Z	ci-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2555	174	CI-5.0GB-30D-PEW54FVD9	ci-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2556	174	CI-3.0GB-30D-PW6P3DX2G	ci-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2557	174	CI-20.0GB-90D-PB83STJL6	ci-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1100	266	LC-5.0GB-1D-PX18HJ4XW	lc-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1101	266	LC-1.0GB-1D-P8JCL47FC	lc-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
1102	266	LC-0.5GB-1D-PX2WSA7L1	lc-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1103	266	LC-10.0GB-30D-PCHZ59M2J	lc-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1104	266	LC-5.0GB-30D-P7GA02CZP	lc-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1105	266	LC-3.0GB-30D-PQB69VW8U	lc-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1106	266	LC-1.0GB-7D-PUSHF5X80	lc-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1107	267	VC-5.0GB-1D-PX18HJ4XW	vc-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1108	267	VC-1.0GB-1D-P8JCL47FC	vc-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
1109	267	VC-0.5GB-1D-PX2WSA7L1	vc-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1110	267	VC-10.0GB-30D-PCHZ59M2J	vc-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1111	267	VC-5.0GB-30D-P7GA02CZP	vc-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1112	267	VC-3.0GB-30D-PQB69VW8U	vc-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1113	267	VC-1.0GB-7D-PUSHF5X80	vc-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1114	268	WS-1.0GB-7D-CKH823	ws-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1115	268	WS-5.0GB-30D-CKH825	ws-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1116	268	WS-10.0GB-30D-CKH826	ws-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1117	268	WS-3.0GB-30D-PHD8GZ2VN	ws-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1118	268	WS-20.0GB-90D-PG3K0LHBC	ws-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1119	268	WS-1.0GB-365D-PCQXBW5UJ	ws-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1120	269	SM-6.0GB-15D-AIS002	sm-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1121	270	CKH036	sa-ckh036	3.0GB / 30 дней	3	30	7.3	Saudi Arabia 3GB 30Days	t
1122	270	CKH277	sa-ckh277	1.0GB / 7 дней	1	7	2.9	Saudi Arabia 1GB 7Days	t
1123	270	CKH278	sa-ckh278	3.0GB / 15 дней	3	15	7.2	Saudi Arabia 3GB 15Days	t
1124	270	CKH279	sa-ckh279	5.0GB / 30 дней	5	30	11	Saudi Arabia 5GB 30Days	t
1125	270	CKH280	sa-ckh280	10.0GB / 30 дней	10	30	19	Saudi Arabia 10GB 30Days	t
1126	270	SA-6.0GB-15D-AIS002	sa-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1127	270	CKH800	sa-ckh800	20.0GB / 30 дней	20	30	32	Saudi Arabia 20GB 30Days	t
1128	270	SA-1.0GB-7D-CKH823	sa-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1129	270	SA-5.0GB-30D-CKH825	sa-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2558	174	CI-20.0GB-30D-PR3JZMC20	ci-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2559	174	CI-10.0GB-30D-P34FHRF8J	ci-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2578	175	DK-3.0GB-30D-PHD8GZ2VN	dk-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2579	175	DK-20.0GB-90D-PG3K0LHBC	dk-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2580	175	DK-1.0GB-365D-PCQXBW5UJ	dk-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2581	175	DK-1.0GB-30D-PM1HX6ES9	dk-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2582	175	DK-3.0GB-30D-PJK6T8JT2	dk-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2583	175	DK-5.0GB-30D-P87F6RTKY	dk-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2957	197	CKH609	gg-ckh609	3.0GB / 15 дней	3	15	11.2	Guernsey 3GB 15Days	t
2976	198	GW-1.0GB-7D-PHS30M6EZ	gw-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2977	198	GW-1.0GB-365D-PYMC5N31Z	gw-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2978	198	GW-5.0GB-30D-PEW54FVD9	gw-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2979	198	GW-3.0GB-30D-PW6P3DX2G	gw-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2980	198	GW-20.0GB-90D-PB83STJL6	gw-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2981	198	GW-20.0GB-30D-PR3JZMC20	gw-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2982	198	GW-10.0GB-30D-P34FHRF8J	gw-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3005	201	JC004	hk-jc004	3.0GB / 30 дней	3	30	1.8	Hong Kong 3GB 30Days	t
2584	175	DK-1.0GB-7D-PV048NCRG	dk-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2585	175	DK-10.0GB-30D-P50GVS8GN	dk-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2586	175	DK-20.0GB-30D-PHC4X21NC	dk-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2587	175	DK-20.0GB-90D-P5NWWU08G	dk-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2588	175	DK-50.0GB-180D-PE70MYRZ5	dk-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
2589	175	DK-1.0GB-1D-PUDV52A3R	dk-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
2590	175	DK-1.5GB-1D-P34CJYA6C	dk-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2591	175	DK-1.0GB-7D-PHS30M6EZ	dk-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2592	175	DK-1.0GB-365D-PYMC5N31Z	dk-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2593	175	DK-5.0GB-30D-PEW54FVD9	dk-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2594	175	DK-3.0GB-30D-PW6P3DX2G	dk-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2595	175	DK-20.0GB-90D-PB83STJL6	dk-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2596	175	DK-20.0GB-30D-PR3JZMC20	dk-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2597	175	DK-10.0GB-30D-P34FHRF8J	dk-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2598	175	DK-2.0GB-1D-PZ6R8ASH9	dk-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2599	175	DK-3.0GB-1D-PE01DJZS7	dk-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
2600	175	DK-0.5GB-1D-P61RQP7ZW	dk-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2601	175	DK-0.3GB-1D-P82Y6VYRL	dk-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2635	178	EC-1.0GB-7D-PHS30M6EZ	ec-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2636	178	EC-1.0GB-365D-PYMC5N31Z	ec-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1179	272	RS-3.0GB-30D-CKH006	rs-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
1180	272	RS-5.0GB-30D-CKH007	rs-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1181	272	CKH113	rs-ckh113	3.0GB / 30 дней	3	30	7.3	Serbia 3GB 30Days	t
1182	272	RS-1.0GB-7D-CKH484	rs-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1183	272	RS-10.0GB-30D-CKH486	rs-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1184	272	RS-20.0GB-30D-CKH500	rs-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1185	272	RS-6.0GB-15D-AIS002	rs-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1186	272	CKH1016	rs-ckh1016	1.0GB / 7 дней	1	7	2.9	Serbia 1GB 7Days	t
1187	272	CKH677	rs-ckh677	3.0GB / 15 дней	3	15	7.2	Serbia 3GB 15Days	t
1188	272	CKH803	rs-ckh803	20.0GB / 30 дней	20	30	32	Serbia 20GB 30Days	t
1189	272	RS-1.0GB-7D-CKH823	rs-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2637	178	EC-5.0GB-30D-PEW54FVD9	ec-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2638	178	EC-3.0GB-30D-PW6P3DX2G	ec-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2639	178	EC-20.0GB-90D-PB83STJL6	ec-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2640	178	EC-20.0GB-30D-PR3JZMC20	ec-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2641	178	EC-10.0GB-30D-P34FHRF8J	ec-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
973	179	MB024	eg-mb024	1.0GB / 7 дней	1	7	2.3	Egypt 1GB 7Days	t
974	179	MB029	eg-mb029	3.0GB / 15 дней	3	15	5.7	Egypt 3GB 15Days	t
975	179	MB034	eg-mb034	5.0GB / 30 дней	5	30	8.8	Egypt 5GB 30Days	t
976	179	MB039	eg-mb039	10.0GB / 30 дней	10	30	15.2	Egypt 10GB 30Days	t
3006	201	JC005	hk-jc005	5.0GB / 30 дней	5	30	2.7	Hong Kong 5GB 30Days	t
3007	201	JC021	hk-jc021	1.0GB / 7 дней	1	7	0.7	Hong Kong 1GB 7Days	t
3008	201	JC022	hk-jc022	3.0GB / 15 дней	3	15	1.7	Hong Kong 3GB 15Days	t
3009	201	JC023	hk-jc023	10.0GB / 30 дней	10	30	4.7	Hong Kong 10GB 30Days	t
3010	201	HK-6.0GB-8D-AIS001	hk-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3011	201	HK-6.0GB-15D-AIS002	hk-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3012	201	JC104	hk-jc104	20.0GB / 30 дней	20	30	8.2	Hong Kong 20GB 30Days	t
3029	201	HK-20.0GB-90D-PG3K0LHBC	hk-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3030	201	P4MCCLBKV	hk-p4mcclbkv	50.0GB / 180 дней	50	180	32	Hong Kong 50GB 180Days	t
4234	252	PK-1.0GB-7D-PHS30M6EZ	pk-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4245	252	P70ZZFLRP	pk-p70zzflrp	3.0GB / 30 дней	3	30	4.7		t
4248	254	CKH328	pa-ckh328	3.0GB / 15 дней	3	15	11.2	Panama 3GB 15Days	t
4249	254	PA-1.0GB-7D-CKH487	pa-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
4254	254	PA-1.0GB-7D-CKH823	pa-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4273	256	PY-5.0GB-30D-CKH489	py-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
4274	256	PY-10.0GB-30D-CKH490	py-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
4275	256	PY-6.0GB-15D-AIS002	py-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4276	256	PY-1.0GB-7D-CKH823	py-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4277	256	PY-5.0GB-30D-CKH825	py-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
977	179	CKH495	eg-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
978	179	CKH497	eg-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
979	179	EG-6.0GB-15D-AIS002	eg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
980	179	EG-1.0GB-7D-CKH823	eg-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
981	179	EG-5.0GB-30D-CKH825	eg-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
982	179	EG-10.0GB-30D-CKH826	eg-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
983	179	P1XXDOD0C	eg-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
984	179	EG-3.0GB-30D-PHD8GZ2VN	eg-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
985	179	EG-20.0GB-90D-PG3K0LHBC	eg-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
986	179	EG-1.0GB-365D-PCQXBW5UJ	eg-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
987	179	EG-1.0GB-7D-PHS30M6EZ	eg-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
988	179	EG-1.0GB-365D-PYMC5N31Z	eg-pymc5n31z	1.0GB / 365 дней	1	365	19		t
989	179	EG-5.0GB-30D-PEW54FVD9	eg-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4278	256	PY-10.0GB-30D-CKH826	py-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
990	179	EG-3.0GB-30D-PW6P3DX2G	eg-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
991	179	EG-20.0GB-90D-PB83STJL6	eg-pb83stjl6	20.0GB / 90 дней	20	90	95		t
992	179	EG-20.0GB-30D-PR3JZMC20	eg-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
993	179	EG-10.0GB-30D-P34FHRF8J	eg-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
994	179	PNLOUKFKT	eg-pnloukfkt	3.0GB / 30 дней	3	30	5.9		t
4279	256	PY-3.0GB-30D-P6FNJUAP4	py-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
1224	275	SK-3.0GB-30D-CKH006	sk-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
1225	275	SK-5.0GB-30D-CKH007	sk-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1226	275	CKH099	sk-ckh099	3.0GB / 30 дней	3	30	2.3	Slovakia 3GB 30Days	t
1227	275	CKH138	sk-ckh138	5.0GB / 30 дней	5	30	3.4	Slovakia 5GB 30Days	t
1228	275	CKH196	sk-ckh196	1.0GB / 7 дней	1	7	0.9	Slovakia 1GB 7Days	t
1229	275	CKH197	sk-ckh197	3.0GB / 15 дней	3	15	2.2	Slovakia 3GB 15Days	t
1230	275	CKH198	sk-ckh198	10.0GB / 30 дней	10	30	6.1	Slovakia 10GB 30Days	t
1231	275	SK-1.0GB-7D-CKH484	sk-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1232	275	SK-10.0GB-30D-CKH486	sk-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1233	275	SK-20.0GB-30D-CKH500	sk-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1234	275	SK-6.0GB-15D-AIS002	sk-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1235	275	CKH730	sk-ckh730	20.0GB / 30 дней	20	30	10.6	Slovakia 20GB 30Days	t
1236	275	SK-1.0GB-7D-CKH823	sk-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1237	275	SK-5.0GB-30D-CKH825	sk-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1443	284	TW-6.0GB-8D-AIS001	tw-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
995	179	PIXA8CXUL	eg-pixa8cxul	20.0GB / 30 дней	20	30	25		t
996	179	PZ23T9OT0	eg-pz23t9ot0	2.0GB / 1 дней	2	1	3		t
2644	180	SV-1.0GB-7D-CKH487	sv-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
2645	180	SV-3.0GB-15D-CKH488	sv-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
2646	180	SV-5.0GB-30D-CKH489	sv-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2647	180	SV-10.0GB-30D-CKH490	sv-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
3031	201	HK-50.0GB-180D-PJKYY3QTL	hk-pjkyy3qtl	50.0GB / 180 дней	50	180	37	China (mainland HK Macao) 50GB 180Days	t
3032	201	HK-1.0GB-365D-PCQXBW5UJ	hk-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3033	201	PPGUJ3XIX	hk-ppguj3xix	1.0GB / 1 дней	1	1	0.85	Hong Kong 1GB/Day	t
3034	201	PJHK9ATRD	hk-pjhk9atrd	2.0GB / 1 дней	2	1	1.6	Hong Kong 2GB/Day	t
3035	201	HK-1.0GB-7D-PHS30M6EZ	hk-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3066	202	HU-10.0GB-30D-CKH826	hu-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3067	202	HU-20.0GB-90D-P7VCE7FKY	hu-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3068	202	HU-50.0GB-180D-PGXJN6W2T	hu-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3069	202	PNLUHHYLQ	hu-pnluhhylq	50.0GB / 180 дней	50	180	22	Hungary 50GB 180Days	t
3070	202	HU-3.0GB-30D-PHD8GZ2VN	hu-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3071	202	HU-20.0GB-90D-PG3K0LHBC	hu-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3072	202	HU-1.0GB-365D-PCQXBW5UJ	hu-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3073	202	HU-1.0GB-30D-PM1HX6ES9	hu-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
3074	202	HU-3.0GB-30D-PJK6T8JT2	hu-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
3075	202	HU-5.0GB-30D-P87F6RTKY	hu-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
4280	256	PY-3.0GB-30D-PHD8GZ2VN	py-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4281	256	PY-20.0GB-90D-PG3K0LHBC	py-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2648	180	SV-6.0GB-15D-AIS002	sv-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2649	180	SV-1.0GB-7D-CKH823	sv-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2650	180	SV-5.0GB-30D-CKH825	sv-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2651	180	SV-10.0GB-30D-CKH826	sv-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2652	180	SV-3.0GB-30D-P6FNJUAP4	sv-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
2653	180	SV-3.0GB-30D-PHD8GZ2VN	sv-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2654	180	SV-20.0GB-90D-PG3K0LHBC	sv-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2655	180	SV-1.0GB-365D-PCQXBW5UJ	sv-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2656	180	SV-1.0GB-7D-PHS30M6EZ	sv-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2657	180	SV-1.0GB-365D-PYMC5N31Z	sv-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2658	180	SV-5.0GB-30D-PEW54FVD9	sv-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2659	180	SV-3.0GB-30D-PW6P3DX2G	sv-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2660	180	SV-20.0GB-90D-PB83STJL6	sv-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2661	180	SV-20.0GB-30D-PR3JZMC20	sv-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2662	180	SV-10.0GB-30D-P34FHRF8J	sv-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2682	181	EE-20.0GB-90D-PG3K0LHBC	ee-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2683	181	EE-1.0GB-365D-PCQXBW5UJ	ee-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1486	288	TN-1.0GB-7D-CKH495	tn-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2684	181	EE-1.0GB-30D-PM1HX6ES9	ee-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2685	181	EE-3.0GB-30D-PJK6T8JT2	ee-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2686	181	EE-5.0GB-30D-P87F6RTKY	ee-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2687	181	EE-1.0GB-7D-PV048NCRG	ee-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2688	181	EE-10.0GB-30D-P50GVS8GN	ee-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2689	181	EE-20.0GB-30D-PHC4X21NC	ee-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2690	181	EE-20.0GB-90D-P5NWWU08G	ee-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2691	181	EE-50.0GB-180D-PE70MYRZ5	ee-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
2692	181	EE-1.0GB-1D-PUDV52A3R	ee-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
2693	181	EE-1.5GB-1D-P34CJYA6C	ee-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2694	181	EE-1.0GB-7D-PHS30M6EZ	ee-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2695	181	EE-1.0GB-365D-PYMC5N31Z	ee-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2696	181	EE-5.0GB-30D-PEW54FVD9	ee-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2697	181	EE-3.0GB-30D-PW6P3DX2G	ee-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2707	182	SZ-1.0GB-7D-CKH495	sz-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2708	182	SZ-5.0GB-30D-CKH497	sz-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
3076	202	HU-1.0GB-7D-PV048NCRG	hu-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
3077	202	HU-10.0GB-30D-P50GVS8GN	hu-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
3078	202	HU-20.0GB-30D-PHC4X21NC	hu-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
3079	202	HU-20.0GB-90D-P5NWWU08G	hu-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
3080	202	HU-50.0GB-180D-PE70MYRZ5	hu-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
3081	202	HU-1.0GB-1D-PUDV52A3R	hu-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3082	202	HU-1.5GB-1D-P34CJYA6C	hu-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3083	202	HU-1.0GB-7D-PHS30M6EZ	hu-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3084	202	HU-1.0GB-365D-PYMC5N31Z	hu-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3085	202	HU-5.0GB-30D-PEW54FVD9	hu-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3086	202	HU-3.0GB-30D-PW6P3DX2G	hu-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3087	202	HU-20.0GB-90D-PB83STJL6	hu-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3088	202	HU-20.0GB-30D-PR3JZMC20	hu-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3089	202	HU-10.0GB-30D-P34FHRF8J	hu-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3090	202	HU-2.0GB-1D-PZ6R8ASH9	hu-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
3091	202	HU-3.0GB-1D-PE01DJZS7	hu-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3092	202	HU-0.5GB-1D-P61RQP7ZW	hu-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
3093	202	HU-0.3GB-1D-P82Y6VYRL	hu-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
3094	203	IS-3.0GB-30D-CKH006	is-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3095	203	IS-5.0GB-30D-CKH007	is-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3096	203	CKH089	is-ckh089	3.0GB / 30 дней	3	30	3.8	Iceland 3GB 30Days	t
3097	203	CKH128	is-ckh128	5.0GB / 30 дней	5	30	5.7	Iceland 5GB 30Days	t
3098	203	CKH217	is-ckh217	1.0GB / 7 дней	1	7	1.5	Iceland 1GB 7Days	t
2709	182	SZ-6.0GB-15D-AIS002	sz-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4282	256	PY-1.0GB-365D-PCQXBW5UJ	py-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4283	256	PY-1.0GB-7D-PHS30M6EZ	py-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4284	256	PY-1.0GB-365D-PYMC5N31Z	py-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4285	256	PY-5.0GB-30D-PEW54FVD9	py-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4286	256	PY-3.0GB-30D-PW6P3DX2G	py-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4287	256	PY-20.0GB-90D-PB83STJL6	py-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4288	256	PY-20.0GB-30D-PR3JZMC20	py-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4326	258	JC034	ph-jc034	1.0GB / 7 дней	1	7	1.8	Philippines 1GB 7Days	t
4327	258	JC035	ph-jc035	3.0GB / 15 дней	3	15	4.6	Philippines 3GB 15Days	t
4328	258	JC036	ph-jc036	5.0GB / 30 дней	5	30	7	Philippines 5GB 30Days	t
4329	258	JC037	ph-jc037	10.0GB / 30 дней	10	30	12.2	Philippines 10GB 30Days	t
4330	258	PH-6.0GB-8D-AIS001	ph-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
4331	258	PH-6.0GB-15D-AIS002	ph-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4332	258	JC099	ph-jc099	20.0GB / 30 дней	20	30	20	Philippines 20GB 30Days	t
4333	258	PH-1.0GB-7D-CKH823	ph-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4334	258	PH-5.0GB-30D-CKH825	ph-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4335	258	PH-10.0GB-30D-CKH826	ph-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4336	258	PH-1.0GB-7D-JC165	ph-jc165	1.0GB / 7 дней	1	7	1.8	Asia (7 areas) 1GB 7Days	t
4337	258	PH-3.0GB-15D-JC166	ph-jc166	3.0GB / 15 дней	3	15	4.6	Asia (7 areas) 3GB 15Days	t
4338	258	PH-5.0GB-30D-JC167	ph-jc167	5.0GB / 30 дней	5	30	7	Asia (7 areas) 5GB 30Days	t
1309	279	JC042	lk-jc042	1.0GB / 7 дней	1	7	2.9	Sri Lanka 1GB 7Days	t
1347	280	CKH388	sd-ckh388	1.0GB / 7 дней	1	7	11.2	Sudan 1GB 7Days	t
1359	281	SJ-6.0GB-15D-AIS002	sj-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2710	182	SZ-1.0GB-7D-CKH823	sz-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2711	182	SZ-5.0GB-30D-CKH825	sz-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2712	182	SZ-10.0GB-30D-CKH826	sz-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2713	182	SZ-3.0GB-30D-P1XXDOD0C	sz-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2714	182	SZ-3.0GB-30D-PHD8GZ2VN	sz-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2715	182	SZ-20.0GB-90D-PG3K0LHBC	sz-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2716	182	SZ-1.0GB-365D-PCQXBW5UJ	sz-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2717	182	SZ-1.0GB-7D-PHS30M6EZ	sz-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2718	182	SZ-1.0GB-365D-PYMC5N31Z	sz-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2719	182	SZ-5.0GB-30D-PEW54FVD9	sz-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2720	182	SZ-3.0GB-30D-PW6P3DX2G	sz-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1360	282	SE-3.0GB-30D-CKH006	se-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
1361	282	SE-5.0GB-30D-CKH007	se-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1362	282	CKH101	se-ckh101	3.0GB / 30 дней	3	30	2.3	Sweden 3GB 30Days	t
1363	282	CKH140	se-ckh140	5.0GB / 30 дней	5	30	3.4	Sweden 5GB 30Days	t
1364	282	CKH199	se-ckh199	1.0GB / 7 дней	1	7	0.9	Sweden 1GB 7Days	t
1365	282	CKH200	se-ckh200	3.0GB / 15 дней	3	15	2.2	Sweden 3GB 15Days	t
1366	282	CKH201	se-ckh201	10.0GB / 30 дней	10	30	6.1	Sweden 10GB 30Days	t
1367	282	SE-1.0GB-7D-CKH484	se-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1604	294	UZ-1.0GB-7D-CKH823	uz-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2721	182	SZ-20.0GB-90D-PB83STJL6	sz-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3099	203	CKH218	is-ckh218	3.0GB / 15 дней	3	15	3.7	Iceland 3GB 15Days	t
3100	203	CKH219	is-ckh219	10.0GB / 30 дней	10	30	9.9	Iceland 10GB 30Days	t
3101	203	IS-1.0GB-7D-CKH484	is-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3102	203	IS-10.0GB-30D-CKH486	is-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
3103	203	IS-20.0GB-30D-CKH500	is-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
3104	203	IS-6.0GB-15D-AIS002	is-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3105	203	CKH714	is-ckh714	20.0GB / 30 дней	20	30	16.8	Iceland 20GB 30Days	t
3106	203	IS-1.0GB-7D-CKH823	is-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3107	203	IS-5.0GB-30D-CKH825	is-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3108	203	IS-10.0GB-30D-CKH826	is-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3109	203	IS-20.0GB-90D-P7VCE7FKY	is-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3110	203	IS-50.0GB-180D-PGXJN6W2T	is-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3111	203	PKK3BVKVF	is-pkk3bvkvf	50.0GB / 180 дней	50	180	37	Iceland 50GB 180Days	t
3112	203	IS-3.0GB-30D-PHD8GZ2VN	is-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3157	204	ID-1.0GB-7D-JC183	id-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
2744	185	FI-20.0GB-90D-PG3K0LHBC	fi-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2745	185	FI-1.0GB-365D-PCQXBW5UJ	fi-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2746	185	FI-1.0GB-30D-PM1HX6ES9	fi-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2747	185	FI-3.0GB-30D-PJK6T8JT2	fi-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2748	185	FI-5.0GB-30D-P87F6RTKY	fi-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2749	185	FI-1.0GB-7D-PV048NCRG	fi-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2750	185	FI-10.0GB-30D-P50GVS8GN	fi-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2751	185	FI-20.0GB-30D-PHC4X21NC	fi-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2752	185	FI-20.0GB-90D-P5NWWU08G	fi-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2753	185	FI-50.0GB-180D-PE70MYRZ5	fi-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
2754	185	FI-1.0GB-1D-PUDV52A3R	fi-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
2755	185	FI-1.5GB-1D-P34CJYA6C	fi-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2756	185	FI-1.0GB-7D-PHS30M6EZ	fi-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2757	185	FI-1.0GB-365D-PYMC5N31Z	fi-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2758	185	FI-5.0GB-30D-PEW54FVD9	fi-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2759	185	FI-3.0GB-30D-PW6P3DX2G	fi-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2760	185	FI-20.0GB-90D-PB83STJL6	fi-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2761	185	FI-20.0GB-30D-PR3JZMC20	fi-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2762	185	FI-10.0GB-30D-P34FHRF8J	fi-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2763	185	FI-2.0GB-1D-PZ6R8ASH9	fi-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2764	185	FI-3.0GB-1D-PE01DJZS7	fi-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
2765	185	FI-0.5GB-1D-P61RQP7ZW	fi-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2766	185	FI-0.3GB-1D-P82Y6VYRL	fi-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2771	186	GF-5.0GB-30D-P7GA02CZP	gf-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2772	186	GF-3.0GB-30D-PQB69VW8U	gf-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2773	186	GF-1.0GB-7D-PUSHF5X80	gf-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2782	187	GA-3.0GB-30D-P1XXDOD0C	ga-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2783	187	GA-3.0GB-30D-PHD8GZ2VN	ga-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2784	187	GA-20.0GB-90D-PG3K0LHBC	ga-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2785	187	GA-1.0GB-365D-PCQXBW5UJ	ga-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2786	187	GA-1.0GB-7D-PHS30M6EZ	ga-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2787	187	GA-1.0GB-365D-PYMC5N31Z	ga-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3113	203	IS-20.0GB-90D-PG3K0LHBC	is-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3114	203	IS-1.0GB-365D-PCQXBW5UJ	is-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3124	203	IS-1.5GB-1D-P34CJYA6C	is-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3125	203	IS-1.0GB-7D-PHS30M6EZ	is-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3126	203	IS-1.0GB-365D-PYMC5N31Z	is-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3127	203	IS-5.0GB-30D-PEW54FVD9	is-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3128	203	IS-3.0GB-30D-PW6P3DX2G	is-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3129	203	IS-20.0GB-90D-PB83STJL6	is-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3130	203	IS-20.0GB-30D-PR3JZMC20	is-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3131	203	IS-10.0GB-30D-P34FHRF8J	is-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3132	203	IS-2.0GB-1D-PZ6R8ASH9	is-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
3133	203	IS-3.0GB-1D-PE01DJZS7	is-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3134	203	IS-0.5GB-1D-P61RQP7ZW	is-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
3135	203	IS-0.3GB-1D-P82Y6VYRL	is-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
3136	204	JC056	id-jc056	1.0GB / 7 дней	1	7	0.7	Indonesia 1GB 7Days	t
3137	204	JC057	id-jc057	3.0GB / 15 дней	3	15	1.7	Indonesia 3GB 15Days	t
3138	204	JC058	id-jc058	5.0GB / 30 дней	5	30	2.7	Indonesia 5GB 30Days	t
3139	204	JC059	id-jc059	10.0GB / 30 дней	10	30	4.7	Indonesia 10GB 30Days	t
3140	204	ID-6.0GB-8D-AIS001	id-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3141	204	ID-6.0GB-15D-AIS002	id-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3142	204	JC143	id-jc143	20.0GB / 30 дней	20	30	8.2	Indonesia 20GB 30Days	t
3143	204	ID-1.0GB-7D-CKH823	id-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3144	204	ID-5.0GB-30D-CKH825	id-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3145	204	ID-10.0GB-30D-CKH826	id-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3146	204	ID-1.0GB-7D-JC165	id-jc165	1.0GB / 7 дней	1	7	1.8	Asia (7 areas) 1GB 7Days	t
2788	187	GA-5.0GB-30D-PEW54FVD9	ga-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2789	187	GA-3.0GB-30D-PW6P3DX2G	ga-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2790	187	GA-20.0GB-90D-PB83STJL6	ga-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2791	187	GA-20.0GB-30D-PR3JZMC20	ga-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2792	187	GA-10.0GB-30D-P34FHRF8J	ga-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2821	189	GH-20.0GB-30D-PR3JZMC20	gh-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2822	189	GH-10.0GB-30D-P34FHRF8J	gh-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2825	190	CKH114	gi-ckh114	3.0GB / 30 дней	3	30	7.3	Gibraltar 3GB 30Days	t
2826	190	CKH481	gi-ckh481	1.0GB / 7 дней	1	7	2.9	Gibraltar 1GB 7Days	t
2827	190	CKH482	gi-ckh482	3.0GB / 15 дней	3	15	7.2	Gibraltar 3GB 15Days	t
2828	190	GI-1.0GB-7D-CKH484	gi-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2829	190	GI-10.0GB-30D-CKH486	gi-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2830	190	GI-20.0GB-30D-CKH500	gi-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2831	190	GI-1.0GB-7D-CKH823	gi-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2832	190	GI-5.0GB-30D-CKH825	gi-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2833	190	GI-10.0GB-30D-CKH826	gi-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2834	190	GI-20.0GB-90D-P7VCE7FKY	gi-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2835	190	GI-50.0GB-180D-PGXJN6W2T	gi-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1444	284	TW-6.0GB-15D-AIS002	tw-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1462	285	TJ-6.0GB-15D-AIS002	tj-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1463	286	MB027	tz-mb027	1.0GB / 7 дней	1	7	3.6	Tanzania 1GB 7Days	t
1464	286	MB032	tz-mb032	3.0GB / 15 дней	3	15	8.9	Tanzania 3GB 15Days	t
1465	286	TZ-1.0GB-7D-CKH495	tz-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1466	286	TZ-5.0GB-30D-CKH497	tz-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1467	286	TZ-6.0GB-15D-AIS002	tz-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1468	286	TZ-1.0GB-7D-CKH823	tz-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1469	286	TZ-5.0GB-30D-CKH825	tz-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1470	286	TZ-10.0GB-30D-CKH826	tz-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1471	286	TZ-3.0GB-30D-P1XXDOD0C	tz-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1472	286	TZ-3.0GB-30D-PHD8GZ2VN	tz-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1473	286	TZ-20.0GB-90D-PG3K0LHBC	tz-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1474	286	TZ-1.0GB-365D-PCQXBW5UJ	tz-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1475	286	TZ-1.0GB-7D-PHS30M6EZ	tz-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1476	286	TZ-1.0GB-365D-PYMC5N31Z	tz-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1477	286	TZ-5.0GB-30D-PEW54FVD9	tz-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1478	286	TZ-3.0GB-30D-PW6P3DX2G	tz-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1482	287	TO-6.0GB-15D-AIS002	to-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1483	288	KR001	tn-kr001	1.0GB / 7 дней	1	7	1.8	Tunisia 1GB 7Days	t
1484	288	KR003	tn-kr003	5.0GB / 30 дней	5	30	7	Tunisia 5GB 30Days	t
1485	288	KR004	tn-kr004	10.0GB / 30 дней	10	30	12.2	Tunisia 10GB 30Days	t
2836	190	GI-3.0GB-30D-PHD8GZ2VN	gi-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3147	204	ID-3.0GB-15D-JC166	id-jc166	3.0GB / 15 дней	3	15	4.6	Asia (7 areas) 3GB 15Days	t
3148	204	ID-5.0GB-30D-JC167	id-jc167	5.0GB / 30 дней	5	30	7	Asia (7 areas) 5GB 30Days	t
3149	204	ID-10.0GB-30D-JC168	id-jc168	10.0GB / 30 дней	10	30	12.2	Asia (7 areas) 10GB 30Days	t
3150	204	ID-20.0GB-30D-JC169	id-jc169	20.0GB / 30 дней	20	30	20	Asia (7 areas) 20GB 30Days	t
3151	204	ID-1.0GB-30D-JC177	id-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
3152	204	ID-5.0GB-30D-JC178	id-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
4339	258	PH-10.0GB-30D-JC168	ph-jc168	10.0GB / 30 дней	10	30	12.2	Asia (7 areas) 10GB 30Days	t
4340	258	PH-20.0GB-30D-JC169	ph-jc169	20.0GB / 30 дней	20	30	20	Asia (7 areas) 20GB 30Days	t
4341	258	PH-1.0GB-30D-JC177	ph-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
4342	258	PH-5.0GB-30D-JC178	ph-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
4343	258	PH-3.0GB-15D-JC179	ph-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
4344	258	PH-10.0GB-30D-JC180	ph-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
4345	258	PH-20.0GB-90D-JC181	ph-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
4346	258	PH-50.0GB-180D-JC182	ph-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
4347	258	PH-1.0GB-7D-JC183	ph-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
4348	258	PH-3.0GB-30D-PHD8GZ2VN	ph-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4349	258	PH-20.0GB-90D-PG3K0LHBC	ph-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4350	258	PYEPCSNFU	ph-pyepcsnfu	50.0GB / 180 дней	50	180	45	Philippines 50GB 180Days	t
1512	291	CKH392	ug-ckh392	1.0GB / 7 дней	1	7	5.7	Uganda 1GB 7Days	t
2837	190	GI-20.0GB-90D-PG3K0LHBC	gi-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2838	190	GI-1.0GB-365D-PCQXBW5UJ	gi-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2839	190	GI-1.0GB-7D-PHS30M6EZ	gi-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2840	190	GI-1.0GB-365D-PYMC5N31Z	gi-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2841	190	GI-5.0GB-30D-PEW54FVD9	gi-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2842	190	GI-3.0GB-30D-PW6P3DX2G	gi-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2843	190	GI-20.0GB-90D-PB83STJL6	gi-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2844	190	GI-20.0GB-30D-PR3JZMC20	gi-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2845	190	GI-10.0GB-30D-P34FHRF8J	gi-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2868	191	GR-3.0GB-30D-PJK6T8JT2	gr-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
2869	191	GR-5.0GB-30D-P87F6RTKY	gr-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2870	191	GR-1.0GB-7D-PV048NCRG	gr-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2871	191	GR-10.0GB-30D-P50GVS8GN	gr-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2872	191	GR-20.0GB-30D-PHC4X21NC	gr-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2873	191	GR-20.0GB-90D-P5NWWU08G	gr-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2874	191	GR-50.0GB-180D-PE70MYRZ5	gr-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
1513	291	CKH421	ug-ckh421	3.0GB / 15 дней	3	15	14.1	Uganda 3GB 15Days	t
1514	291	UG-1.0GB-7D-CKH495	ug-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1515	291	UG-5.0GB-30D-CKH497	ug-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1516	291	UG-1.0GB-7D-CKH823	ug-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1517	291	UG-5.0GB-30D-CKH825	ug-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1518	291	UG-10.0GB-30D-CKH826	ug-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1519	291	UG-3.0GB-30D-P1XXDOD0C	ug-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1530	292	UA-3.0GB-30D-CKH006	ua-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
1531	292	UA-5.0GB-30D-CKH007	ua-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1532	292	CKH103	ua-ckh103	3.0GB / 30 дней	3	30	1.8	Ukraine 3GB 30Days	t
1533	292	CKH142	ua-ckh142	5.0GB / 30 дней	5	30	2.7	Ukraine 5GB 30Days	t
1534	292	CKH250	ua-ckh250	1.0GB / 7 дней	1	7	0.7	Ukraine 1GB 7Days	t
1535	292	CKH251	ua-ckh251	3.0GB / 15 дней	3	15	1.7	Ukraine 3GB 15Days	t
1536	292	CKH252	ua-ckh252	10.0GB / 30 дней	10	30	4.7	Ukraine 10GB 30Days	t
1537	292	UA-1.0GB-7D-CKH484	ua-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1538	292	UA-10.0GB-30D-CKH486	ua-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1539	292	UA-20.0GB-30D-CKH500	ua-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1540	292	UA-6.0GB-15D-AIS002	ua-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1541	292	UA-1.0GB-7D-CKH823	ua-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1542	292	UA-5.0GB-30D-CKH825	ua-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1543	292	UA-10.0GB-30D-CKH826	ua-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1544	292	UA-20.0GB-90D-P7VCE7FKY	ua-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1545	292	UA-50.0GB-180D-PGXJN6W2T	ua-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2875	191	GR-1.0GB-1D-PUDV52A3R	gr-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3153	204	ID-3.0GB-15D-JC179	id-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
3154	204	ID-10.0GB-30D-JC180	id-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
3155	204	ID-20.0GB-90D-JC181	id-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
3156	204	ID-50.0GB-180D-JC182	id-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
3158	204	ID-3.0GB-30D-PHD8GZ2VN	id-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3159	204	ID-20.0GB-90D-PG3K0LHBC	id-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3160	204	ID-50.0GB-180D-P4GNDNA36	id-p4gndna36	50.0GB / 180 дней	50	180	45	Asia (7 areas) 50GB 180Days	t
3161	204	ID-1.0GB-365D-PCQXBW5UJ	id-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4351	258	PH-50.0GB-180D-P4GNDNA36	ph-p4gndna36	50.0GB / 180 дней	50	180	45	Asia (7 areas) 50GB 180Days	t
4356	258	PH-1.0GB-7D-PHS30M6EZ	ph-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4358	258	PH-5.0GB-30D-PEW54FVD9	ph-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4370	259	PL-5.0GB-30D-CKH007	pl-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
4371	259	CKH096	pl-ckh096	3.0GB / 30 дней	3	30	1.8	Poland 3GB 30Days	t
4372	259	CKH135	pl-ckh135	5.0GB / 30 дней	5	30	2.7	Poland 5GB 30Days	t
4373	259	CKH236	pl-ckh236	1.0GB / 7 дней	1	7	0.7	Poland 1GB 7Days	t
4374	259	CKH237	pl-ckh237	3.0GB / 15 дней	3	15	1.7	Poland 3GB 15Days	t
4375	259	PL-1.0GB-7D-CKH484	pl-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2876	191	GR-1.5GB-1D-P34CJYA6C	gr-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2877	191	GR-1.0GB-7D-PHS30M6EZ	gr-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2878	191	GR-1.0GB-365D-PYMC5N31Z	gr-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2879	191	GR-5.0GB-30D-PEW54FVD9	gr-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2880	191	GR-3.0GB-30D-PW6P3DX2G	gr-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2881	191	GR-20.0GB-90D-PB83STJL6	gr-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2882	191	GR-20.0GB-30D-PR3JZMC20	gr-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2883	191	GR-10.0GB-30D-P34FHRF8J	gr-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2884	191	GR-2.0GB-1D-PZ6R8ASH9	gr-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2885	191	GR-3.0GB-1D-PE01DJZS7	gr-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
2886	191	GR-0.5GB-1D-P61RQP7ZW	gr-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2887	191	GR-0.3GB-1D-P82Y6VYRL	gr-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2909	194	GP-5.0GB-30D-P7GA02CZP	gp-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2910	194	GP-3.0GB-30D-PQB69VW8U	gp-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2911	194	GP-1.0GB-7D-PUSHF5X80	gp-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2924	195	PIN2SHYSA	gu-pin2shysa	5.0GB / 30 дней	5	30	13.6		t
2925	195	PMYQIPASB	gu-pmyqipasb	10.0GB / 30 дней	10	30	23		t
2926	195	P04857JJB	gu-p04857jjb	20.0GB / 30 дней	20	30	40		t
2938	196	GT-3.0GB-30D-PHD8GZ2VN	gt-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2939	196	GT-20.0GB-90D-PG3K0LHBC	gt-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2940	196	GT-1.0GB-365D-PCQXBW5UJ	gt-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2941	196	GT-1.0GB-7D-PHS30M6EZ	gt-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2942	196	GT-1.0GB-365D-PYMC5N31Z	gt-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2943	196	GT-5.0GB-30D-PEW54FVD9	gt-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1599	294	UZ-6.0GB-8D-AIS001	uz-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
1600	294	UZ-6.0GB-15D-AIS002	uz-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1601	294	CKH1017	uz-ckh1017	1.0GB / 7 дней	1	7	1.5	Uzbekistan 1GB 7Days	t
1602	294	CKH1029	uz-ckh1029	5.0GB / 30 дней	5	30	5.7	Uzbekistan 5GB 30Days	t
1603	294	CKH766	uz-ckh766	10.0GB / 30 дней	10	30	9.9	Uzbekistan 10GB 30Days	t
2944	196	GT-3.0GB-30D-PW6P3DX2G	gt-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2945	196	GT-20.0GB-90D-PB83STJL6	gt-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2946	196	GT-20.0GB-30D-PR3JZMC20	gt-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2947	196	GT-10.0GB-30D-P34FHRF8J	gt-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2958	197	CKH788	gg-ckh788	20.0GB / 30 дней	20	30	50	Guernsey 20GB 30Days	t
2959	197	GG-1.0GB-7D-CKH823	gg-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3162	204	PXCJQ9KNR	id-pxcjq9knr	0.49GB / 1 дней	0.49	1	0.5	Indonesia 500MB/Day	t
3163	204	PGBV9EXGK	id-pgbv9exgk	1.0GB / 1 дней	1	1	0.9	Indonesia 1GB/Day	t
3164	204	P3H6TP1TU	id-p3h6tp1tu	3.0GB / 30 дней	3	30	1.8	Indonesia 3GB 30Days	t
3165	204	ID-1.0GB-7D-PHS30M6EZ	id-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3166	204	ID-1.0GB-365D-PYMC5N31Z	id-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3167	204	ID-5.0GB-30D-PEW54FVD9	id-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3168	204	ID-3.0GB-30D-PW6P3DX2G	id-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3169	204	ID-20.0GB-90D-PB83STJL6	id-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3170	204	ID-20.0GB-30D-PR3JZMC20	id-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3171	204	ID-10.0GB-30D-P34FHRF8J	id-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3172	204	ID-0.5GB-1D-PACK04L3R	id-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
3173	204	ID-1.0GB-1D-PXJ8HG40S	id-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
3174	204	ID-2.0GB-1D-PVBKS19B4	id-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
4376	259	PL-10.0GB-30D-CKH486	pl-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
4377	259	PL-20.0GB-30D-CKH500	pl-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
4378	259	PL-6.0GB-15D-AIS002	pl-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4403	259	PL-20.0GB-90D-PB83STJL6	pl-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4404	259	PL-20.0GB-30D-PR3JZMC20	pl-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4405	259	PL-10.0GB-30D-P34FHRF8J	pl-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4406	259	PL-2.0GB-1D-PZ6R8ASH9	pl-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
4407	259	PL-3.0GB-1D-PE01DJZS7	pl-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
4408	259	PL-0.5GB-1D-P61RQP7ZW	pl-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
4409	259	PL-0.3GB-1D-P82Y6VYRL	pl-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
4444	260	PT-20.0GB-90D-PB83STJL6	pt-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2960	197	GG-5.0GB-30D-CKH825	gg-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2961	197	GG-10.0GB-30D-CKH826	gg-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2962	197	GG-20.0GB-90D-P7VCE7FKY	gg-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
2963	197	GG-50.0GB-180D-PGXJN6W2T	gg-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
2964	197	GG-3.0GB-30D-PHD8GZ2VN	gg-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2965	197	GG-20.0GB-90D-PG3K0LHBC	gg-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2966	197	GG-1.0GB-365D-PCQXBW5UJ	gg-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2997	200	HN-1.0GB-365D-PCQXBW5UJ	hn-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2998	200	HN-1.0GB-7D-PHS30M6EZ	hn-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2999	200	HN-1.0GB-365D-PYMC5N31Z	hn-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3000	200	HN-5.0GB-30D-PEW54FVD9	hn-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3001	200	HN-3.0GB-30D-PW6P3DX2G	hn-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3002	200	HN-20.0GB-90D-PB83STJL6	hn-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3003	200	HN-20.0GB-30D-PR3JZMC20	hn-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3004	200	HN-10.0GB-30D-P34FHRF8J	hn-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3013	201	HK-1.0GB-7D-CKH823	hk-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3014	201	HK-5.0GB-30D-CKH825	hk-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1661	296	VG-6.0GB-15D-AIS002	vg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1662	296	VG-5.0GB-1D-PX18HJ4XW	vg-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1663	296	VG-1.0GB-1D-P8JCL47FC	vg-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
3015	201	HK-10.0GB-30D-CKH826	hk-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3016	201	HK-1.0GB-7D-JC172	hk-jc172	1.0GB / 7 дней	1	7	1.5	China (mainland HK Macao) 1GB 7Days	t
3017	201	HK-3.0GB-15D-JC173	hk-jc173	3.0GB / 15 дней	3	15	3.7	China (mainland HK Macao) 3GB 15Days	t
3018	201	HK-5.0GB-30D-JC174	hk-jc174	5.0GB / 30 дней	5	30	5.7	China (mainland HK Macao) 5GB 30Days	t
3019	201	HK-10.0GB-30D-JC175	hk-jc175	10.0GB / 30 дней	10	30	9.9	China (mainland HK Macao) 10GB 30Days	t
3020	201	HK-20.0GB-30D-JC176	hk-jc176	20.0GB / 30 дней	20	30	16.8	China (mainland HK Macao) 20GB 30Days	t
3021	201	HK-1.0GB-30D-JC177	hk-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
3022	201	HK-5.0GB-30D-JC178	hk-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
3023	201	HK-3.0GB-15D-JC179	hk-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
3024	201	HK-10.0GB-30D-JC180	hk-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
3025	201	HK-20.0GB-90D-JC181	hk-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
3026	201	HK-50.0GB-180D-JC182	hk-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
3027	201	HK-1.0GB-7D-JC183	hk-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
3028	201	HK-3.0GB-30D-PHD8GZ2VN	hk-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3175	204	ID-3.0GB-1D-PM5T3Z4UM	id-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
3176	204	P3RA09KRL	id-p3ra09krl	2.0GB / 1 дней	2	1	1.6	Indonesia 2GB/Day	t
3177	204	PWV1DH08R	id-pwv1dh08r	3.0GB / 1 дней	3	1	2.4	Indonesia 3GB/Day	t
3178	204	P2KEH0D5E	id-p2keh0d5e	10.0GB / 1 дней	10	1	8	Indonesia 10GB/Day	t
3179	204	ID-1.0GB-1D-P0N8SUBG5	id-p0n8subg5	1.0GB / 1 дней	1	1	1.7	Asia (7 areas) 1GB/Day	t
3180	204	ID-0.5GB-1D-PX5NT8Z4K	id-px5nt8z4k	0.49GB / 1 дней	0.49	1	0.9	Asia (7 areas) 500MB/Day	t
3181	204	ID-2.0GB-1D-PBZUB2S60	id-pbzub2s60	2.0GB / 1 дней	2	1	3	Asia (7 areas) 2GB/Day	t
3182	204	ID-5.0GB-1D-PJ2W7KTJ4	id-pj2w7ktj4	5.0GB / 1 дней	5	1	6	Asia (7 areas) 5GB/Day	t
3183	205	IR-6.0GB-15D-AIS002	ir-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3185	206	PS0TRW67Y	iq-ps0trw67y	1.0GB / 1 дней	1	1	2.2	Iraq 1GB/Day	t
3186	206	PQ206NZYN	iq-pq206nzyn	2.0GB / 1 дней	2	1	4.3	Iraq 2GB/Day	t
3187	206	P3YAYU76M	iq-p3yayu76m	3.0GB / 1 дней	3	1	5.6	Iraq 3GB/Day	t
3188	206	IQ-10.0GB-1D-PLR26GSE7	iq-plr26gse7	10.0GB / 1 дней	10	1	22	Gulf Region 10GB/Day	t
3189	206	IQ-5.0GB-1D-PLK713DWL	iq-plk713dwl	5.0GB / 1 дней	5	1	10.8	Gulf Region 5GB/Day	t
3190	206	IQ-1.0GB-1D-P40YDJ9WA	iq-p40ydj9wa	1.0GB / 1 дней	1	1	2.9	Gulf Region 1GB/Day	t
3191	206	IQ-0.5GB-1D-PW9U86NGE	iq-pw9u86nge	0.49GB / 1 дней	0.49	1	1.8	Gulf Region 500MB/Day	t
3192	206	IQ-10.0GB-30D-P9DH2MUN5	iq-p9dh2mun5	10.0GB / 30 дней	10	30	22	Gulf Region 10GB 30Days Single Use	t
3206	207	IE-6.0GB-15D-AIS002	ie-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3207	207	CKH720	ie-ckh720	20.0GB / 30 дней	20	30	10.6	Ireland 20GB 30Days	t
3208	207	IE-1.0GB-7D-CKH823	ie-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3215	207	IE-20.0GB-90D-PG3K0LHBC	ie-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3216	207	IE-1.0GB-365D-PCQXBW5UJ	ie-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3217	207	PC3TTT87P	ie-pc3ttt87p	0.49GB / 3 дней	0.49	3	0.6	Ireland 500MB 3Days	t
1699	299	ZW-6.0GB-15D-AIS002	zw-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1700	300	AX-3.0GB-30D-CKH006	ax-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
1701	300	AX-5.0GB-30D-CKH007	ax-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1702	300	CKH105	ax-ckh105	3.0GB / 30 дней	3	30	4.7	Aaland Islands 3GB 30Days	t
1703	300	CKH144	ax-ckh144	5.0GB / 30 дней	5	30	7	Aaland Islands 5GB 30Days	t
3036	201	HK-1.0GB-365D-PYMC5N31Z	hk-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3037	201	HK-5.0GB-30D-PEW54FVD9	hk-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3038	201	HK-3.0GB-30D-PW6P3DX2G	hk-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3039	201	HK-20.0GB-90D-PB83STJL6	hk-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3040	201	HK-20.0GB-30D-PR3JZMC20	hk-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3041	201	HK-10.0GB-30D-P34FHRF8J	hk-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1704	300	CKH256	ax-ckh256	1.0GB / 7 дней	1	7	1.8	Aaland Islands 1GB 7Days	t
1705	300	CKH257	ax-ckh257	3.0GB / 15 дней	3	15	4.6	Aaland Islands 3GB 15Days	t
1706	300	AX-1.0GB-7D-CKH484	ax-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1707	300	AX-10.0GB-30D-CKH486	ax-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
3042	201	HK-0.5GB-1D-PACK04L3R	hk-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
3043	201	HK-1.0GB-1D-PXJ8HG40S	hk-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
3044	201	HK-2.0GB-1D-PVBKS19B4	hk-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
3045	201	HK-3.0GB-1D-PM5T3Z4UM	hk-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
3046	201	HK-0.5GB-1D-PN6QWT0Q4	hk-pn6qwt0q4	0.49GB / 1 дней	0.49	1	0.9	China (mainland HK Macao) 500MB/Day	t
1679	298	CKH393	zm-ckh393	1.0GB / 7 дней	1	7	4.6	Zambia 1GB 7Days	t
1680	298	CKH422	zm-ckh422	3.0GB / 15 дней	3	15	11.2	Zambia 3GB 15Days	t
1681	298	CKH451	zm-ckh451	5.0GB / 30 дней	5	30	17.1	Zambia 5GB 30Days	t
1682	298	ZM-1.0GB-7D-CKH495	zm-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1683	298	ZM-5.0GB-30D-CKH497	zm-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1684	298	ZM-6.0GB-15D-AIS002	zm-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1708	300	AX-20.0GB-30D-CKH500	ax-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1709	300	AX-6.0GB-15D-AIS002	ax-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1710	300	CKH740	ax-ckh740	20.0GB / 30 дней	20	30	20	Aaland Islands 20GB 30Days	t
3047	201	HK-1.0GB-1D-P78RBUJQ4	hk-p78rbujq4	1.0GB / 1 дней	1	1	1.6	China (mainland HK Macao) 1GB/Day	t
3048	201	HK-2.0GB-1D-PY0WGY2C1	hk-py0wgy2c1	2.0GB / 1 дней	2	1	2.5	China (mainland HK Macao) 2GB/Day	t
3049	201	HK-3.0GB-1D-PB64TT7WN	hk-pb64tt7wn	3.0GB / 1 дней	3	1	3.8	China (mainland HK Macao) 3GB/Day	t
3050	201	PG9WP0YY6	hk-pg9wp0yy6	10.0GB / 1 дней	10	1	4.6		t
3051	201	P6SW3B9NG	hk-p6sw3b9ng	0.49GB / 1 дней	0.49	1	0.45	Hong Kong (China) 500MB/Day	t
3056	202	CKH178	hu-ckh178	1.0GB / 7 дней	1	7	0.9	Hungary 1GB 7Days	t
3057	202	CKH179	hu-ckh179	3.0GB / 15 дней	3	15	2.2	Hungary 3GB 15Days	t
1719	139	!RG-3.0GB-30D-CKH006	!rg-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
1720	139	!RG-5.0GB-30D-CKH007	!rg-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1721	139	!RG-1.0GB-7D-CKH484	!rg-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3058	202	CKH180	hu-ckh180	10.0GB / 30 дней	10	30	6.1	Hungary 10GB 30Days	t
3218	207	IE-1.0GB-30D-PM1HX6ES9	ie-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
3219	207	IE-3.0GB-30D-PJK6T8JT2	ie-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
3220	207	IE-5.0GB-30D-P87F6RTKY	ie-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
3221	207	IE-1.0GB-7D-PV048NCRG	ie-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
3222	207	IE-10.0GB-30D-P50GVS8GN	ie-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
3223	207	IE-20.0GB-30D-PHC4X21NC	ie-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
3224	207	IE-20.0GB-90D-P5NWWU08G	ie-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
3225	207	IE-50.0GB-180D-PE70MYRZ5	ie-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
3226	207	IE-1.0GB-1D-PUDV52A3R	ie-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3227	207	IE-1.5GB-1D-P34CJYA6C	ie-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3228	207	IE-1.0GB-7D-PHS30M6EZ	ie-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3229	207	IE-1.0GB-365D-PYMC5N31Z	ie-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3230	207	IE-5.0GB-30D-PEW54FVD9	ie-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3231	207	IE-3.0GB-30D-PW6P3DX2G	ie-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4445	260	PT-20.0GB-30D-PR3JZMC20	pt-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4452	261	CKH315	pr-ckh315	1.0GB / 7 дней	1	7	2.9	Puerto Rico 1GB 7Days	t
4453	261	CKH331	pr-ckh331	3.0GB / 15 дней	3	15	7.2	Puerto Rico 3GB 15Days	t
4454	261	CKH347	pr-ckh347	5.0GB / 30 дней	5	30	11	Puerto Rico 5GB 30Days	t
4455	261	PR-1.0GB-7D-CKH487	pr-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
4456	261	PR-3.0GB-15D-CKH488	pr-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
4457	261	PR-5.0GB-30D-CKH489	pr-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
4458	261	PR-10.0GB-30D-CKH490	pr-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
4459	261	PR-6.0GB-15D-AIS002	pr-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4460	261	PR-1.0GB-7D-CKH823	pr-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4461	261	PR-5.0GB-30D-CKH825	pr-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4462	261	PR-10.0GB-30D-CKH826	pr-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4463	261	PR-3.0GB-30D-P6FNJUAP4	pr-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
4464	261	PR-3.0GB-30D-PHD8GZ2VN	pr-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4465	261	PR-20.0GB-90D-PG3K0LHBC	pr-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4466	261	PR-1.0GB-365D-PCQXBW5UJ	pr-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4467	261	PR-1.0GB-7D-PHS30M6EZ	pr-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4468	261	PR-1.0GB-365D-PYMC5N31Z	pr-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4469	261	PR-5.0GB-30D-PEW54FVD9	pr-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4470	261	PR-3.0GB-30D-PW6P3DX2G	pr-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4471	261	PR-20.0GB-90D-PB83STJL6	pr-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4472	261	PR-20.0GB-30D-PR3JZMC20	pr-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4473	261	PR-10.0GB-30D-P34FHRF8J	pr-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4474	261	PR-5.0GB-1D-PX18HJ4XW	pr-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
3560	221	LR-20.0GB-90D-PB83STJL6	lr-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3561	221	LR-20.0GB-30D-PR3JZMC20	lr-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3562	221	LR-10.0GB-30D-P34FHRF8J	lr-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3580	222	LI-1.0GB-30D-PM1HX6ES9	li-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
3581	222	LI-3.0GB-30D-PJK6T8JT2	li-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
3582	222	LI-5.0GB-30D-P87F6RTKY	li-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
3583	222	LI-1.0GB-7D-PV048NCRG	li-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
3584	222	LI-10.0GB-30D-P50GVS8GN	li-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
3585	222	LI-20.0GB-30D-PHC4X21NC	li-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
3586	222	LI-20.0GB-90D-P5NWWU08G	li-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
3587	222	LI-50.0GB-180D-PE70MYRZ5	li-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
3588	222	LI-1.0GB-1D-PUDV52A3R	li-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3589	222	LI-1.5GB-1D-P34CJYA6C	li-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3590	222	LI-1.0GB-7D-PHS30M6EZ	li-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3591	222	LI-1.0GB-365D-PYMC5N31Z	li-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3616	223	LT-20.0GB-90D-P7VCE7FKY	lt-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3617	223	LT-50.0GB-180D-PGXJN6W2T	lt-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3618	223	PDCRKSTTY	lt-pdcrkstty	50.0GB / 180 дней	50	180	37	Lithuania 50GB 180Days	t
3619	223	LT-3.0GB-30D-PHD8GZ2VN	lt-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3620	223	LT-20.0GB-90D-PG3K0LHBC	lt-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3621	223	LT-1.0GB-365D-PCQXBW5UJ	lt-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3622	223	LT-1.0GB-30D-PM1HX6ES9	lt-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
3623	223	LT-3.0GB-30D-PJK6T8JT2	lt-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
3624	223	LT-5.0GB-30D-P87F6RTKY	lt-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
3625	223	LT-1.0GB-7D-PV048NCRG	lt-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
3626	223	LT-10.0GB-30D-P50GVS8GN	lt-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
3627	223	LT-20.0GB-30D-PHC4X21NC	lt-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
3628	223	LT-20.0GB-90D-P5NWWU08G	lt-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
3629	223	LT-50.0GB-180D-PE70MYRZ5	lt-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
3630	223	LT-1.0GB-1D-PUDV52A3R	lt-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3631	223	LT-1.5GB-1D-P34CJYA6C	lt-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3632	223	LT-1.0GB-7D-PHS30M6EZ	lt-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3633	223	LT-1.0GB-365D-PYMC5N31Z	lt-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3634	223	LT-5.0GB-30D-PEW54FVD9	lt-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3635	223	LT-3.0GB-30D-PW6P3DX2G	lt-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4481	262	CKH029	qa-ckh029	3.0GB / 30 дней	3	30	9.1	Qatar 3GB 30Days	t
4482	262	QA-6.0GB-8D-AIS001	qa-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
4483	262	QA-6.0GB-15D-AIS002	qa-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4484	262	CKH513	qa-ckh513	1.0GB / 7 дней	1	7	3.6	Qatar 1GB 7Days	t
4485	262	CKH667	qa-ckh667	3.0GB / 15 дней	3	15	8.9	Qatar 3GB 15Days	t
4486	262	CKH668	qa-ckh668	5.0GB / 30 дней	5	30	13.6	Qatar 5GB 30Days	t
4487	262	CKH762	qa-ckh762	20.0GB / 30 дней	20	30	40	Qatar 20GB 30Days	t
3647	224	CKH230	lu-ckh230	1.0GB / 7 дней	1	7	0.9	Luxembourg 1GB 7Days	t
3648	224	CKH231	lu-ckh231	3.0GB / 15 дней	3	15	2.2	Luxembourg 3GB 15Days	t
3649	224	CKH232	lu-ckh232	10.0GB / 30 дней	10	30	6.1	Luxembourg 10GB 30Days	t
3650	224	LU-1.0GB-7D-CKH484	lu-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3651	224	LU-10.0GB-30D-CKH486	lu-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
3652	224	LU-20.0GB-30D-CKH500	lu-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
3653	224	LU-6.0GB-15D-AIS002	lu-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3706	225	MO-50.0GB-180D-JC182	mo-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
3707	225	MO-1.0GB-7D-JC183	mo-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
3708	225	MO-3.0GB-30D-PHD8GZ2VN	mo-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3709	225	MO-20.0GB-90D-PG3K0LHBC	mo-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3710	225	PDRBEISAJ	mo-pdrbeisaj	50.0GB / 180 дней	50	180	32	Macao 50GB 180Days	t
3711	225	MO-50.0GB-180D-PJKYY3QTL	mo-pjkyy3qtl	50.0GB / 180 дней	50	180	37	China (mainland HK Macao) 50GB 180Days	t
3712	225	MO-1.0GB-365D-PCQXBW5UJ	mo-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3713	225	MO-1.0GB-7D-PHS30M6EZ	mo-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3714	225	MO-1.0GB-365D-PYMC5N31Z	mo-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3715	225	MO-5.0GB-30D-PEW54FVD9	mo-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3716	225	MO-3.0GB-30D-PW6P3DX2G	mo-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3717	225	MO-20.0GB-90D-PB83STJL6	mo-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3718	225	MO-20.0GB-30D-PR3JZMC20	mo-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3719	225	MO-10.0GB-30D-P34FHRF8J	mo-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4520	263	RO-1.0GB-7D-CKH484	ro-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
4521	263	RO-10.0GB-30D-CKH486	ro-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
4522	263	RO-20.0GB-30D-CKH500	ro-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
4523	263	RO-6.0GB-15D-AIS002	ro-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4524	263	CKH728	ro-ckh728	20.0GB / 30 дней	20	30	8.2	Romania 20GB 30Days	t
4525	263	RO-1.0GB-7D-CKH823	ro-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4526	263	RO-5.0GB-30D-CKH825	ro-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4527	263	RO-10.0GB-30D-CKH826	ro-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3232	207	IE-20.0GB-90D-PB83STJL6	ie-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3233	207	IE-20.0GB-30D-PR3JZMC20	ie-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3234	207	IE-10.0GB-30D-P34FHRF8J	ie-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3235	207	IE-2.0GB-1D-PZ6R8ASH9	ie-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
3236	207	IE-3.0GB-1D-PE01DJZS7	ie-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3237	207	IE-0.5GB-1D-P61RQP7ZW	ie-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
3238	207	IE-0.3GB-1D-P82Y6VYRL	ie-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
3239	207	PC0TA4B6L	ie-pc0ta4b6l	1.0GB / 1 дней	1	1	0.85	Ireland 1GB/Day	t
3240	208	IM-3.0GB-30D-CKH006	im-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3241	208	IM-5.0GB-30D-CKH007	im-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3242	208	CKH106	im-ckh106	3.0GB / 30 дней	3	30	3	Isle of Man 3GB 30Days	t
3243	208	CKH145	im-ckh145	5.0GB / 30 дней	5	30	4.4	Isle of Man 5GB 30Days	t
1839	141	AL-6.0GB-15D-AIS002	al-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1856	142	CKH515	dz-ckh515	1.0GB / 7 дней	1	7	1.1	Algeria 1GB 7Days	t
1857	142	CKH551	dz-ckh551	3.0GB / 15 дней	3	15	2.8	Algeria 3GB 15Days	t
1858	142	CKH552	dz-ckh552	5.0GB / 30 дней	5	30	4.4	Algeria 5GB 30Days	t
1859	142	CKH809	dz-ckh809	10.0GB / 30 дней	10	30	7.6	Algeria 10GB 30Days	t
1860	142	CKH810	dz-ckh810	20.0GB / 30 дней	20	30	12.9	Algeria 20GB 30Days	t
1861	142	DZ-1.0GB-7D-CKH823	dz-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1862	142	DZ-5.0GB-30D-CKH825	dz-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1863	142	DZ-10.0GB-30D-CKH826	dz-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1864	142	DZ-3.0GB-30D-PHD8GZ2VN	dz-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1865	142	DZ-20.0GB-90D-PG3K0LHBC	dz-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1866	142	DZ-1.0GB-365D-PCQXBW5UJ	dz-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1868	143	AI-5.0GB-1D-PX18HJ4XW	ai-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1869	143	AI-1.0GB-1D-P8JCL47FC	ai-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
1870	143	AI-0.5GB-1D-PX2WSA7L1	ai-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1871	143	AI-10.0GB-30D-PCHZ59M2J	ai-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1872	143	AI-5.0GB-30D-P7GA02CZP	ai-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1873	143	AI-3.0GB-30D-PQB69VW8U	ai-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1874	143	AI-1.0GB-7D-PUSHF5X80	ai-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1875	144	AG-5.0GB-1D-PX18HJ4XW	ag-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1876	144	AG-1.0GB-1D-P8JCL47FC	ag-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
1877	144	AG-0.5GB-1D-PX2WSA7L1	ag-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1878	144	AG-10.0GB-30D-PCHZ59M2J	ag-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1879	144	AG-5.0GB-30D-P7GA02CZP	ag-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1880	144	AG-3.0GB-30D-PQB69VW8U	ag-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1881	144	AG-1.0GB-7D-PUSHF5X80	ag-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1882	145	CKH293	ar-ckh293	1.0GB / 7 дней	1	7	3.6	Argentina 1GB 7Days	t
1883	145	CKH294	ar-ckh294	3.0GB / 15 дней	3	15	8.9	Argentina 3GB 15Days	t
1943	147	CKH537	at-ckh537	20.0GB / 30 дней	20	30	10.6	Austria 20GB 30Days	t
3244	208	CKH259	im-ckh259	1.0GB / 7 дней	1	7	1.1	Isle of Man 1GB 7Days	t
3765	227	MW-10.0GB-30D-P34FHRF8J	mw-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3767	228	JC028	my-jc028	3.0GB / 15 дней	3	15	1.7	Malaysia 3GB 15Days	t
3768	228	JC029	my-jc029	5.0GB / 30 дней	5	30	2.7	Malaysia 5GB 30Days	t
3769	228	JC030	my-jc030	10.0GB / 30 дней	10	30	4.7	Malaysia 10GB 30Days	t
3770	228	MY-6.0GB-8D-AIS001	my-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3771	228	MY-6.0GB-15D-AIS002	my-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3772	228	JC097	my-jc097	20.0GB / 30 дней	20	30	8.2	Malaysia 20GB 30Days	t
4528	263	RO-20.0GB-90D-P7VCE7FKY	ro-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
4529	263	RO-50.0GB-180D-PGXJN6W2T	ro-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
4530	263	PBOG35WTO	ro-pbog35wto	50.0GB / 180 дней	50	180	30	Romania 50GB 180Days	t
4531	263	RO-3.0GB-30D-PHD8GZ2VN	ro-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4532	263	RO-20.0GB-90D-PG3K0LHBC	ro-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1932	147	AT-3.0GB-30D-CKH006	at-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3245	208	CKH260	im-ckh260	3.0GB / 15 дней	3	15	2.8	Isle of Man 3GB 15Days	t
3246	208	IM-1.0GB-7D-CKH484	im-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3247	208	IM-10.0GB-30D-CKH486	im-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
3268	209	IL-5.0GB-30D-CKH825	il-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3269	209	IL-10.0GB-30D-CKH826	il-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3270	209	IL-1.0GB-7D-CKH848	il-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
3271	209	IL-5.0GB-30D-CKH850	il-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
3272	209	IL-1.0GB-30D-JC177	il-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
3273	209	IL-5.0GB-30D-JC178	il-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
3274	209	IL-3.0GB-15D-JC179	il-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
3275	209	IL-10.0GB-30D-JC180	il-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
3276	209	IL-20.0GB-90D-JC181	il-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
3277	209	IL-50.0GB-180D-JC182	il-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
3295	210	JM-5.0GB-1D-PX18HJ4XW	jm-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
3296	210	JM-1.0GB-1D-P8JCL47FC	jm-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
3304	211	CKH107	je-ckh107	3.0GB / 30 дней	3	30	1.8	Jersey 3GB 30Days	t
3305	211	CKH146	je-ckh146	5.0GB / 30 дней	5	30	2.7	Jersey 5GB 30Days	t
3306	211	CKH262	je-ckh262	1.0GB / 7 дней	1	7	0.7	Jersey 1GB 7Days	t
3307	211	CKH263	je-ckh263	3.0GB / 15 дней	3	15	1.7	Jersey 3GB 15Days	t
3308	211	JE-1.0GB-7D-CKH484	je-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3309	211	JE-10.0GB-30D-CKH486	je-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1933	147	AT-5.0GB-30D-CKH007	at-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1934	147	CKH076	at-ckh076	3.0GB / 30 дней	3	30	2.3	Austria 3GB 30Days	t
1935	147	CKH115	at-ckh115	5.0GB / 30 дней	5	30	3.4	Austria 5GB 30Days	t
1936	147	CKH157	at-ckh157	1.0GB / 7 дней	1	7	0.9	Austria 1GB 7Days	t
1937	147	CKH158	at-ckh158	3.0GB / 15 дней	3	15	2.2	Austria 3GB 15Days	t
1938	147	CKH159	at-ckh159	10.0GB / 30 дней	10	30	6.1	Austria 10GB 30Days	t
1939	147	AT-1.0GB-7D-CKH484	at-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1940	147	AT-10.0GB-30D-CKH486	at-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1941	147	AT-20.0GB-30D-CKH500	at-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1942	147	AT-6.0GB-15D-AIS002	at-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3310	211	JE-20.0GB-30D-CKH500	je-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1994	149	CKH035	bh-ckh035	3.0GB / 30 дней	3	30	11.4	Bahrain 3GB 30Days	t
3311	211	JE-6.0GB-15D-AIS002	je-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3312	211	CKH753	je-ckh753	20.0GB / 30 дней	20	30	8.2	Jersey 20GB 30Days	t
3313	211	JE-1.0GB-7D-CKH823	je-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3314	211	JE-5.0GB-30D-CKH825	je-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3315	211	JE-10.0GB-30D-CKH826	je-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3316	211	JE-20.0GB-90D-P7VCE7FKY	je-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3317	211	JE-50.0GB-180D-PGXJN6W2T	je-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3318	211	JE-3.0GB-30D-PHD8GZ2VN	je-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3319	211	JE-20.0GB-90D-PG3K0LHBC	je-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3320	211	JE-1.0GB-365D-PCQXBW5UJ	je-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3330	212	JO-5.0GB-30D-CKH825	jo-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3331	212	JO-10.0GB-30D-CKH826	jo-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3332	212	JO-1.0GB-7D-CKH848	jo-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
3333	212	JO-5.0GB-30D-CKH850	jo-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
3334	212	JO-3.0GB-30D-PHD8GZ2VN	jo-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3335	212	JO-20.0GB-90D-PG3K0LHBC	jo-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3336	212	JO-3.0GB-30D-PNEKXVZKV	jo-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
3337	212	JO-1.0GB-365D-PCQXBW5UJ	jo-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3338	212	JO-1.0GB-7D-PHS30M6EZ	jo-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3823	230	ML-1.0GB-7D-CKH495	ml-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1995	149	CKH289	bh-ckh289	1.0GB / 7 дней	1	7	4.6	Bahrain 1GB 7Days	t
1996	149	CKH290	bh-ckh290	3.0GB / 15 дней	3	15	11.2	Bahrain 3GB 15Days	t
1997	149	BH-6.0GB-8D-AIS001	bh-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
1998	149	BH-6.0GB-15D-AIS002	bh-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1999	149	BH-1.0GB-7D-CKH823	bh-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2000	149	BH-5.0GB-30D-CKH825	bh-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2001	149	BH-10.0GB-30D-CKH826	bh-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2002	149	BH-1.0GB-7D-CKH848	bh-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
3824	230	ML-5.0GB-30D-CKH497	ml-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
3825	230	ML-1.0GB-7D-CKH823	ml-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3826	230	ML-5.0GB-30D-CKH825	ml-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3827	230	ML-10.0GB-30D-CKH826	ml-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3828	230	ML-3.0GB-30D-P1XXDOD0C	ml-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
3829	230	ML-3.0GB-30D-PHD8GZ2VN	ml-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3830	230	ML-20.0GB-90D-PG3K0LHBC	ml-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2032	151	BB-5.0GB-1D-PX18HJ4XW	bb-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
3339	212	JO-1.0GB-365D-PYMC5N31Z	jo-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3363	213	KZ-20.0GB-30D-PR3JZMC20	kz-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3364	213	KZ-10.0GB-30D-P34FHRF8J	kz-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3365	213	KZ-10.0GB-1D-PGP9AZY26	kz-pgp9azy26	10.0GB / 1 дней	10	1	10.8	Central Asia 10GB/Day	t
3366	213	KZ-5.0GB-1D-P9RS4VV0A	kz-p9rs4vv0a	5.0GB / 1 дней	5	1	6	Central Asia 5GB/Day	t
3367	213	KZ-1.0GB-1D-PJA28XEA7	kz-pja28xea7	1.0GB / 1 дней	1	1	1.4	Central Asia 1GB/Day	t
3368	213	KZ-0.5GB-1D-P712EDLGB	kz-p712edlgb	0.49GB / 1 дней	0.49	1	0.6	Central Asia 500MB/Day	t
3369	214	CKH379	ke-ckh379	1.0GB / 7 дней	1	7	5.7	Kenya 1GB 7Days	t
3370	214	CKH408	ke-ckh408	3.0GB / 15 дней	3	15	14.1	Kenya 3GB 15Days	t
3371	214	CKH437	ke-ckh437	5.0GB / 30 дней	5	30	21	Kenya 5GB 30Days	t
3372	214	KE-1.0GB-7D-CKH495	ke-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
3373	214	KE-5.0GB-30D-CKH497	ke-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2033	151	BB-1.0GB-1D-P8JCL47FC	bb-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2034	151	BB-0.5GB-1D-PX2WSA7L1	bb-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
2035	151	BB-10.0GB-30D-PCHZ59M2J	bb-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
2036	151	BB-5.0GB-30D-P7GA02CZP	bb-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2037	151	BB-3.0GB-30D-PQB69VW8U	bb-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2038	151	BB-1.0GB-7D-PUSHF5X80	bb-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2039	152	BY-6.0GB-15D-AIS002	by-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2040	152	BY-1.0GB-7D-CKH823	by-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2041	152	BY-5.0GB-30D-CKH825	by-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2042	152	BY-10.0GB-30D-CKH826	by-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2043	152	EF4MLC10	by-ef4mlc10	1.0GB / 7 дней	1	7	2.1	Belarus 1GB 7Days	t
2044	152	ALL95F6M	by-all95f6m	3.0GB / 15 дней	3	15	6.3	Belarus 3GB 15Days	t
2045	152	G9EDN4W6	by-g9edn4w6	5.0GB / 30 дней	5	30	10.5	Belarus 5GB 30Days	t
2046	152	BY-3.0GB-30D-PHD8GZ2VN	by-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2047	152	BY-20.0GB-90D-PG3K0LHBC	by-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2048	152	BY-1.0GB-365D-PCQXBW5UJ	by-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2049	153	BE-3.0GB-30D-CKH006	be-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2050	153	BE-5.0GB-30D-CKH007	be-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2051	153	CKH077	be-ckh077	3.0GB / 30 дней	3	30	2.3	Belgium 3GB 30Days	t
2052	153	CKH116	be-ckh116	5.0GB / 30 дней	5	30	3.4	Belgium 5GB 30Days	t
2053	153	CKH202	be-ckh202	1.0GB / 7 дней	1	7	0.9	Belgium 1GB 7Days	t
2054	153	CKH203	be-ckh203	3.0GB / 15 дней	3	15	2.2	Belgium 3GB 15Days	t
2055	153	CKH204	be-ckh204	10.0GB / 30 дней	10	30	6.1	Belgium 10GB 30Days	t
2056	153	BE-1.0GB-7D-CKH484	be-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2057	153	BE-10.0GB-30D-CKH486	be-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2058	153	BE-20.0GB-30D-CKH500	be-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2059	153	BE-6.0GB-15D-AIS002	be-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2060	153	CKH502	be-ckh502	20.0GB / 30 дней	20	30	10.6	Belgium 20GB 30Days	t
3374	214	KE-6.0GB-15D-AIS002	ke-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3855	231	MT-50.0GB-180D-PGXJN6W2T	mt-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3856	231	MT-3.0GB-30D-PHD8GZ2VN	mt-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3857	231	MT-20.0GB-90D-PG3K0LHBC	mt-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3858	231	MT-1.0GB-365D-PCQXBW5UJ	mt-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3859	231	MT-1.0GB-30D-PM1HX6ES9	mt-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
3860	231	MT-3.0GB-30D-PJK6T8JT2	mt-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
3861	231	MT-5.0GB-30D-P87F6RTKY	mt-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2093	155	CKH297	bo-ckh297	1.0GB / 7 дней	1	7	5.7	Bolivia 1GB 7Days	t
3375	214	KE-1.0GB-7D-CKH823	ke-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3376	214	KE-5.0GB-30D-CKH825	ke-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3377	214	KE-10.0GB-30D-CKH826	ke-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3378	214	KE-3.0GB-30D-P1XXDOD0C	ke-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
3379	214	KE-3.0GB-30D-PHD8GZ2VN	ke-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3380	214	KE-20.0GB-90D-PG3K0LHBC	ke-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3381	214	KE-1.0GB-365D-PCQXBW5UJ	ke-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3382	214	KE-1.0GB-7D-PHS30M6EZ	ke-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3383	214	KE-1.0GB-365D-PYMC5N31Z	ke-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3384	214	KE-5.0GB-30D-PEW54FVD9	ke-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3385	214	KE-3.0GB-30D-PW6P3DX2G	ke-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3412	216	KR-3.0GB-30D-PHD8GZ2VN	kr-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3413	216	KR-20.0GB-90D-PG3K0LHBC	kr-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3414	216	KR-1.0GB-365D-PCQXBW5UJ	kr-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3415	216	PR7PDLXPX	kr-pr7pdlxpx	1.0GB / 1 дней	1	1	0.8	South Korea 1GB/Day	t
3416	216	P21XNC9CT	kr-p21xnc9ct	0.49GB / 1 дней	0.49	1	0.4	South Korea 500MB/Day	t
3417	216	KR-1.0GB-7D-PHS30M6EZ	kr-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3418	216	KR-1.0GB-365D-PYMC5N31Z	kr-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3419	216	KR-5.0GB-30D-PEW54FVD9	kr-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3420	216	KR-3.0GB-30D-PW6P3DX2G	kr-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3421	216	KR-20.0GB-90D-PB83STJL6	kr-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3422	216	KR-20.0GB-30D-PR3JZMC20	kr-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3423	216	KR-10.0GB-30D-P34FHRF8J	kr-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3424	216	KR-0.5GB-1D-PACK04L3R	kr-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
3425	216	KR-1.0GB-1D-PXJ8HG40S	kr-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
3426	216	KR-2.0GB-1D-PVBKS19B4	kr-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
3427	216	KR-3.0GB-1D-PM5T3Z4UM	kr-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
3869	231	MT-1.0GB-7D-PHS30M6EZ	mt-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3882	232	MQ-5.0GB-30D-CKH489	mq-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
3883	232	MQ-10.0GB-30D-CKH490	mq-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
3884	232	MQ-1.0GB-7D-CKH823	mq-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3885	232	MQ-5.0GB-30D-CKH825	mq-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3886	232	MQ-10.0GB-30D-CKH826	mq-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3887	232	MQ-3.0GB-30D-P6FNJUAP4	mq-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
3888	232	MQ-3.0GB-30D-PHD8GZ2VN	mq-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3889	232	MQ-20.0GB-90D-PG3K0LHBC	mq-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3890	232	MQ-1.0GB-365D-PCQXBW5UJ	mq-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
900	234	MX-1.0GB-7D-CKH491	mx-ckh491	1.0GB / 7 дней	1	7	2.3	North America 1GB 7Days	t
901	234	MX-5.0GB-30D-CKH493	mx-ckh493	5.0GB / 30 дней	5	30	8.8	North America 5GB 30Days	t
902	234	MX-10.0GB-30D-CKH494	mx-ckh494	10.0GB / 30 дней	10	30	15.2	North America 10GB 30Days	t
903	234	MX-6.0GB-15D-AIS002	mx-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2138	157	CKH368	bw-ckh368	1.0GB / 7 дней	1	7	7.1	Botswana 1GB 7Days	t
2139	157	CKH397	bw-ckh397	3.0GB / 15 дней	3	15	17.6	Botswana 3GB 15Days	t
2140	157	BW-1.0GB-7D-CKH495	bw-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2141	157	BW-5.0GB-30D-CKH497	bw-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2156	158	BN-6.0GB-8D-AIS001	bn-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
2157	158	BN-6.0GB-15D-AIS002	bn-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2158	158	BN-1.0GB-7D-CKH823	bn-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2159	158	BN-5.0GB-30D-CKH825	bn-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2160	158	BN-10.0GB-30D-CKH826	bn-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2161	158	CKH833	bn-ckh833	1.0GB / 7 дней	1	7	4.6	Brunei Darussalam 1GB 7Days	t
2162	158	CKH834	bn-ckh834	3.0GB / 15 дней	3	15	11.2	Brunei Darussalam 3GB 15Days	t
2163	158	CKH837	bn-ckh837	20.0GB / 30 дней	20	30	50	Brunei Darussalam 20GB 30Days	t
2164	158	BN-3.0GB-30D-PHD8GZ2VN	bn-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2165	158	BN-20.0GB-90D-PG3K0LHBC	bn-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2166	158	BN-1.0GB-365D-PCQXBW5UJ	bn-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2167	158	PRWWKX908	bn-prwwkx908	0.49GB / 1 дней	0.49	1	9.3	Brunei Darussalam 500MB/Day	t
2168	158	PU2ENL69H	bn-pu2enl69h	1.0GB / 1 дней	1	1	14.5	Brunei Darussalam 1GB/Day	t
2169	159	BG-3.0GB-30D-CKH006	bg-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2170	159	BG-5.0GB-30D-CKH007	bg-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2171	159	CKH078	bg-ckh078	3.0GB / 30 дней	3	30	2.3	Bulgaria 3GB 30Days	t
2172	159	CKH205	bg-ckh205	1.0GB / 7 дней	1	7	0.9	Bulgaria 1GB 7Days	t
2173	159	CKH206	bg-ckh206	3.0GB / 15 дней	3	15	2.2	Bulgaria 3GB 15Days	t
2174	159	CKH207	bg-ckh207	10.0GB / 30 дней	10	30	6.1	Bulgaria 10GB 30Days	t
2175	159	BG-1.0GB-7D-CKH484	bg-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2176	159	BG-10.0GB-30D-CKH486	bg-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2177	159	BG-20.0GB-30D-CKH500	bg-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
904	234	CKH518	mx-ckh518	1.0GB / 7 дней	1	7	2.3	Mexico 1GB 7Days	t
905	234	CKH644	mx-ckh644	3.0GB / 15 дней	3	15	5.7	Mexico 3GB 15Days	t
906	234	CKH645	mx-ckh645	5.0GB / 30 дней	5	30	8.8	Mexico 5GB 30Days	t
907	234	CKH798	mx-ckh798	20.0GB / 30 дней	20	30	25	Mexico 20GB 30Days	t
908	234	MX-1.0GB-7D-CKH823	mx-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
909	234	MX-5.0GB-30D-CKH825	mx-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
910	234	MX-10.0GB-30D-CKH826	mx-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
911	234	MX-3.0GB-30D-PB9HFSUS0	mx-pb9hfsus0	3.0GB / 30 дней	3	30	5.9	North America 3GB 30Days	t
912	234	MX-20.0GB-90D-PVF7RTI3Y	mx-pvf7rti3y	20.0GB / 90 дней	20	90	27	North America 20GB 90Days	t
913	234	MX-50.0GB-180D-POGTY0THV	mx-pogty0thv	50.0GB / 180 дней	50	180	58	North America 50GB 180Days	t
914	234	MX-3.0GB-30D-PHD8GZ2VN	mx-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
915	234	MX-20.0GB-90D-PG3K0LHBC	mx-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
916	234	MX-1.0GB-365D-PCQXBW5UJ	mx-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
917	234	MX-1.0GB-1D-PCTEPKHJW	mx-pctepkhjw	1.0GB / 1 дней	1	1	2.2	North America 1GB/Day	t
918	234	MX-1.5GB-1D-P5SQ1FXCQ	mx-p5sq1fxcq	1.5GB / 1 дней	1.5	1	3.2	North America 1.5GB/Day	t
919	234	MX-2.0GB-1D-PWTRNZF6E	mx-pwtrnzf6e	2.0GB / 1 дней	2	1	4.3	North America 2GB/Day	t
1077	264	CKH394	re-ckh394	3.0GB / 15 дней	3	15	7.2	Reunion 3GB 15Days	t
1088	264	RE-1.0GB-365D-PCQXBW5UJ	re-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1089	264	PQD094RUX	re-pqd094rux	0.49GB / 1 дней	0.49	1	1.45	Reunion 500MB/Day	t
1090	264	PHMS8J01F	re-phms8j01f	1.0GB / 1 дней	1	1	2.9	Reunion 1GB/Day	t
1091	264	P1X3N5XFT	re-p1x3n5xft	2.0GB / 1 дней	2	1	5.5	Reunion 2GB/Day	t
1092	264	P530XLLHQ	re-p530xllhq	3.0GB / 1 дней	3	1	7.1	Reunion 3GB/Day	t
2221	161	KH-6.0GB-8D-AIS001	kh-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
2222	161	KH-6.0GB-15D-AIS002	kh-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2223	161	JC109	kh-jc109	1.0GB / 7 дней	1	7	2.3	Cambodia 1GB 7Days	t
2224	161	JC115	kh-jc115	3.0GB / 15 дней	3	15	5.7	Cambodia 3GB 15Days	t
2225	161	JC149	kh-jc149	10.0GB / 30 дней	10	30	15.2	Cambodia 10GB 30Days	t
2226	161	JC150	kh-jc150	20.0GB / 30 дней	20	30	25	Cambodia 20GB 30Days	t
2227	161	KH-1.0GB-7D-CKH823	kh-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2228	161	KH-5.0GB-30D-CKH825	kh-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2229	161	KH-10.0GB-30D-CKH826	kh-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2230	161	KH-1.0GB-7D-JC165	kh-jc165	1.0GB / 7 дней	1	7	1.8	Asia (7 areas) 1GB 7Days	t
2231	161	KH-3.0GB-15D-JC166	kh-jc166	3.0GB / 15 дней	3	15	4.6	Asia (7 areas) 3GB 15Days	t
2232	161	KH-5.0GB-30D-JC167	kh-jc167	5.0GB / 30 дней	5	30	7	Asia (7 areas) 5GB 30Days	t
920	234	MX-1.0GB-30D-PWTE0W1Q4	mx-pwte0w1q4	1.0GB / 30 дней	1	30	2.5	North America 1GB 30Days	t
921	234	P8DKZK30Q	mx-p8dkzk30q	3.0GB / 30 дней	3	30	5.9	Mexico 3GB 30Days	t
922	234	P84BJ7UTL	mx-p84bj7utl	10.0GB / 30 дней	10	30	15.2	Mexico 10GB 30Days	t
923	234	MX-1.0GB-7D-PHS30M6EZ	mx-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
924	234	MX-1.0GB-365D-PYMC5N31Z	mx-pymc5n31z	1.0GB / 365 дней	1	365	19		t
925	234	MX-5.0GB-30D-PEW54FVD9	mx-pew54fvd9	5.0GB / 30 дней	5	30	26		t
926	234	MX-3.0GB-30D-PW6P3DX2G	mx-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
927	234	MX-20.0GB-90D-PB83STJL6	mx-pb83stjl6	20.0GB / 90 дней	20	90	95		t
928	234	MX-20.0GB-30D-PR3JZMC20	mx-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
929	234	MX-10.0GB-30D-P34FHRF8J	mx-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
930	234	MX-0.5GB-1D-PLF76MUC5	mx-plf76muc5	0.49GB / 1 дней	0.49	1	1.15	North America 500MB/Day	t
931	234	MX-3.0GB-1D-P5N9FP7RL	mx-p5n9fp7rl	3.0GB / 1 дней	3	1	5.6	North America 3GB/Day	t
932	234	MX-10.0GB-1D-PVT108ZDN	mx-pvt108zdn	10.0GB / 1 дней	10	1	15.1	North America 10GB/Day	t
933	234	MX-5.0GB-1D-P8L7JA0WC	mx-p8l7ja0wc	5.0GB / 1 дней	5	1	8.7	North America 5GB/Day	t
934	234	MX-10.0GB-30D-PF2BEFF37	mx-pf2beff37	10.0GB / 30 дней	10	30	19	North America 10GB 30Days Single Use	t
1094	265	KN-1.0GB-1D-P8JCL47FC	kn-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
3910	235	MD-1.0GB-7D-PHS30M6EZ	md-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3911	235	MD-1.0GB-365D-PYMC5N31Z	md-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3912	235	MD-5.0GB-30D-PEW54FVD9	md-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3913	235	MD-3.0GB-30D-PW6P3DX2G	md-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3914	235	MD-20.0GB-90D-PB83STJL6	md-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3915	235	MD-20.0GB-30D-PR3JZMC20	md-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3916	235	MD-10.0GB-30D-P34FHRF8J	md-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3972	240	MA-1.0GB-365D-PCQXBW5UJ	ma-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3973	240	MA-1.0GB-7D-PHS30M6EZ	ma-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3974	240	MA-1.0GB-365D-PYMC5N31Z	ma-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3975	240	MA-5.0GB-30D-PEW54FVD9	ma-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3976	240	MA-3.0GB-30D-PW6P3DX2G	ma-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3977	240	MA-20.0GB-90D-PB83STJL6	ma-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2269	163	KY-5.0GB-1D-PX18HJ4XW	ky-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2270	163	KY-1.0GB-1D-P8JCL47FC	ky-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2271	163	KY-0.5GB-1D-PX2WSA7L1	ky-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
2272	163	KY-10.0GB-30D-PCHZ59M2J	ky-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
2273	163	KY-5.0GB-30D-P7GA02CZP	ky-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2274	163	KY-3.0GB-30D-PQB69VW8U	ky-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2275	163	KY-1.0GB-7D-PUSHF5X80	ky-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
2276	164	CKH370	cf-ckh370	1.0GB / 7 дней	1	7	7.1	Central African Republic 1GB 7Days	t
2277	164	CKH399	cf-ckh399	3.0GB / 15 дней	3	15	17.6	Central African Republic 3GB 15Days	t
2278	164	CKH428	cf-ckh428	5.0GB / 30 дней	5	30	26	Central African Republic 5GB 30Days	t
2279	164	CF-1.0GB-7D-CKH495	cf-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2280	164	CF-5.0GB-30D-CKH497	cf-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2281	164	CF-3.0GB-30D-P1XXDOD0C	cf-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2282	164	CF-1.0GB-7D-PHS30M6EZ	cf-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2283	164	CF-1.0GB-365D-PYMC5N31Z	cf-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2284	164	CF-5.0GB-30D-PEW54FVD9	cf-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2285	164	CF-3.0GB-30D-PW6P3DX2G	cf-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2286	164	CF-20.0GB-90D-PB83STJL6	cf-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2287	164	CF-20.0GB-30D-PR3JZMC20	cf-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2288	164	CF-10.0GB-30D-P34FHRF8J	cf-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2289	165	CKH371	td-ckh371	1.0GB / 7 дней	1	7	5.7	Chad 1GB 7Days	t
2290	165	CKH400	td-ckh400	3.0GB / 15 дней	3	15	14.1	Chad 3GB 15Days	t
2291	165	CKH429	td-ckh429	5.0GB / 30 дней	5	30	21	Chad 5GB 30Days	t
2292	165	TD-1.0GB-7D-CKH495	td-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2293	165	TD-5.0GB-30D-CKH497	td-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
3932	236	MC-20.0GB-30D-PR3JZMC20	mc-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3933	236	MC-10.0GB-30D-P34FHRF8J	mc-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3943	238	ME-10.0GB-30D-CKH826	me-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3944	238	ME-3.0GB-30D-PHD8GZ2VN	me-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3945	238	ME-20.0GB-90D-PG3K0LHBC	me-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3946	238	ME-1.0GB-365D-PCQXBW5UJ	me-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3947	238	ME-1.0GB-7D-PHS30M6EZ	me-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3948	238	ME-1.0GB-365D-PYMC5N31Z	me-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3949	238	ME-5.0GB-30D-PEW54FVD9	me-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3950	238	ME-3.0GB-30D-PW6P3DX2G	me-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3951	238	ME-20.0GB-90D-PB83STJL6	me-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3952	238	ME-20.0GB-30D-PR3JZMC20	me-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3953	238	ME-10.0GB-30D-P34FHRF8J	me-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3978	240	MA-20.0GB-30D-PR3JZMC20	ma-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3979	240	MA-10.0GB-30D-P34FHRF8J	ma-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3980	240	PPHIWSELT	ma-pphiwselt	3.0GB / 30 дней	3	30	3.8		t
3981	240	P7BXAR31R	ma-p7bxar31r	5.0GB / 30 дней	5	30	5.7		t
3982	240	PO5WKZOPV	ma-po5wkzopv	10.0GB / 30 дней	10	30	9.9		t
3983	240	PKUWF7BJC	ma-pkuwf7bjc	1.0GB / 1 дней	1	1	1.4		t
3984	240	P33C3KC73	ma-p33c3kc73	2.0GB / 1 дней	2	1	2.5		t
3985	240	PRPJ3X0Y2	ma-prpj3x0y2	0.49GB / 1 дней	0.49	1	0.73	Morocco 500MB/Day	t
4003	244	NL-20.0GB-30D-CKH500	nl-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
4004	244	NL-6.0GB-15D-AIS002	nl-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4005	244	CKH724	nl-ckh724	20.0GB / 30 дней	20	30	10.6	Netherlands 20GB 30Days	t
4006	244	NL-1.0GB-7D-CKH823	nl-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4007	244	NL-5.0GB-30D-CKH825	nl-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4008	244	NL-10.0GB-30D-CKH826	nl-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4009	244	NL-20.0GB-90D-P7VCE7FKY	nl-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
4010	244	NL-50.0GB-180D-PGXJN6W2T	nl-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
4011	244	P6D7MCOBF	nl-p6d7mcobf	50.0GB / 180 дней	50	180	30	Netherlands 50GB 180Days	t
4012	244	NL-3.0GB-30D-PHD8GZ2VN	nl-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4013	244	NL-20.0GB-90D-PG3K0LHBC	nl-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4014	244	NL-1.0GB-365D-PCQXBW5UJ	nl-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4015	244	NL-1.0GB-30D-PM1HX6ES9	nl-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
2330	167	CKH303	co-ckh303	1.0GB / 7 дней	1	7	5.7	Colombia 1GB 7Days	t
2331	167	CKH319	co-ckh319	3.0GB / 15 дней	3	15	14.4	Colombia 3GB 15Days	t
2332	167	CO-1.0GB-7D-CKH487	co-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
2333	167	CO-3.0GB-15D-CKH488	co-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
2334	167	CO-5.0GB-30D-CKH489	co-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2335	167	CO-10.0GB-30D-CKH490	co-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
2336	167	CO-6.0GB-15D-AIS002	co-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2337	167	CO-1.0GB-7D-CKH823	co-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2338	167	CO-5.0GB-30D-CKH825	co-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2339	167	CO-10.0GB-30D-CKH826	co-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2340	167	CO-3.0GB-30D-P6FNJUAP4	co-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
2341	167	CO-3.0GB-30D-PHD8GZ2VN	co-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2342	167	CO-20.0GB-90D-PG3K0LHBC	co-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2343	167	CO-1.0GB-365D-PCQXBW5UJ	co-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4016	244	NL-3.0GB-30D-PJK6T8JT2	nl-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
4017	244	NL-5.0GB-30D-P87F6RTKY	nl-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
4018	244	NL-1.0GB-7D-PV048NCRG	nl-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
4019	244	NL-10.0GB-30D-P50GVS8GN	nl-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
4020	244	NL-20.0GB-30D-PHC4X21NC	nl-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
4021	244	NL-20.0GB-90D-P5NWWU08G	nl-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
4022	244	NL-50.0GB-180D-PE70MYRZ5	nl-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
4023	244	NL-1.0GB-1D-PUDV52A3R	nl-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
2378	169	CD-1.0GB-7D-CKH495	cd-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
4024	244	NL-1.5GB-1D-P34CJYA6C	nl-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
4025	244	NL-1.0GB-7D-PHS30M6EZ	nl-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4026	244	NL-1.0GB-365D-PYMC5N31Z	nl-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4027	244	NL-5.0GB-30D-PEW54FVD9	nl-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4028	244	NL-3.0GB-30D-PW6P3DX2G	nl-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4029	244	NL-20.0GB-90D-PB83STJL6	nl-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4030	244	NL-20.0GB-30D-PR3JZMC20	nl-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4031	244	NL-10.0GB-30D-P34FHRF8J	nl-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4032	244	NL-2.0GB-1D-PZ6R8ASH9	nl-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
4033	244	NL-3.0GB-1D-PE01DJZS7	nl-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
4034	244	NL-0.5GB-1D-P61RQP7ZW	nl-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
4035	244	NL-0.3GB-1D-P82Y6VYRL	nl-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2379	169	CD-5.0GB-30D-CKH497	cd-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2380	169	CD-6.0GB-15D-AIS002	cd-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2381	169	CD-1.0GB-7D-CKH823	cd-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2382	169	CD-5.0GB-30D-CKH825	cd-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2383	169	CD-10.0GB-30D-CKH826	cd-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2395	170	CKH304	cr-ckh304	1.0GB / 7 дней	1	7	4.6	Costa Rica 1GB 7Days	t
2396	170	CKH320	cr-ckh320	3.0GB / 15 дней	3	15	11.2	Costa Rica 3GB 15Days	t
2397	170	CR-1.0GB-7D-CKH487	cr-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
2398	170	CR-3.0GB-15D-CKH488	cr-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
2399	170	CR-5.0GB-30D-CKH489	cr-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2400	170	CR-10.0GB-30D-CKH490	cr-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
2401	170	CR-6.0GB-15D-AIS002	cr-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2402	170	CR-1.0GB-7D-CKH823	cr-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2403	170	CR-5.0GB-30D-CKH825	cr-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2404	170	CR-10.0GB-30D-CKH826	cr-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2405	170	CR-3.0GB-30D-P6FNJUAP4	cr-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
2406	170	CR-3.0GB-30D-PHD8GZ2VN	cr-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2407	170	CR-20.0GB-90D-PG3K0LHBC	cr-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2408	170	CR-1.0GB-365D-PCQXBW5UJ	cr-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2409	170	CR-1.0GB-7D-PHS30M6EZ	cr-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2410	170	CR-1.0GB-365D-PYMC5N31Z	cr-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4062	245	NZ-20.0GB-90D-PB83STJL6	nz-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4063	245	NZ-20.0GB-30D-PR3JZMC20	nz-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4064	245	NZ-10.0GB-30D-P34FHRF8J	nz-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4065	245	P7L62ZCMR	nz-p7l62zcmr	2.0GB / 1 дней	2	1	2.9	New Zealand 2GB/Day	t
4066	245	P65ZSJGC3	nz-p65zsjgc3	3.0GB / 1 дней	3	1	4.2	New Zealand 3GB/Day	t
4072	246	NI-10.0GB-30D-CKH490	ni-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
4073	246	NI-6.0GB-15D-AIS002	ni-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4074	246	NI-1.0GB-7D-CKH823	ni-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4075	246	NI-5.0GB-30D-CKH825	ni-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4076	246	NI-10.0GB-30D-CKH826	ni-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4077	246	NI-3.0GB-30D-P6FNJUAP4	ni-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
4078	246	NI-3.0GB-30D-PHD8GZ2VN	ni-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4079	246	NI-20.0GB-90D-PG3K0LHBC	ni-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2458	172	CY-3.0GB-30D-CKH006	cy-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2459	172	CY-5.0GB-30D-CKH007	cy-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2460	172	CKH080	cy-ckh080	3.0GB / 30 дней	3	30	2.3	Cyprus 3GB 30Days	t
2461	172	CKH119	cy-ckh119	5.0GB / 30 дней	5	30	3.4	Cyprus 5GB 30Days	t
4080	246	NI-1.0GB-365D-PCQXBW5UJ	ni-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4081	246	NI-1.0GB-7D-PHS30M6EZ	ni-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4082	246	NI-1.0GB-365D-PYMC5N31Z	ni-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4083	246	NI-5.0GB-30D-PEW54FVD9	ni-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4122	248	NG-20.0GB-90D-PB83STJL6	ng-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4123	248	NG-20.0GB-30D-PR3JZMC20	ng-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4124	248	NG-10.0GB-30D-P34FHRF8J	ng-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4127	249	MK-1.0GB-7D-CKH484	mk-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
4128	249	MK-10.0GB-30D-CKH486	mk-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
4129	249	MK-20.0GB-30D-CKH500	mk-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
4130	249	MK-6.0GB-15D-AIS002	mk-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4131	249	CKH517	mk-ckh517	1.0GB / 7 дней	1	7	2.3	North Macedonia of  1GB 7Days	t
4132	249	CKH637	mk-ckh637	3.0GB / 15 дней	3	15	5.7	North Macedonia of  3GB 15Days	t
4133	249	CKH638	mk-ckh638	5.0GB / 30 дней	5	30	8.8	North Macedonia of  5GB 30Days	t
4134	249	MK-1.0GB-7D-CKH823	mk-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4135	249	MK-5.0GB-30D-CKH825	mk-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4136	249	MK-10.0GB-30D-CKH826	mk-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4137	249	MK-20.0GB-90D-P7VCE7FKY	mk-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
4138	249	MK-50.0GB-180D-PGXJN6W2T	mk-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
4139	249	MK-3.0GB-30D-PHD8GZ2VN	mk-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4140	249	MK-20.0GB-90D-PG3K0LHBC	mk-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4141	249	MK-1.0GB-365D-PCQXBW5UJ	mk-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4146	249	MK-20.0GB-90D-PB83STJL6	mk-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4147	249	MK-20.0GB-30D-PR3JZMC20	mk-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4148	249	MK-10.0GB-30D-P34FHRF8J	mk-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4172	250	NO-5.0GB-30D-P87F6RTKY	no-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
4173	250	NO-1.0GB-7D-PV048NCRG	no-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
4174	250	NO-10.0GB-30D-P50GVS8GN	no-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
4175	250	NO-20.0GB-30D-PHC4X21NC	no-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
4176	250	NO-20.0GB-90D-P5NWWU08G	no-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
4177	250	NO-50.0GB-180D-PE70MYRZ5	no-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
4178	250	NO-1.0GB-1D-PUDV52A3R	no-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
4179	250	NO-1.5GB-1D-P34CJYA6C	no-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
4181	250	NO-1.0GB-365D-PYMC5N31Z	no-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4182	250	NO-5.0GB-30D-PEW54FVD9	no-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4183	250	NO-3.0GB-30D-PW6P3DX2G	no-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4184	250	NO-20.0GB-90D-PB83STJL6	no-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4185	250	NO-20.0GB-30D-PR3JZMC20	no-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4186	250	NO-10.0GB-30D-P34FHRF8J	no-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4187	250	NO-2.0GB-1D-PZ6R8ASH9	no-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
4188	250	NO-3.0GB-1D-PE01DJZS7	no-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
4189	250	NO-0.5GB-1D-P61RQP7ZW	no-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
4190	250	NO-0.3GB-1D-P82Y6VYRL	no-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
4191	250	PL6FJ9N2A	no-pl6fj9n2a	1.0GB / 1 дней	1	1	0.65	Norway 1GB/Day	t
4203	251	OM-3.0GB-30D-PHD8GZ2VN	om-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4204	251	OM-20.0GB-90D-PG3K0LHBC	om-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4205	251	OM-3.0GB-30D-PNEKXVZKV	om-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
4206	251	OM-1.0GB-365D-PCQXBW5UJ	om-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4207	251	OM-1.0GB-7D-PHS30M6EZ	om-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4208	251	OM-1.0GB-365D-PYMC5N31Z	om-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4209	251	OM-5.0GB-30D-PEW54FVD9	om-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4210	251	OM-3.0GB-30D-PW6P3DX2G	om-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4211	251	OM-20.0GB-90D-PB83STJL6	om-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4212	251	OM-20.0GB-30D-PR3JZMC20	om-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4213	251	OM-10.0GB-30D-P34FHRF8J	om-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4235	252	PK-1.0GB-365D-PYMC5N31Z	pk-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4236	252	PK-5.0GB-30D-PEW54FVD9	pk-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4237	252	PK-3.0GB-30D-PW6P3DX2G	pk-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4238	252	PK-20.0GB-90D-PB83STJL6	pk-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4239	252	PK-20.0GB-30D-PR3JZMC20	pk-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4240	252	PK-10.0GB-30D-P34FHRF8J	pk-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4241	252	PK-10.0GB-1D-PGP9AZY26	pk-pgp9azy26	10.0GB / 1 дней	10	1	10.8	Central Asia 10GB/Day	t
4242	252	PK-5.0GB-1D-P9RS4VV0A	pk-p9rs4vv0a	5.0GB / 1 дней	5	1	6	Central Asia 5GB/Day	t
4243	252	PK-1.0GB-1D-PJA28XEA7	pk-pja28xea7	1.0GB / 1 дней	1	1	1.4	Central Asia 1GB/Day	t
4244	252	PK-0.5GB-1D-P712EDLGB	pk-p712edlgb	0.49GB / 1 дней	0.49	1	0.6	Central Asia 500MB/Day	t
4250	254	PA-3.0GB-15D-CKH488	pa-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
4251	254	PA-5.0GB-30D-CKH489	pa-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
4252	254	PA-10.0GB-30D-CKH490	pa-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
4253	254	PA-6.0GB-15D-AIS002	pa-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4255	254	PA-5.0GB-30D-CKH825	pa-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2560	175	DK-3.0GB-30D-CKH006	dk-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2561	175	DK-5.0GB-30D-CKH007	dk-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2562	175	CKH082	dk-ckh082	3.0GB / 30 дней	3	30	2.3	Denmark 3GB 30Days	t
2563	175	CKH121	dk-ckh121	5.0GB / 30 дней	5	30	3.4	Denmark 5GB 30Days	t
2564	175	CKH166	dk-ckh166	1.0GB / 7 дней	1	7	0.9	Denmark 1GB 7Days	t
2565	175	CKH167	dk-ckh167	3.0GB / 15 дней	3	15	2.2	Denmark 3GB 15Days	t
2566	175	CKH168	dk-ckh168	10.0GB / 30 дней	10	30	6.1	Denmark 10GB 30Days	t
2567	175	DK-1.0GB-7D-CKH484	dk-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2568	175	DK-10.0GB-30D-CKH486	dk-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
2569	175	DK-20.0GB-30D-CKH500	dk-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
2570	175	DK-6.0GB-15D-AIS002	dk-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2571	175	CKH543	dk-ckh543	20.0GB / 30 дней	20	30	10.6	Denmark 20GB 30Days	t
2572	175	DK-1.0GB-7D-CKH823	dk-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4256	254	PA-10.0GB-30D-CKH826	pa-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4257	254	PA-3.0GB-30D-P6FNJUAP4	pa-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
4258	254	PA-3.0GB-30D-PHD8GZ2VN	pa-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4259	254	PA-20.0GB-90D-PG3K0LHBC	pa-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4260	254	PA-1.0GB-365D-PCQXBW5UJ	pa-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4261	254	PA-1.0GB-7D-PHS30M6EZ	pa-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4262	254	PA-1.0GB-365D-PYMC5N31Z	pa-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4263	254	PA-5.0GB-30D-PEW54FVD9	pa-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4264	254	PA-3.0GB-30D-PW6P3DX2G	pa-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4265	254	PA-20.0GB-90D-PB83STJL6	pa-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4266	254	PA-20.0GB-30D-PR3JZMC20	pa-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4267	254	PA-10.0GB-30D-P34FHRF8J	pa-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4289	256	PY-10.0GB-30D-P34FHRF8J	py-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4290	256	PY-5.0GB-1D-PX18HJ4XW	py-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
4291	256	PY-1.0GB-1D-P8JCL47FC	py-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
4292	256	PY-0.5GB-1D-PX2WSA7L1	py-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
4293	256	PY-10.0GB-30D-PCHZ59M2J	py-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
4294	256	PY-5.0GB-30D-P7GA02CZP	py-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
4295	256	PY-3.0GB-30D-PQB69VW8U	py-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
4296	256	PY-1.0GB-7D-PUSHF5X80	py-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
4300	257	PE-3.0GB-15D-CKH488	pe-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
4301	257	PE-5.0GB-30D-CKH489	pe-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2609	177	DO-6.0GB-15D-AIS002	do-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2610	177	JC158	do-jc158	1.0GB / 7 дней	1	7	5.7	Dominican Republic 1GB 7Days	t
2611	177	JC159	do-jc159	3.0GB / 15 дней	3	15	14.1	Dominican Republic 3GB 15Days	t
2612	177	JC160	do-jc160	5.0GB / 30 дней	5	30	21	Dominican Republic 5GB 30Days	t
2613	177	JC162	do-jc162	20.0GB / 30 дней	20	30	63	Dominican Republic 20GB 30Days	t
2614	177	DO-5.0GB-1D-PX18HJ4XW	do-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2615	177	DO-1.0GB-1D-P8JCL47FC	do-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2616	177	DO-0.5GB-1D-PX2WSA7L1	do-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
2621	178	CKH305	ec-ckh305	1.0GB / 7 дней	1	7	4.6	Ecuador 1GB 7Days	t
2622	178	CKH321	ec-ckh321	3.0GB / 15 дней	3	15	11.2	Ecuador 3GB 15Days	t
2623	178	EC-1.0GB-7D-CKH487	ec-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
2624	178	EC-3.0GB-15D-CKH488	ec-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
2625	178	EC-5.0GB-30D-CKH489	ec-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2626	178	EC-10.0GB-30D-CKH490	ec-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
2627	178	EC-6.0GB-15D-AIS002	ec-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2628	178	EC-1.0GB-7D-CKH823	ec-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2629	178	EC-5.0GB-30D-CKH825	ec-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2630	178	EC-10.0GB-30D-CKH826	ec-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2631	178	EC-3.0GB-30D-P6FNJUAP4	ec-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
2632	178	EC-3.0GB-30D-PHD8GZ2VN	ec-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2633	178	EC-20.0GB-90D-PG3K0LHBC	ec-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2642	180	CKH306	sv-ckh306	1.0GB / 7 дней	1	7	5.7	El Salvador 1GB 7Days	t
2643	180	CKH322	sv-ckh322	3.0GB / 15 дней	3	15	14.1	El Salvador 3GB 15Days	t
4302	257	PE-10.0GB-30D-CKH490	pe-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
4303	257	PE-6.0GB-15D-AIS002	pe-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4304	257	PE-1.0GB-7D-CKH823	pe-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4305	257	PE-5.0GB-30D-CKH825	pe-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4306	257	PE-10.0GB-30D-CKH826	pe-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4307	257	CKH862	pe-ckh862	20.0GB / 30 дней	20	30	98	Peru 20GB 30Days	t
4308	257	PE-3.0GB-30D-P6FNJUAP4	pe-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
4309	257	PE-3.0GB-30D-PHD8GZ2VN	pe-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4310	257	PE-20.0GB-90D-PG3K0LHBC	pe-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4311	257	PE-1.0GB-365D-PCQXBW5UJ	pe-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4312	257	PE-1.0GB-7D-PHS30M6EZ	pe-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4313	257	PE-1.0GB-365D-PYMC5N31Z	pe-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4314	257	PE-5.0GB-30D-PEW54FVD9	pe-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4315	257	PE-3.0GB-30D-PW6P3DX2G	pe-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4316	257	PE-20.0GB-90D-PB83STJL6	pe-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4317	257	PE-20.0GB-30D-PR3JZMC20	pe-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4318	257	PE-10.0GB-30D-P34FHRF8J	pe-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4319	257	PE-5.0GB-1D-PX18HJ4XW	pe-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
4320	257	PE-1.0GB-1D-P8JCL47FC	pe-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
4321	257	PE-0.5GB-1D-PX2WSA7L1	pe-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
4322	257	PE-10.0GB-30D-PCHZ59M2J	pe-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
4323	257	PE-5.0GB-30D-P7GA02CZP	pe-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
4324	257	PE-3.0GB-30D-PQB69VW8U	pe-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
4325	257	PE-1.0GB-7D-PUSHF5X80	pe-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
4352	258	PH-1.0GB-365D-PCQXBW5UJ	ph-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4353	258	PKI8J4QW7	ph-pki8j4qw7	0.49GB / 1 дней	0.49	1	0.8	Philippines 500MB/Day	t
4354	258	PKOY9TRDZ	ph-pkoy9trdz	1.0GB / 1 дней	1	1	1.5	Philippines 1GB/Day	t
4355	258	PYKASRYFN	ph-pykasryfn	2.0GB / 1 дней	2	1	3	Philippines 2GB/Day	t
4357	258	PH-1.0GB-365D-PYMC5N31Z	ph-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4359	258	PH-3.0GB-30D-PW6P3DX2G	ph-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4360	258	PH-20.0GB-90D-PB83STJL6	ph-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4361	258	PH-20.0GB-30D-PR3JZMC20	ph-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4362	258	PH-10.0GB-30D-P34FHRF8J	ph-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4363	258	P7H5ESZX4	ph-p7h5eszx4	3.0GB / 1 дней	3	1	4.5	Philippine 3GB/Day	t
4364	258	P08FIDBBQ	ph-p08fidbbq	10.0GB / 1 дней	10	1	15		t
4365	258	PH-1.0GB-1D-P0N8SUBG5	ph-p0n8subg5	1.0GB / 1 дней	1	1	1.7	Asia (7 areas) 1GB/Day	t
4366	258	PH-0.5GB-1D-PX5NT8Z4K	ph-px5nt8z4k	0.49GB / 1 дней	0.49	1	0.9	Asia (7 areas) 500MB/Day	t
4367	258	PH-2.0GB-1D-PBZUB2S60	ph-pbzub2s60	2.0GB / 1 дней	2	1	3	Asia (7 areas) 2GB/Day	t
4368	258	PH-5.0GB-1D-PJ2W7KTJ4	ph-pj2w7ktj4	5.0GB / 1 дней	5	1	6	Asia (7 areas) 5GB/Day	t
4379	259	CKH726	pl-ckh726	20.0GB / 30 дней	20	30	8.2	Poland 20GB 30Days	t
4380	259	PL-1.0GB-7D-CKH823	pl-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4381	259	PL-5.0GB-30D-CKH825	pl-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4382	259	PL-10.0GB-30D-CKH826	pl-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4383	259	PL-20.0GB-90D-P7VCE7FKY	pl-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
4384	259	PL-50.0GB-180D-PGXJN6W2T	pl-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
4385	259	PZMKJMCWN	pl-pzmkjmcwn	50.0GB / 180 дней	50	180	28	Poland 50GB 180Days	t
4386	259	PL-3.0GB-30D-PHD8GZ2VN	pl-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4387	259	PL-20.0GB-90D-PG3K0LHBC	pl-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4388	259	PL-1.0GB-365D-PCQXBW5UJ	pl-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4389	259	PL-1.0GB-30D-PM1HX6ES9	pl-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
4390	259	PL-3.0GB-30D-PJK6T8JT2	pl-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
4391	259	PL-5.0GB-30D-P87F6RTKY	pl-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
4392	259	PL-1.0GB-7D-PV048NCRG	pl-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
4393	259	PL-10.0GB-30D-P50GVS8GN	pl-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
4394	259	PL-20.0GB-30D-PHC4X21NC	pl-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
4395	259	PL-20.0GB-90D-P5NWWU08G	pl-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
4396	259	PL-50.0GB-180D-PE70MYRZ5	pl-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
4397	259	PL-1.0GB-1D-PUDV52A3R	pl-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
4398	259	PL-1.5GB-1D-P34CJYA6C	pl-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
4399	259	PL-1.0GB-7D-PHS30M6EZ	pl-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4400	259	PL-1.0GB-365D-PYMC5N31Z	pl-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4401	259	PL-5.0GB-30D-PEW54FVD9	pl-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4402	259	PL-3.0GB-30D-PW6P3DX2G	pl-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4417	260	PT-1.0GB-7D-CKH484	pt-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
2724	183	FO-6.0GB-15D-AIS002	fo-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2725	184	FJ-6.0GB-15D-AIS002	fj-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2726	185	FI-3.0GB-30D-CKH006	fi-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2727	185	FI-5.0GB-30D-CKH007	fi-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
4418	260	PT-10.0GB-30D-CKH486	pt-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
4419	260	PT-20.0GB-30D-CKH500	pt-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
4420	260	PT-6.0GB-15D-AIS002	pt-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4421	260	CKH1011	pt-ckh1011	20.0GB / 30 дней	20	30	10.6	Portugal 20GB 30Days	t
4422	260	PT-1.0GB-7D-CKH823	pt-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4423	260	PT-5.0GB-30D-CKH825	pt-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4424	260	PT-10.0GB-30D-CKH826	pt-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4425	260	PT-20.0GB-90D-P7VCE7FKY	pt-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
4426	260	PT-50.0GB-180D-PGXJN6W2T	pt-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
4427	260	PT-3.0GB-30D-PHD8GZ2VN	pt-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4428	260	PT-20.0GB-90D-PG3K0LHBC	pt-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4429	260	PT-1.0GB-365D-PCQXBW5UJ	pt-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4430	260	PT-1.0GB-30D-PM1HX6ES9	pt-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
4431	260	PT-3.0GB-30D-PJK6T8JT2	pt-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
4432	260	PT-5.0GB-30D-P87F6RTKY	pt-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
4433	260	PT-1.0GB-7D-PV048NCRG	pt-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
4434	260	PT-10.0GB-30D-P50GVS8GN	pt-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
4435	260	PT-20.0GB-30D-PHC4X21NC	pt-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2774	187	CKH376	ga-ckh376	1.0GB / 7 дней	1	7	4.6	Gabon 1GB 7Days	t
2775	187	CKH405	ga-ckh405	3.0GB / 15 дней	3	15	11.2	Gabon 3GB 15Days	t
4436	260	PT-20.0GB-90D-P5NWWU08G	pt-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
4437	260	PT-50.0GB-180D-PE70MYRZ5	pt-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
4438	260	PT-1.0GB-1D-PUDV52A3R	pt-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
4439	260	PT-1.5GB-1D-P34CJYA6C	pt-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
4440	260	PT-1.0GB-7D-PHS30M6EZ	pt-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4441	260	PT-1.0GB-365D-PYMC5N31Z	pt-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4442	260	PT-5.0GB-30D-PEW54FVD9	pt-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2776	187	GA-1.0GB-7D-CKH495	ga-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2777	187	GA-5.0GB-30D-CKH497	ga-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2778	187	GA-6.0GB-15D-AIS002	ga-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2793	188	CKH970	ge-ckh970	3.0GB / 30 дней	3	30	3.8	Georgia 3GB 30Days	t
2794	188	GE-6.0GB-8D-AIS001	ge-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
2795	188	GE-6.0GB-15D-AIS002	ge-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2796	188	CKH511	ge-ckh511	1.0GB / 7 дней	1	7	1.5	Georgia 1GB 7Days	t
2797	188	CKH601	ge-ckh601	3.0GB / 15 дней	3	15	3.7	Georgia 3GB 15Days	t
2798	188	CKH602	ge-ckh602	5.0GB / 30 дней	5	30	5.7	Georgia 5GB 30Days	t
2799	188	CKH743	ge-ckh743	20.0GB / 30 дней	20	30	16.8	Georgia 20GB 30Days	t
2800	188	GE-1.0GB-7D-CKH823	ge-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2806	189	GH-1.0GB-7D-CKH495	gh-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
2807	189	GH-5.0GB-30D-CKH497	gh-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2808	189	GH-6.0GB-15D-AIS002	gh-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2809	189	GH-1.0GB-7D-CKH823	gh-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2810	189	GH-5.0GB-30D-CKH825	gh-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2811	189	GH-10.0GB-30D-CKH826	gh-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2812	189	GH-3.0GB-30D-P1XXDOD0C	gh-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2813	189	GH-3.0GB-30D-PHD8GZ2VN	gh-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2814	189	GH-20.0GB-90D-PG3K0LHBC	gh-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2815	189	GH-1.0GB-365D-PCQXBW5UJ	gh-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2816	189	GH-1.0GB-7D-PHS30M6EZ	gh-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2817	189	GH-1.0GB-365D-PYMC5N31Z	gh-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2818	189	GH-5.0GB-30D-PEW54FVD9	gh-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4443	260	PT-3.0GB-30D-PW6P3DX2G	pt-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4446	260	PT-10.0GB-30D-P34FHRF8J	pt-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4447	260	PT-2.0GB-1D-PZ6R8ASH9	pt-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
4448	260	PT-3.0GB-1D-PE01DJZS7	pt-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
4449	260	PT-0.5GB-1D-P61RQP7ZW	pt-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
4450	260	PT-0.3GB-1D-P82Y6VYRL	pt-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
4451	260	P7R54NBNC	pt-p7r54nbnc	1.0GB / 1 дней	1	1	0.85	Portugal 1GB/Day	t
4475	261	PR-1.0GB-1D-P8JCL47FC	pr-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
4476	261	PR-0.5GB-1D-PX2WSA7L1	pr-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
4477	261	PR-10.0GB-30D-PCHZ59M2J	pr-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
4478	261	PR-5.0GB-30D-P7GA02CZP	pr-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
4479	261	PR-3.0GB-30D-PQB69VW8U	pr-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
4480	261	PR-1.0GB-7D-PUSHF5X80	pr-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
4488	262	QA-1.0GB-7D-CKH823	qa-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4489	262	QA-5.0GB-30D-CKH825	qa-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4490	262	QA-10.0GB-30D-CKH826	qa-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4491	262	QA-1.0GB-7D-CKH848	qa-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
4492	262	QA-5.0GB-30D-CKH850	qa-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
4493	262	QA-3.0GB-30D-PHD8GZ2VN	qa-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4494	262	QA-20.0GB-90D-PG3K0LHBC	qa-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4495	262	QA-3.0GB-30D-PNEKXVZKV	qa-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
4496	262	QA-1.0GB-365D-PCQXBW5UJ	qa-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2846	191	GR-3.0GB-30D-CKH006	gr-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
2847	191	GR-5.0GB-30D-CKH007	gr-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
2848	191	CKH979	gr-ckh979	3.0GB / 30 дней	3	30	2.3	Greece 3GB 30Days	t
4497	262	QA-1.0GB-7D-PHS30M6EZ	qa-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4498	262	QA-1.0GB-365D-PYMC5N31Z	qa-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4499	262	QA-5.0GB-30D-PEW54FVD9	qa-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4500	262	QA-3.0GB-30D-PW6P3DX2G	qa-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4501	262	QA-20.0GB-90D-PB83STJL6	qa-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4502	262	QA-20.0GB-30D-PR3JZMC20	qa-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4503	262	QA-10.0GB-30D-P34FHRF8J	qa-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
4504	262	QA-10.0GB-1D-PLR26GSE7	qa-plr26gse7	10.0GB / 1 дней	10	1	22	Gulf Region 10GB/Day	t
4505	262	QA-5.0GB-1D-PLK713DWL	qa-plk713dwl	5.0GB / 1 дней	5	1	10.8	Gulf Region 5GB/Day	t
4506	262	QA-1.0GB-1D-P40YDJ9WA	qa-p40ydj9wa	1.0GB / 1 дней	1	1	2.9	Gulf Region 1GB/Day	t
4507	262	QA-0.5GB-1D-PW9U86NGE	qa-pw9u86nge	0.49GB / 1 дней	0.49	1	1.8	Gulf Region 500MB/Day	t
4508	262	QA-10.0GB-30D-P9DH2MUN5	qa-p9dh2mun5	10.0GB / 30 дней	10	30	22	Gulf Region 10GB 30Days Single Use	t
4509	262	QA-5.0GB-30D-PK2BXX9B4	qa-pk2bxx9b4	5.0GB / 30 дней	5	30	10.8	Gulf Region  5GB  30Days Single Use	t
4510	262	QA-3.0GB-30D-P8D7Q1CZY	qa-p8d7q1czy	3.0GB / 30 дней	3	30	6.8	Gulf Region  3GB  30Days Single Use	t
4511	262	QA-1.0GB-7D-PTJX062PT	qa-ptjx062pt	1.0GB / 7 дней	1	7	2.3	Gulf Region 1GB  7Days Single Use	t
4512	262	PMJUJWRQ8	qa-pmjujwrq8	1.0GB / 1 дней	1	1	1.7		t
4533	263	RO-1.0GB-365D-PCQXBW5UJ	ro-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4534	263	RO-1.0GB-30D-PM1HX6ES9	ro-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
4535	263	RO-3.0GB-30D-PJK6T8JT2	ro-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
4536	263	RO-5.0GB-30D-P87F6RTKY	ro-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
4537	263	RO-1.0GB-7D-PV048NCRG	ro-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
4538	263	RO-10.0GB-30D-P50GVS8GN	ro-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
4539	263	RO-20.0GB-30D-PHC4X21NC	ro-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2895	193	GD-5.0GB-1D-PX18HJ4XW	gd-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2896	193	GD-1.0GB-1D-P8JCL47FC	gd-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2897	193	GD-0.5GB-1D-PX2WSA7L1	gd-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
2898	193	GD-10.0GB-30D-PCHZ59M2J	gd-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
2899	193	GD-5.0GB-30D-P7GA02CZP	gd-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
2900	193	GD-3.0GB-30D-PQB69VW8U	gd-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2902	194	CKH812	gp-ckh812	1.0GB / 7 дней	1	7	2.9	Guadeloupe 1GB 7Days	t
2903	194	CKH813	gp-ckh813	3.0GB / 15 дней	3	15	7.2	Guadeloupe 3GB 15Days	t
2904	194	CKH816	gp-ckh816	20.0GB / 30 дней	20	30	32	Guadeloupe 20GB 30Days	t
2905	194	GP-5.0GB-1D-PX18HJ4XW	gp-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2906	194	GP-1.0GB-1D-P8JCL47FC	gp-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2907	194	GP-0.5GB-1D-PX2WSA7L1	gp-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
2908	194	GP-10.0GB-30D-PCHZ59M2J	gp-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
2912	195	GU-6.0GB-8D-AIS001	gu-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
2913	195	GU-6.0GB-15D-AIS002	gu-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2914	195	GU-1.0GB-7D-PHS30M6EZ	gu-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2915	195	GU-1.0GB-365D-PYMC5N31Z	gu-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2916	195	GU-5.0GB-30D-PEW54FVD9	gu-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2917	195	GU-3.0GB-30D-PW6P3DX2G	gu-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2918	195	GU-20.0GB-90D-PB83STJL6	gu-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2919	195	GU-20.0GB-30D-PR3JZMC20	gu-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2920	195	GU-10.0GB-30D-P34FHRF8J	gu-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2927	196	CKH309	gt-ckh309	1.0GB / 7 дней	1	7	5.7	Guatemala 1GB 7Days	t
2928	196	CKH325	gt-ckh325	3.0GB / 15 дней	3	15	14.1	Guatemala 3GB 15Days	t
2929	196	GT-1.0GB-7D-CKH487	gt-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
2930	196	GT-3.0GB-15D-CKH488	gt-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
2931	196	GT-5.0GB-30D-CKH489	gt-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2932	196	GT-10.0GB-30D-CKH490	gt-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
2933	196	GT-6.0GB-15D-AIS002	gt-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2934	196	GT-1.0GB-7D-CKH823	gt-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2935	196	GT-5.0GB-30D-CKH825	gt-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2936	196	GT-10.0GB-30D-CKH826	gt-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2937	196	GT-3.0GB-30D-P6FNJUAP4	gt-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
4540	263	RO-20.0GB-90D-P5NWWU08G	ro-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
4541	263	RO-50.0GB-180D-PE70MYRZ5	ro-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
4542	263	RO-1.0GB-1D-PUDV52A3R	ro-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
4543	263	RO-1.5GB-1D-P34CJYA6C	ro-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
4544	263	RO-1.0GB-7D-PHS30M6EZ	ro-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4545	263	RO-1.0GB-365D-PYMC5N31Z	ro-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4546	263	RO-5.0GB-30D-PEW54FVD9	ro-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4547	263	RO-3.0GB-30D-PW6P3DX2G	ro-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
4548	263	RO-20.0GB-90D-PB83STJL6	ro-pb83stjl6	20.0GB / 90 дней	20	90	95		t
4549	263	RO-20.0GB-30D-PR3JZMC20	ro-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4550	263	RO-10.0GB-30D-P34FHRF8J	ro-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1095	265	KN-0.5GB-1D-PX2WSA7L1	kn-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1096	265	KN-10.0GB-30D-PCHZ59M2J	kn-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1097	265	KN-5.0GB-30D-P7GA02CZP	kn-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1098	265	KN-3.0GB-30D-PQB69VW8U	kn-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
2967	198	GW-1.0GB-7D-CKH495	gw-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
4551	263	RO-2.0GB-1D-PZ6R8ASH9	ro-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
4552	263	RO-3.0GB-1D-PE01DJZS7	ro-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
4553	263	RO-0.5GB-1D-P61RQP7ZW	ro-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
4554	263	RO-0.3GB-1D-P82Y6VYRL	ro-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2968	198	GW-5.0GB-30D-CKH497	gw-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
2969	198	GW-1.0GB-7D-CKH823	gw-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2970	198	GW-5.0GB-30D-CKH825	gw-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2971	198	GW-10.0GB-30D-CKH826	gw-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2972	198	GW-3.0GB-30D-P1XXDOD0C	gw-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
2973	198	GW-3.0GB-30D-PHD8GZ2VN	gw-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2974	198	GW-20.0GB-90D-PG3K0LHBC	gw-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2975	198	GW-1.0GB-365D-PCQXBW5UJ	gw-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2983	199	VA-6.0GB-15D-AIS002	va-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2984	200	CKH310	hn-ckh310	1.0GB / 7 дней	1	7	4.6	Honduras 1GB 7Days	t
2985	200	CKH326	hn-ckh326	3.0GB / 15 дней	3	15	11.2	Honduras 3GB 15Days	t
2986	200	HN-1.0GB-7D-CKH487	hn-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
2987	200	HN-3.0GB-15D-CKH488	hn-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
2988	200	HN-5.0GB-30D-CKH489	hn-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2989	200	HN-10.0GB-30D-CKH490	hn-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
2990	200	HN-6.0GB-15D-AIS002	hn-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2991	200	HN-1.0GB-7D-CKH823	hn-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2992	200	HN-5.0GB-30D-CKH825	hn-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2993	200	HN-10.0GB-30D-CKH826	hn-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2994	200	HN-3.0GB-30D-P6FNJUAP4	hn-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
2995	200	HN-3.0GB-30D-PHD8GZ2VN	hn-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2996	200	HN-20.0GB-90D-PG3K0LHBC	hn-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1025	11	JC070	ru-jc070	1.0GB / 7 дней	1	7	2.9	Russia 1GB 7Days	t
875	7	CA-1.5GB-1D-P5SQ1FXCQ	ca-p5sq1fxcq	1.5GB / 1 дней	1.5	1	3.2	North America 1.5GB/Day	t
876	7	CA-2.0GB-1D-PWTRNZF6E	ca-pwtrnzf6e	2.0GB / 1 дней	2	1	4.3	North America 2GB/Day	t
877	7	CA-1.0GB-30D-PWTE0W1Q4	ca-pwte0w1q4	1.0GB / 30 дней	1	30	2.5	North America 1GB 30Days	t
878	7	PJYU684PF	ca-pjyu684pf	3.0GB / 30 дней	3	30	5.9	Canada 3GB 30Days	t
879	7	CA-1.0GB-7D-PHS30M6EZ	ca-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
880	7	CA-1.0GB-365D-PYMC5N31Z	ca-pymc5n31z	1.0GB / 365 дней	1	365	19		t
881	7	CA-5.0GB-30D-PEW54FVD9	ca-pew54fvd9	5.0GB / 30 дней	5	30	26		t
882	7	CA-3.0GB-30D-PW6P3DX2G	ca-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
883	7	CA-20.0GB-90D-PB83STJL6	ca-pb83stjl6	20.0GB / 90 дней	20	90	95		t
884	7	CA-20.0GB-30D-PR3JZMC20	ca-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
885	7	CA-10.0GB-30D-P34FHRF8J	ca-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
886	7	PPPTNR783	ca-ppptnr783	0.49GB / 1 дней	0.49	1	0.9	Canada 500MB/Day	t
887	7	P58GBEZQ3	ca-p58gbezq3	3.0GB / 1 дней	3	1	5.4	Canada 3GB/Day	t
888	7	CA-0.5GB-1D-PLF76MUC5	ca-plf76muc5	0.49GB / 1 дней	0.49	1	1.15	North America 500MB/Day	t
889	7	CA-3.0GB-1D-P5N9FP7RL	ca-p5n9fp7rl	3.0GB / 1 дней	3	1	5.6	North America 3GB/Day	t
890	7	CA-10.0GB-1D-PVT108ZDN	ca-pvt108zdn	10.0GB / 1 дней	10	1	15.1	North America 10GB/Day	t
891	7	CA-5.0GB-1D-P8L7JA0WC	ca-p8l7ja0wc	5.0GB / 1 дней	5	1	8.7	North America 5GB/Day	t
892	7	CA-10.0GB-30D-PF2BEFF37	ca-pf2beff37	10.0GB / 30 дней	10	30	19	North America 10GB 30Days Single Use	t
893	7	CA-5.0GB-30D-PWPB9E2B6	ca-pwpb9e2b6	5.0GB / 30 дней	5	30	10	North America 5GB   30Days Single Use	t
894	7	CA-3.0GB-30D-P2C6DT8XP	ca-p2c6dt8xp	3.0GB / 30 дней	3	30	6.6	North America 3GB 30Days Single Use	t
895	7	CA-1.0GB-7D-PB2CS54LH	ca-pb2cs54lh	1.0GB / 7 дней	1	7	2.5	North America  1GB 7Days Single Use	t
896	7	P62Q7VLTJ	ca-p62q7vltj	10.0GB / 30 дней	10	30	18	Canada 10GB 30Days Single Use	t
897	7	PL1YY76UZ	ca-pl1yy76uz	5.0GB / 30 дней	5	30	10	Canada 5GB  30Days Single Use	t
898	7	PUYZ1X5Z9	ca-puyz1x5z9	3.0GB / 30 дней	3	30	6.6	Canada 3GB  30Days Single Use	t
899	7	PNGH5E6S7	ca-pngh5e6s7	1.0GB / 7 дней	1	7	2.5	Canada 1GB 7Days Single Use	t
721	10	JC173	cn-jc173	3.0GB / 15 дней	3	15	3.7	China (mainland HK Macao) 3GB 15Days	t
722	10	JC174	cn-jc174	5.0GB / 30 дней	5	30	5.7	China (mainland HK Macao) 5GB 30Days	t
723	10	JC175	cn-jc175	10.0GB / 30 дней	10	30	9.9	China (mainland HK Macao) 10GB 30Days	t
724	10	JC176	cn-jc176	20.0GB / 30 дней	20	30	16.8	China (mainland HK Macao) 20GB 30Days	t
725	10	CN-1.0GB-30D-JC177	cn-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
726	10	CN-5.0GB-30D-JC178	cn-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
727	10	CN-3.0GB-15D-JC179	cn-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
728	10	CN-10.0GB-30D-JC180	cn-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
729	10	CN-20.0GB-90D-JC181	cn-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
730	10	CN-50.0GB-180D-JC182	cn-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
731	10	CN-1.0GB-7D-JC183	cn-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
732	10	CN-3.0GB-30D-PHD8GZ2VN	cn-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
733	10	CN-20.0GB-90D-PG3K0LHBC	cn-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
734	10	PXI7MA5MW	cn-pxi7ma5mw	50.0GB / 180 дней	50	180	28	China 50GB 180Days	t
735	10	PJKYY3QTL	cn-pjkyy3qtl	50.0GB / 180 дней	50	180	37	China (mainland HK Macao) 50GB 180Days	t
736	10	CN-1.0GB-365D-PCQXBW5UJ	cn-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
737	10	CN-1.0GB-7D-PHS30M6EZ	cn-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
738	10	CN-1.0GB-365D-PYMC5N31Z	cn-pymc5n31z	1.0GB / 365 дней	1	365	19		t
739	10	CN-5.0GB-30D-PEW54FVD9	cn-pew54fvd9	5.0GB / 30 дней	5	30	26		t
740	10	CN-3.0GB-30D-PW6P3DX2G	cn-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
741	10	CN-20.0GB-90D-PB83STJL6	cn-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3052	202	HU-3.0GB-30D-CKH006	hu-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3053	202	HU-5.0GB-30D-CKH007	hu-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3054	202	CKH088	hu-ckh088	3.0GB / 30 дней	3	30	2.3	Hungary 3GB 30Days	t
3055	202	CKH127	hu-ckh127	5.0GB / 30 дней	5	30	3.4	Hungary 5GB 30Days	t
742	10	CN-20.0GB-30D-PR3JZMC20	cn-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
743	10	CN-10.0GB-30D-P34FHRF8J	cn-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
744	10	CN-0.5GB-1D-PACK04L3R	cn-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
745	10	CN-1.0GB-1D-PXJ8HG40S	cn-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
746	10	CN-2.0GB-1D-PVBKS19B4	cn-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
747	10	CN-3.0GB-1D-PM5T3Z4UM	cn-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
748	10	PN6QWT0Q4	cn-pn6qwt0q4	0.49GB / 1 дней	0.49	1	0.9	China (mainland HK Macao) 500MB/Day	t
749	10	P78RBUJQ4	cn-p78rbujq4	1.0GB / 1 дней	1	1	1.6	China (mainland HK Macao) 1GB/Day	t
750	10	PY0WGY2C1	cn-py0wgy2c1	2.0GB / 1 дней	2	1	2.5	China (mainland HK Macao) 2GB/Day	t
751	10	PB64TT7WN	cn-pb64tt7wn	3.0GB / 1 дней	3	1	3.8	China (mainland HK Macao) 3GB/Day	t
752	10	PZ60GWHNI	cn-pz60gwhni	0.49GB / 1 дней	0.49	1	0.5		t
753	10	P92TALXP8	cn-p92talxp8	1.0GB / 1 дней	1	1	0.65		t
754	10	PBUK9LV51	cn-pbuk9lv51	2.0GB / 1 дней	2	1	1.2	China mainland 2GB/Day	t
755	10	P78LXV6UX	cn-p78lxv6ux	5.0GB / 1 дней	5	1	2.4	China mainland 5GB/Day	t
756	10	CN-1.0GB-7D-P4XU0X3CX	cn-p4xu0x3cx	1.0GB / 7 дней	1	7	2.3	China mainland & Japan & South Korea 1GB 7Days	t
757	10	CN-3.0GB-15D-P9Q0XP8HU	cn-p9q0xp8hu	3.0GB / 15 дней	3	15	5.7	China mainland & Japan & South Korea 3GB 15Days	t
758	10	CN-3.0GB-30D-P64BPV0PR	cn-p64bpv0pr	3.0GB / 30 дней	3	30	5.9	China mainland & Japan & South Korea 3GB 30Days	t
759	10	CN-5.0GB-30D-P5KZF2WY6	cn-p5kzf2wy6	5.0GB / 30 дней	5	30	8.8	China mainland & Japan & South Korea 5GB 30Days	t
760	10	CN-10.0GB-30D-P5JHQ39EE	cn-p5jhq39ee	10.0GB / 30 дней	10	30	15.2	China mainland & Japan & South Korea 10GB 30Days	t
761	10	CN-20.0GB-30D-P93F7ZCSY	cn-p93f7zcsy	20.0GB / 30 дней	20	30	25	China mainland & Japan & South Korea 20GB 30Days	t
762	10	CN-0.5GB-1D-PD4EBQ08R	cn-pd4ebq08r	0.49GB / 1 дней	0.49	1	1.2	China mainland & Japan & South Korea 500MB/Day	t
763	10	CN-1.0GB-1D-P8SU7BG1W	cn-p8su7bg1w	1.0GB / 1 дней	1	1	2.2	China mainland & Japan & South Korea 1GB/Day	t
764	10	CN-2.0GB-1D-P1Z74ZBVM	cn-p1z74zbvm	2.0GB / 1 дней	2	1	4.3	China mainland & Japan & South Korea 2GB/Day	t
393	4	FR-20.0GB-30D-CKH500	fr-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
394	4	FR-6.0GB-15D-AIS002	fr-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
395	4	CKH1005	fr-ckh1005	20.0GB / 30 дней	20	30	10.6	France 20GB 30Days	t
396	4	FR-1.0GB-7D-CKH823	fr-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
397	4	FR-5.0GB-30D-CKH825	fr-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
398	4	FR-10.0GB-30D-CKH826	fr-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
399	4	P5ML89XJG	fr-p5ml89xjg	50.0GB / 180 дней	50	180	22	France 50GB 180Days	t
400	4	FR-20.0GB-90D-P7VCE7FKY	fr-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
401	4	FR-50.0GB-180D-PGXJN6W2T	fr-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
402	4	FR-3.0GB-30D-PHD8GZ2VN	fr-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
403	4	FR-20.0GB-90D-PG3K0LHBC	fr-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
404	4	FR-1.0GB-365D-PCQXBW5UJ	fr-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
405	4	FR-1.0GB-30D-PM1HX6ES9	fr-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
406	4	FR-3.0GB-30D-PJK6T8JT2	fr-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
407	4	FR-5.0GB-30D-P87F6RTKY	fr-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
408	4	FR-1.0GB-7D-PV048NCRG	fr-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
409	4	FR-10.0GB-30D-P50GVS8GN	fr-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
410	4	FR-20.0GB-30D-PHC4X21NC	fr-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
411	4	FR-20.0GB-90D-P5NWWU08G	fr-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
412	4	FR-50.0GB-180D-PE70MYRZ5	fr-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
413	4	FR-1.0GB-1D-PUDV52A3R	fr-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
414	4	FR-1.5GB-1D-P34CJYA6C	fr-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
415	4	FR-1.0GB-7D-PHS30M6EZ	fr-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
416	4	FR-1.0GB-365D-PYMC5N31Z	fr-pymc5n31z	1.0GB / 365 дней	1	365	19		t
417	4	FR-5.0GB-30D-PEW54FVD9	fr-pew54fvd9	5.0GB / 30 дней	5	30	26		t
418	4	FR-3.0GB-30D-PW6P3DX2G	fr-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
419	4	FR-20.0GB-90D-PB83STJL6	fr-pb83stjl6	20.0GB / 90 дней	20	90	95		t
420	4	FR-20.0GB-30D-PR3JZMC20	fr-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
421	4	FR-10.0GB-30D-P34FHRF8J	fr-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
422	4	FR-2.0GB-1D-PZ6R8ASH9	fr-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
423	4	FR-3.0GB-1D-PE01DJZS7	fr-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
424	4	FR-0.5GB-1D-P61RQP7ZW	fr-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
425	4	FR-0.3GB-1D-P82Y6VYRL	fr-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
426	4	PG0H26XJA	fr-pg0h26xja	1.0GB / 1 дней	1	1	0.85	France 1GB/Day	t
427	4	PL2WG7K9D	fr-pl2wg7k9d	0.49GB / 1 дней	0.49	1	0.45	France 500MB/Day	t
428	4	P05WBGPG2	fr-p05wbgpg2	2.0GB / 1 дней	2	1	1.2	France 2GB/Day	t
429	4	P2G8P5FHJ	fr-p2g8p5fhj	5.0GB / 1 дней	5	1	2.3	France 5GB/Day	t
344	3	CKH995	de-ckh995	10.0GB / 30 дней	10	30	6.1	Germany 10GB 30Days	t
345	3	DE-1.0GB-7D-CKH484	de-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
346	3	DE-10.0GB-30D-CKH486	de-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
347	3	DE-20.0GB-30D-CKH500	de-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
348	3	DE-6.0GB-15D-AIS002	de-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
349	3	CKH1013	de-ckh1013	20.0GB / 30 дней	20	30	10.6	Germany 20GB 30Days	t
350	3	DE-1.0GB-7D-CKH823	de-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
351	3	DE-5.0GB-30D-CKH825	de-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
352	3	DE-10.0GB-30D-CKH826	de-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
353	3	PMDYU8KU3	de-pmdyu8ku3	50.0GB / 180 дней	50	180	22	Germany 50GB 180Days	t
354	3	DE-20.0GB-90D-P7VCE7FKY	de-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
355	3	DE-50.0GB-180D-PGXJN6W2T	de-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
356	3	DE-3.0GB-30D-PHD8GZ2VN	de-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
357	3	DE-20.0GB-90D-PG3K0LHBC	de-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
358	3	DE-1.0GB-365D-PCQXBW5UJ	de-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
359	3	DE-1.0GB-30D-PM1HX6ES9	de-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
360	3	DE-3.0GB-30D-PJK6T8JT2	de-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
361	3	DE-5.0GB-30D-P87F6RTKY	de-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
362	3	DE-1.0GB-7D-PV048NCRG	de-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
363	3	DE-10.0GB-30D-P50GVS8GN	de-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
364	3	DE-20.0GB-30D-PHC4X21NC	de-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
365	3	DE-20.0GB-90D-P5NWWU08G	de-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
366	3	DE-50.0GB-180D-PE70MYRZ5	de-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
367	3	DE-1.0GB-1D-PUDV52A3R	de-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
368	3	DE-1.5GB-1D-P34CJYA6C	de-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
369	3	DE-1.0GB-7D-PHS30M6EZ	de-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
370	3	DE-1.0GB-365D-PYMC5N31Z	de-pymc5n31z	1.0GB / 365 дней	1	365	19		t
371	3	DE-5.0GB-30D-PEW54FVD9	de-pew54fvd9	5.0GB / 30 дней	5	30	26		t
372	3	DE-3.0GB-30D-PW6P3DX2G	de-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
373	3	DE-20.0GB-90D-PB83STJL6	de-pb83stjl6	20.0GB / 90 дней	20	90	95		t
374	3	DE-20.0GB-30D-PR3JZMC20	de-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
375	3	DE-10.0GB-30D-P34FHRF8J	de-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
376	3	DE-2.0GB-1D-PZ6R8ASH9	de-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
377	3	DE-3.0GB-1D-PE01DJZS7	de-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
378	3	DE-0.5GB-1D-P61RQP7ZW	de-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
379	3	DE-0.3GB-1D-P82Y6VYRL	de-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
380	3	PXB5F4VY4	de-pxb5f4vy4	1.0GB / 1 дней	1	1	0.85		t
381	3	PQWSL862L	de-pqwsl862l	0.49GB / 1 дней	0.49	1	0.45	Germany 500MB/Day	t
382	3	PQ6VQPJ28	de-pq6vqpj28	2.0GB / 1 дней	2	1	1.5	Germany 2GB/Day	t
383	3	P241WBSZG	de-p241wbszg	5.0GB / 1 дней	5	1	2.5	Germany 5GB/Day	t
1067	13	PYGUMRHX1	in-pygumrhx1	1.0GB / 1 дней	1	1	2.4	India 1GB/Day	t
1068	13	IN-1.0GB-7D-PHS30M6EZ	in-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1069	13	IN-1.0GB-365D-PYMC5N31Z	in-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1070	13	IN-5.0GB-30D-PEW54FVD9	in-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1071	13	IN-3.0GB-30D-PW6P3DX2G	in-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1072	13	IN-20.0GB-90D-PB83STJL6	in-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1073	13	IN-20.0GB-30D-PR3JZMC20	in-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1074	13	IN-10.0GB-30D-P34FHRF8J	in-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3184	206	P6XJ4XAA1	iq-p6xj4xaa1	0.49GB / 1 дней	0.49	1	1.1	Iraq 500MB/Day	t
3196	207	IE-3.0GB-30D-CKH006	ie-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3197	207	IE-5.0GB-30D-CKH007	ie-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3198	207	CKH090	ie-ckh090	3.0GB / 30 дней	3	30	2.3	Ireland 3GB 30Days	t
3199	207	CKH129	ie-ckh129	5.0GB / 30 дней	5	30	3.4	Ireland 5GB 30Days	t
3200	207	CKH220	ie-ckh220	1.0GB / 7 дней	1	7	0.9	Ireland 1GB 7Days	t
3201	207	CKH221	ie-ckh221	3.0GB / 15 дней	3	15	2.2	Ireland 3GB 15Days	t
3202	207	CKH222	ie-ckh222	10.0GB / 30 дней	10	30	6.1	Ireland 10GB 30Days	t
3203	207	IE-1.0GB-7D-CKH484	ie-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3204	207	IE-10.0GB-30D-CKH486	ie-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1075	13	PKS9FL7X0	in-pks9fl7x0	2.0GB / 1 дней	2	1	4	India 2GB/Day	t
3205	207	IE-20.0GB-30D-CKH500	ie-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1099	265	KN-1.0GB-7D-PUSHF5X80	kn-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1974	148	CKH032	az-ckh032	3.0GB / 30 дней	3	30	17.9	Azerbaijan 3GB 30Days	t
1975	148	CKH281	az-ckh281	1.0GB / 7 дней	1	7	7.1	Azerbaijan 1GB 7Days	t
1976	148	CKH282	az-ckh282	3.0GB / 15 дней	3	15	17.6	Azerbaijan 3GB 15Days	t
1977	148	AZ-6.0GB-15D-AIS002	az-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1978	148	AZ-1.0GB-7D-CKH823	az-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1979	148	AZ-5.0GB-30D-CKH825	az-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1980	148	AZ-10.0GB-30D-CKH826	az-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1981	148	AZ-1.0GB-7D-CKH848	az-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
1982	148	AZ-5.0GB-30D-CKH850	az-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
1983	148	AZ-3.0GB-30D-PHD8GZ2VN	az-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1984	148	AZ-20.0GB-90D-PG3K0LHBC	az-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1985	148	AZ-3.0GB-30D-PNEKXVZKV	az-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
1986	148	AZ-1.0GB-365D-PCQXBW5UJ	az-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1987	148	AZ-1.0GB-7D-PHS30M6EZ	az-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1988	148	AZ-1.0GB-365D-PYMC5N31Z	az-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1989	148	AZ-5.0GB-30D-PEW54FVD9	az-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1990	148	AZ-3.0GB-30D-PW6P3DX2G	az-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1991	148	AZ-20.0GB-90D-PB83STJL6	az-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1992	148	AZ-20.0GB-30D-PR3JZMC20	az-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1993	148	AZ-10.0GB-30D-P34FHRF8J	az-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2014	149	BH-1.0GB-1D-P40YDJ9WA	bh-p40ydj9wa	1.0GB / 1 дней	1	1	2.9	Gulf Region 1GB/Day	t
2015	149	BH-0.5GB-1D-PW9U86NGE	bh-pw9u86nge	0.49GB / 1 дней	0.49	1	1.8	Gulf Region 500MB/Day	t
2016	149	BH-10.0GB-30D-P9DH2MUN5	bh-p9dh2mun5	10.0GB / 30 дней	10	30	22	Gulf Region 10GB 30Days Single Use	t
2017	149	BH-5.0GB-30D-PK2BXX9B4	bh-pk2bxx9b4	5.0GB / 30 дней	5	30	10.8	Gulf Region  5GB  30Days Single Use	t
2018	149	BH-3.0GB-30D-P8D7Q1CZY	bh-p8d7q1czy	3.0GB / 30 дней	3	30	6.8	Gulf Region  3GB  30Days Single Use	t
2019	149	BH-1.0GB-7D-PTJX062PT	bh-ptjx062pt	1.0GB / 7 дней	1	7	2.3	Gulf Region 1GB  7Days Single Use	t
2020	150	BD-6.0GB-8D-AIS001	bd-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
2021	150	BD-6.0GB-15D-AIS002	bd-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2022	150	JC110	bd-jc110	1.0GB / 7 дней	1	7	2.9	Bangladesh 1GB 7Days	t
2023	150	JC112	bd-jc112	3.0GB / 15 дней	3	15	7.2	Bangladesh 3GB 15Days	t
2024	150	JC113	bd-jc113	5.0GB / 30 дней	5	30	11	Bangladesh 5GB 30Days	t
3259	209	CKH024	il-ckh024	3.0GB / 30 дней	3	30	3.8	Israel 3GB 30Days	t
3260	209	CKH223	il-ckh223	1.0GB / 7 дней	1	7	1.5	Israel 1GB 7Days	t
3261	209	CKH224	il-ckh224	3.0GB / 15 дней	3	15	3.7	Israel 3GB 15Days	t
3262	209	CKH225	il-ckh225	5.0GB / 30 дней	5	30	5.7	Israel 5GB 30Days	t
3263	209	CKH226	il-ckh226	10.0GB / 30 дней	10	30	9.9	Israel 10GB 30Days	t
3264	209	IL-6.0GB-8D-AIS001	il-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3265	209	IL-6.0GB-15D-AIS002	il-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3266	209	CKH722	il-ckh722	20.0GB / 30 дней	20	30	16.8	Israel 20GB 30Days	t
3267	209	IL-1.0GB-7D-CKH823	il-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1145	270	SA-1.0GB-365D-PYMC5N31Z	sa-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1146	270	SA-5.0GB-30D-PEW54FVD9	sa-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1147	270	SA-3.0GB-30D-PW6P3DX2G	sa-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1148	270	SA-20.0GB-90D-PB83STJL6	sa-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1149	270	SA-20.0GB-30D-PR3JZMC20	sa-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1150	270	SA-10.0GB-30D-P34FHRF8J	sa-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1151	270	SA-10.0GB-1D-PLR26GSE7	sa-plr26gse7	10.0GB / 1 дней	10	1	22	Gulf Region 10GB/Day	t
1152	270	SA-5.0GB-1D-PLK713DWL	sa-plk713dwl	5.0GB / 1 дней	5	1	10.8	Gulf Region 5GB/Day	t
1153	270	SA-1.0GB-1D-P40YDJ9WA	sa-p40ydj9wa	1.0GB / 1 дней	1	1	2.9	Gulf Region 1GB/Day	t
1154	270	SA-0.5GB-1D-PW9U86NGE	sa-pw9u86nge	0.49GB / 1 дней	0.49	1	1.8	Gulf Region 500MB/Day	t
1155	270	SA-10.0GB-30D-P9DH2MUN5	sa-p9dh2mun5	10.0GB / 30 дней	10	30	22	Gulf Region 10GB 30Days Single Use	t
1156	270	SA-5.0GB-30D-PK2BXX9B4	sa-pk2bxx9b4	5.0GB / 30 дней	5	30	10.8	Gulf Region  5GB  30Days Single Use	t
1157	270	SA-3.0GB-30D-P8D7Q1CZY	sa-p8d7q1czy	3.0GB / 30 дней	3	30	6.8	Gulf Region  3GB  30Days Single Use	t
1158	270	SA-1.0GB-7D-PTJX062PT	sa-ptjx062pt	1.0GB / 7 дней	1	7	2.3	Gulf Region 1GB  7Days Single Use	t
1159	271	CKH385	sn-ckh385	1.0GB / 7 дней	1	7	7.1	Senegal 1GB 7Days	t
1160	271	CKH414	sn-ckh414	3.0GB / 15 дней	3	15	17.6	Senegal 3GB 15Days	t
1161	271	CKH443	sn-ckh443	5.0GB / 30 дней	5	30	26	Senegal 5GB 30Days	t
1162	271	SN-1.0GB-7D-CKH495	sn-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1163	271	SN-5.0GB-30D-CKH497	sn-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1164	271	SN-6.0GB-15D-AIS002	sn-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1165	271	SN-1.0GB-7D-CKH823	sn-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1166	271	SN-5.0GB-30D-CKH825	sn-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1167	271	SN-10.0GB-30D-CKH826	sn-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3302	211	JE-3.0GB-30D-CKH006	je-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3303	211	JE-5.0GB-30D-CKH007	je-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3321	212	CKH026	jo-ckh026	3.0GB / 30 дней	3	30	4.7	Jordan 3GB 30Days	t
3322	212	CKH269	jo-ckh269	1.0GB / 7 дней	1	7	1.8	Jordan 1GB 7Days	t
3323	212	CKH270	jo-ckh270	3.0GB / 15 дней	3	15	4.6	Jordan 3GB 15Days	t
3324	212	CKH271	jo-ckh271	5.0GB / 30 дней	5	30	7	Jordan 5GB 30Days	t
3325	212	CKH272	jo-ckh272	10.0GB / 30 дней	10	30	12.2	Jordan 10GB 30Days	t
3326	212	JO-6.0GB-8D-AIS001	jo-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3327	212	JO-6.0GB-15D-AIS002	jo-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3328	212	CKH790	jo-ckh790	20.0GB / 30 дней	20	30	20	Jordan 20GB 30Days	t
3329	212	JO-1.0GB-7D-CKH823	jo-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3345	213	KZ-6.0GB-8D-AIS001	kz-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3346	213	KZ-6.0GB-15D-AIS002	kz-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3347	213	CKH1030	kz-ckh1030	1.0GB / 7 дней	1	7	1.5	Kazakhstan 1GB 7Days	t
3348	213	CKH1031	kz-ckh1031	3.0GB / 15 дней	3	15	3.7	Kazakhstan 3GB 15Days	t
3349	213	CKH1032	kz-ckh1032	5.0GB / 30 дней	5	30	5.7	Kazakhstan 5GB 30Days	t
3350	213	CKH750	kz-ckh750	10.0GB / 30 дней	10	30	9.9	Kazakhstan 10GB 30Days	t
3351	213	CKH751	kz-ckh751	20.0GB / 30 дней	20	30	16.8	Kazakhstan 20GB 30Days	t
1168	271	SN-3.0GB-30D-P1XXDOD0C	sn-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1169	271	SN-3.0GB-30D-PHD8GZ2VN	sn-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1170	271	SN-20.0GB-90D-PG3K0LHBC	sn-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3389	215	KI-1.0GB-7D-CKH823	ki-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3390	215	KI-5.0GB-30D-CKH825	ki-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3391	215	KI-10.0GB-30D-CKH826	ki-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3392	215	KI-3.0GB-30D-PHD8GZ2VN	ki-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3393	215	KI-20.0GB-90D-PG3K0LHBC	ki-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3394	215	KI-1.0GB-365D-PCQXBW5UJ	ki-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3395	216	JC072	kr-jc072	1.0GB / 7 дней	1	7	0.7	South Korea 1GB 7Days	t
3396	216	JC073	kr-jc073	3.0GB / 15 дней	3	15	1.7	South Korea 3GB 15Days	t
3397	216	JC074	kr-jc074	5.0GB / 30 дней	5	30	2.7	South Korea 5GB 30Days	t
3398	216	JC075	kr-jc075	10.0GB / 30 дней	10	30	4.7	South Korea 10GB 30Days	t
3399	216	KR-6.0GB-8D-AIS001	kr-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3400	216	KR-6.0GB-15D-AIS002	kr-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3401	216	JC147	kr-jc147	20.0GB / 30 дней	20	30	8.2	South Korea 20GB 30Days	t
3402	216	KR-1.0GB-7D-CKH823	kr-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3403	216	KR-5.0GB-30D-CKH825	kr-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3404	216	KR-10.0GB-30D-CKH826	kr-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3405	216	KR-1.0GB-30D-JC177	kr-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
3406	216	KR-5.0GB-30D-JC178	kr-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
3407	216	KR-3.0GB-15D-JC179	kr-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
3408	216	KR-10.0GB-30D-JC180	kr-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
3409	216	KR-20.0GB-90D-JC181	kr-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
3410	216	KR-50.0GB-180D-JC182	kr-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
3411	216	KR-1.0GB-7D-JC183	kr-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
1171	271	SN-1.0GB-365D-PCQXBW5UJ	sn-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1172	271	SN-1.0GB-7D-PHS30M6EZ	sn-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1173	271	SN-1.0GB-365D-PYMC5N31Z	sn-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1174	271	SN-5.0GB-30D-PEW54FVD9	sn-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1175	271	SN-3.0GB-30D-PW6P3DX2G	sn-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1176	271	SN-20.0GB-90D-PB83STJL6	sn-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1177	271	SN-20.0GB-30D-PR3JZMC20	sn-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1178	271	SN-10.0GB-30D-P34FHRF8J	sn-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1194	272	RS-3.0GB-30D-PHD8GZ2VN	rs-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1195	272	RS-20.0GB-90D-PG3K0LHBC	rs-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1196	272	RS-1.0GB-365D-PCQXBW5UJ	rs-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1197	272	RS-1.0GB-7D-PHS30M6EZ	rs-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1198	272	RS-1.0GB-365D-PYMC5N31Z	rs-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1199	272	RS-5.0GB-30D-PEW54FVD9	rs-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1200	272	RS-3.0GB-30D-PW6P3DX2G	rs-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1201	272	RS-20.0GB-90D-PB83STJL6	rs-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1202	272	RS-20.0GB-30D-PR3JZMC20	rs-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1203	272	RS-10.0GB-30D-P34FHRF8J	rs-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1204	273	CKH386	sc-ckh386	1.0GB / 7 дней	1	7	4.6	Seychelles 1GB 7Days	t
1205	273	CKH415	sc-ckh415	3.0GB / 15 дней	3	15	11.2	Seychelles 3GB 15Days	t
1206	273	CKH444	sc-ckh444	5.0GB / 30 дней	5	30	17.1	Seychelles 5GB 30Days	t
1207	273	SC-1.0GB-7D-CKH495	sc-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1208	273	SC-5.0GB-30D-CKH497	sc-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1209	273	SC-6.0GB-15D-AIS002	sc-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1210	273	SC-1.0GB-7D-CKH823	sc-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1211	273	SC-5.0GB-30D-CKH825	sc-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1212	273	SC-10.0GB-30D-CKH826	sc-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1213	273	SC-3.0GB-30D-P1XXDOD0C	sc-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1214	273	SC-3.0GB-30D-PHD8GZ2VN	sc-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1215	273	SC-20.0GB-90D-PG3K0LHBC	sc-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1216	273	SC-1.0GB-365D-PCQXBW5UJ	sc-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
765	274	JC038	sg-jc038	1.0GB / 7 дней	1	7	0.7	Singapore 1GB 7Days	t
766	274	JC040	sg-jc040	5.0GB / 30 дней	5	30	2.7	Singapore 5GB 30Days	t
767	274	JC041	sg-jc041	10.0GB / 30 дней	10	30	4.7	Singapore 10GB 30Days	t
768	274	JC092	sg-jc092	20.0GB / 30 дней	20	30	8.2	Singapore 20GB 30Days	t
769	274	JC093	sg-jc093	50.0GB / 30 дней	50	30	28	Singapore 50GB 30Days	t
770	274	SG-6.0GB-8D-AIS001	sg-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
771	274	SG-6.0GB-15D-AIS002	sg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
772	274	SG-1.0GB-7D-CKH823	sg-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
773	274	SG-5.0GB-30D-CKH825	sg-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
774	274	SG-10.0GB-30D-CKH826	sg-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
775	274	SG-1.0GB-7D-JC165	sg-jc165	1.0GB / 7 дней	1	7	1.8	Asia (7 areas) 1GB 7Days	t
776	274	SG-3.0GB-15D-JC166	sg-jc166	3.0GB / 15 дней	3	15	4.6	Asia (7 areas) 3GB 15Days	t
777	274	SG-5.0GB-30D-JC167	sg-jc167	5.0GB / 30 дней	5	30	7	Asia (7 areas) 5GB 30Days	t
787	274	SG-3.0GB-30D-PHD8GZ2VN	sg-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
788	274	SG-20.0GB-90D-PG3K0LHBC	sg-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
789	274	PR2GUXUD5	sg-pr2guxud5	3.0GB / 30 дней	3	30	1.8	Singapore 3GB 30Days	t
790	274	SG-50.0GB-180D-P4GNDNA36	sg-p4gndna36	50.0GB / 180 дней	50	180	45	Asia (7 areas) 50GB 180Days	t
791	274	SG-1.0GB-365D-PCQXBW5UJ	sg-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
792	274	P7YECLII9	sg-p7yeclii9	1.0GB / 1 дней	1	1	0.9	Singapore 1GB/Day	t
793	274	PXAZ8ZALE	sg-pxaz8zale	2.0GB / 1 дней	2	1	1.8	Singapore 2GB/Day	t
794	274	PH83BFJ2F	sg-ph83bfj2f	0.49GB / 1 дней	0.49	1	0.5	Singapore 500MB/Day	t
795	274	SG-3.0GB-30D-PZ8NV3QK9	sg-pz8nv3qk9	3.0GB / 30 дней	3	30	3	Singapore & Malaysia & Thailand 3GB 30Days	t
796	274	SG-5.0GB-30D-PYX2W95MR	sg-pyx2w95mr	5.0GB / 30 дней	5	30	4.4	Singapore & Malaysia & Thailand 5GB 30Days	t
797	274	SG-10.0GB-30D-PY5TK3XX6	sg-py5tk3xx6	10.0GB / 30 дней	10	30	7.6	Singapore & Malaysia & Thailand 10GB 30Days	t
798	274	SG-20.0GB-30D-P9NV1LJN6	sg-p9nv1ljn6	20.0GB / 30 дней	20	30	12.9	Singapore & Malaysia & Thailand 20GB 30Days	t
799	274	SG-1.0GB-7D-PHS30M6EZ	sg-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
800	274	SG-1.0GB-365D-PYMC5N31Z	sg-pymc5n31z	1.0GB / 365 дней	1	365	19		t
801	274	SG-5.0GB-30D-PEW54FVD9	sg-pew54fvd9	5.0GB / 30 дней	5	30	26		t
802	274	SG-3.0GB-30D-PW6P3DX2G	sg-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
803	274	SG-20.0GB-90D-PB83STJL6	sg-pb83stjl6	20.0GB / 90 дней	20	90	95		t
804	274	SG-20.0GB-30D-PR3JZMC20	sg-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
805	274	SG-10.0GB-30D-P34FHRF8J	sg-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
806	274	SG-0.5GB-1D-PACK04L3R	sg-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
807	274	SG-1.0GB-1D-PXJ8HG40S	sg-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
808	274	SG-2.0GB-1D-PVBKS19B4	sg-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
809	274	SG-3.0GB-1D-PM5T3Z4UM	sg-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
810	274	P3LR5JXFO	sg-p3lr5jxfo	10.0GB / 1 дней	10	1	9		t
811	274	SG-1.0GB-1D-P0N8SUBG5	sg-p0n8subg5	1.0GB / 1 дней	1	1	1.7	Asia (7 areas) 1GB/Day	t
812	274	SG-0.5GB-1D-PX5NT8Z4K	sg-px5nt8z4k	0.49GB / 1 дней	0.49	1	0.9	Asia (7 areas) 500MB/Day	t
813	274	SG-2.0GB-1D-PBZUB2S60	sg-pbzub2s60	2.0GB / 1 дней	2	1	3	Asia (7 areas) 2GB/Day	t
814	274	SG-5.0GB-1D-PJ2W7KTJ4	sg-pj2w7ktj4	5.0GB / 1 дней	5	1	6	Asia (7 areas) 5GB/Day	t
815	274	SG-1.0GB-7D-P86Y3TMFZ	sg-p86y3tmfz	1.0GB / 7 дней	1	7	1.1	Singapore & Malaysia & Thailand 1GB 7Days	t
3500	219	LA-6.0GB-8D-AIS001	la-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3501	219	LA-6.0GB-15D-AIS002	la-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3502	220	LV-3.0GB-30D-CKH006	lv-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3503	220	LV-5.0GB-30D-CKH007	lv-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3504	220	CKH092	lv-ckh092	3.0GB / 30 дней	3	30	2.3	Latvia 3GB 30Days	t
3505	220	CKH131	lv-ckh131	5.0GB / 30 дней	5	30	3.4	Latvia 5GB 30Days	t
3506	220	CKH181	lv-ckh181	1.0GB / 7 дней	1	7	0.9	Latvia 1GB 7Days	t
3507	220	CKH182	lv-ckh182	3.0GB / 15 дней	3	15	2.2	Latvia 3GB 15Days	t
3508	220	CKH183	lv-ckh183	10.0GB / 30 дней	10	30	6.1	Latvia 10GB 30Days	t
3509	220	LV-1.0GB-7D-CKH484	lv-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3510	220	LV-10.0GB-30D-CKH486	lv-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
3645	224	CKH094	lu-ckh094	3.0GB / 30 дней	3	30	2.3	Luxembourg 3GB 30Days	t
816	274	SG-3.0GB-15D-P71Q4REAB	sg-p71q4reab	3.0GB / 15 дней	3	15	2.8	Singapore & Malaysia & Thailand 3GB 15Days	t
817	274	SG-0.5GB-1D-PB9B7RVL0	sg-pb9b7rvl0	0.49GB / 1 дней	0.49	1	0.6	Singapore & Malaysia & Thailand 500MB/Day	t
818	274	SG-1.0GB-1D-PS6VQM34Q	sg-ps6vqm34q	1.0GB / 1 дней	1	1	1	Singapore & Malaysia & Thailand 1GB/Day	t
819	274	SG-2.0GB-1D-PRPNZ697N	sg-prpnz697n	2.0GB / 1 дней	2	1	2	Singapore & Malaysia & Thailand 2GB/Day	t
1238	275	SK-10.0GB-30D-CKH826	sk-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1239	275	SK-20.0GB-90D-P7VCE7FKY	sk-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1240	275	SK-50.0GB-180D-PGXJN6W2T	sk-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1241	275	PG4XMKAYQ	sk-pg4xmkayq	50.0GB / 180 дней	50	180	30	Slovakia 50GB 180Days	t
1242	275	SK-3.0GB-30D-PHD8GZ2VN	sk-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1244	275	SK-1.0GB-365D-PCQXBW5UJ	sk-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1245	275	SK-1.0GB-30D-PM1HX6ES9	sk-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
1246	275	SK-3.0GB-30D-PJK6T8JT2	sk-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
1247	275	SK-5.0GB-30D-P87F6RTKY	sk-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
1248	275	SK-1.0GB-7D-PV048NCRG	sk-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
1249	275	SK-10.0GB-30D-P50GVS8GN	sk-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
1250	275	SK-20.0GB-30D-PHC4X21NC	sk-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
1251	275	SK-20.0GB-90D-P5NWWU08G	sk-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
1252	275	SK-50.0GB-180D-PE70MYRZ5	sk-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
1253	275	SK-1.0GB-1D-PUDV52A3R	sk-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
1254	275	SK-1.5GB-1D-P34CJYA6C	sk-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
1255	275	SK-1.0GB-7D-PHS30M6EZ	sk-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1256	275	SK-1.0GB-365D-PYMC5N31Z	sk-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3563	222	LI-3.0GB-30D-CKH006	li-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3564	222	LI-5.0GB-30D-CKH007	li-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3565	222	CKH981	li-ckh981	3.0GB / 30 дней	3	30	3.8	Liechtenstein 3GB 30Days	t
3566	222	LI-1.0GB-7D-CKH484	li-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3567	222	LI-10.0GB-30D-CKH486	li-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
3568	222	LI-20.0GB-30D-CKH500	li-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
3569	222	LI-6.0GB-15D-AIS002	li-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3570	222	CKH1015	li-ckh1015	1.0GB / 7 дней	1	7	1.5	Liechtenstein 1GB 7Days	t
3571	222	CKH1021	li-ckh1021	3.0GB / 15 дней	3	15	3.7	Liechtenstein 3GB 15Days	t
3572	222	LI-1.0GB-7D-CKH823	li-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3573	222	LI-5.0GB-30D-CKH825	li-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3574	222	LI-10.0GB-30D-CKH826	li-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3575	222	LI-20.0GB-90D-P7VCE7FKY	li-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3576	222	LI-50.0GB-180D-PGXJN6W2T	li-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3577	222	LI-3.0GB-30D-PHD8GZ2VN	li-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3578	222	LI-20.0GB-90D-PG3K0LHBC	li-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3646	224	CKH133	lu-ckh133	5.0GB / 30 дней	5	30	3.4	Luxembourg 5GB 30Days	t
1257	275	SK-5.0GB-30D-PEW54FVD9	sk-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1258	275	SK-3.0GB-30D-PW6P3DX2G	sk-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1259	275	SK-20.0GB-90D-PB83STJL6	sk-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1260	275	SK-20.0GB-30D-PR3JZMC20	sk-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1261	275	SK-10.0GB-30D-P34FHRF8J	sk-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1262	275	SK-2.0GB-1D-PZ6R8ASH9	sk-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
1263	275	SK-3.0GB-1D-PE01DJZS7	sk-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
1264	275	SK-0.5GB-1D-P61RQP7ZW	sk-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
1265	275	SK-0.3GB-1D-P82Y6VYRL	sk-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
1266	276	SI-3.0GB-30D-CKH006	si-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
1267	276	SI-5.0GB-30D-CKH007	si-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1268	276	CKH100	si-ckh100	3.0GB / 30 дней	3	30	2.3	Slovenia 3GB 30Days	t
1269	276	CKH139	si-ckh139	5.0GB / 30 дней	5	30	3.4	Slovenia 5GB 30Days	t
1270	276	CKH242	si-ckh242	1.0GB / 7 дней	1	7	0.9	Slovenia 1GB 7Days	t
1271	276	CKH243	si-ckh243	3.0GB / 15 дней	3	15	2.2	Slovenia 3GB 15Days	t
1272	276	CKH244	si-ckh244	10.0GB / 30 дней	10	30	6.1	Slovenia 10GB 30Days	t
1273	276	SI-1.0GB-7D-CKH484	si-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1274	276	SI-10.0GB-30D-CKH486	si-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1275	276	SI-20.0GB-30D-CKH500	si-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1276	276	SI-6.0GB-15D-AIS002	si-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1277	276	CKH732	si-ckh732	20.0GB / 30 дней	20	30	10.6	Slovenia 20GB 30Days	t
1278	276	SI-1.0GB-7D-CKH823	si-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1279	276	SI-5.0GB-30D-CKH825	si-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1280	276	SI-10.0GB-30D-CKH826	si-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1281	276	SI-20.0GB-90D-P7VCE7FKY	si-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1282	276	SI-50.0GB-180D-PGXJN6W2T	si-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1305	276	SI-3.0GB-1D-PE01DJZS7	si-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
1306	276	SI-0.5GB-1D-P61RQP7ZW	si-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
1307	276	SI-0.3GB-1D-P82Y6VYRL	si-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
1308	277	SB-6.0GB-15D-AIS002	sb-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1008	278	ZA-3.0GB-30D-P1XXDOD0C	za-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1009	278	ZA-3.0GB-30D-PHD8GZ2VN	za-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1010	278	ZA-20.0GB-90D-PG3K0LHBC	za-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1011	278	ZA-1.0GB-365D-PCQXBW5UJ	za-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1012	278	MB065	za-mb065	3.0GB / 30 дней	3	30	9.1	South Africa 3GB 30Days	t
1013	278	ZA-1.0GB-7D-PHS30M6EZ	za-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1014	278	ZA-1.0GB-365D-PYMC5N31Z	za-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1015	278	ZA-5.0GB-30D-PEW54FVD9	za-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1016	278	ZA-3.0GB-30D-PW6P3DX2G	za-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1017	278	ZA-20.0GB-90D-PB83STJL6	za-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1018	278	ZA-20.0GB-30D-PR3JZMC20	za-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1019	278	ZA-10.0GB-30D-P34FHRF8J	za-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3643	224	LU-3.0GB-30D-CKH006	lu-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3644	224	LU-5.0GB-30D-CKH007	lu-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1020	278	PBSI82U47	za-pbsi82u47	1.0GB / 1 дней	1	1	3.4		t
482	6	ES-1.0GB-7D-CKH484	es-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
483	6	ES-10.0GB-30D-CKH486	es-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
489	6	ES-5.0GB-30D-CKH825	es-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
490	6	ES-10.0GB-30D-CKH826	es-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
491	6	ES-20.0GB-90D-P7VCE7FKY	es-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
492	6	ES-50.0GB-180D-PGXJN6W2T	es-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
493	6	PSUZGLKSQ	es-psuzglksq	50.0GB / 180 дней	50	180	22	Spain 50GB 180Days	t
494	6	ES-3.0GB-30D-PHD8GZ2VN	es-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
495	6	ES-20.0GB-90D-PG3K0LHBC	es-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
496	6	ES-1.0GB-365D-PCQXBW5UJ	es-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
497	6	ES-1.0GB-30D-PM1HX6ES9	es-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
498	6	ES-3.0GB-30D-PJK6T8JT2	es-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
499	6	ES-5.0GB-30D-P87F6RTKY	es-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
500	6	ES-1.0GB-7D-PV048NCRG	es-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
501	6	ES-10.0GB-30D-P50GVS8GN	es-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
502	6	ES-20.0GB-30D-PHC4X21NC	es-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
503	6	ES-20.0GB-90D-P5NWWU08G	es-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
504	6	ES-50.0GB-180D-PE70MYRZ5	es-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
505	6	ES-1.0GB-1D-PUDV52A3R	es-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
506	6	ES-1.5GB-1D-P34CJYA6C	es-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
507	6	ES-1.0GB-7D-PHS30M6EZ	es-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
508	6	ES-1.0GB-365D-PYMC5N31Z	es-pymc5n31z	1.0GB / 365 дней	1	365	19		t
509	6	ES-5.0GB-30D-PEW54FVD9	es-pew54fvd9	5.0GB / 30 дней	5	30	26		t
510	6	ES-3.0GB-30D-PW6P3DX2G	es-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
511	6	ES-20.0GB-90D-PB83STJL6	es-pb83stjl6	20.0GB / 90 дней	20	90	95		t
512	6	ES-20.0GB-30D-PR3JZMC20	es-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
513	6	ES-10.0GB-30D-P34FHRF8J	es-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
514	6	ES-2.0GB-1D-PZ6R8ASH9	es-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
515	6	ES-3.0GB-1D-PE01DJZS7	es-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
516	6	ES-0.5GB-1D-P61RQP7ZW	es-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
517	6	ES-0.3GB-1D-P82Y6VYRL	es-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
518	6	P6WL2RRH5	es-p6wl2rrh5	0.49GB / 1 дней	0.49	1	0.45	Spain 500MB/Day	t
519	6	PZBY51PX0	es-pzby51px0	1.0GB / 1 дней	1	1	0.8	Spain 1GB/Day	t
520	6	P1BF5HDU2	es-p1bf5hdu2	2.0GB / 1 дней	2	1	1	Spain 2GB/Day	t
1327	279	LK-20.0GB-90D-PG3K0LHBC	lk-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1328	279	PVCA0JAXV	lk-pvca0jaxv	50.0GB / 180 дней	50	180	71	Sri Lanka 50GB 180Days	t
1329	279	LK-1.0GB-365D-PCQXBW5UJ	lk-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1330	279	LK-1.0GB-7D-PHS30M6EZ	lk-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1331	279	LK-1.0GB-365D-PYMC5N31Z	lk-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1332	279	LK-5.0GB-30D-PEW54FVD9	lk-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1333	279	LK-3.0GB-30D-PW6P3DX2G	lk-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1334	279	LK-20.0GB-90D-PB83STJL6	lk-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1335	279	LK-20.0GB-30D-PR3JZMC20	lk-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1336	279	LK-10.0GB-30D-P34FHRF8J	lk-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1337	279	PGP9AZY26	lk-pgp9azy26	10.0GB / 1 дней	10	1	10.8	Central Asia 10GB/Day	t
1338	279	P9RS4VV0A	lk-p9rs4vv0a	5.0GB / 1 дней	5	1	6	Central Asia 5GB/Day	t
1339	279	PJA28XEA7	lk-pja28xea7	1.0GB / 1 дней	1	1	1.4	Central Asia 1GB/Day	t
1340	279	P712EDLGB	lk-p712edlgb	0.49GB / 1 дней	0.49	1	0.6	Central Asia 500MB/Day	t
1341	279	PTSKLWZVK	lk-ptsklwzvk	3.0GB / 30 дней	3	30	4.9		t
1342	279	PF4K8XI0Q	lk-pf4k8xi0q	0.49GB / 1 дней	0.49	1	1.3		t
1343	279	PB6CYXWPA	lk-pb6cyxwpa	1.0GB / 1 дней	1	1	2.2		t
1344	279	PSUGO9SDM	lk-psugo9sdm	2.0GB / 1 дней	2	1	3.2		t
1345	279	PGP70GWM9	lk-pgp70gwm9	3.0GB / 1 дней	3	1	4.4		t
1346	279	PWNVS0KKQ	lk-pwnvs0kkq	5.0GB / 1 дней	5	1	7		t
1348	280	CKH417	sd-ckh417	3.0GB / 15 дней	3	15	27	Sudan 3GB 15Days	t
1349	280	CKH446	sd-ckh446	5.0GB / 30 дней	5	30	41	Sudan 5GB 30Days	t
1350	280	SD-1.0GB-7D-CKH495	sd-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1351	280	SD-5.0GB-30D-CKH497	sd-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1352	280	SD-1.0GB-7D-CKH823	sd-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3747	227	CKH367	mw-ckh367	1.0GB / 7 дней	1	7	5.7	Malawi 1GB 7Days	t
3748	227	CKH396	mw-ckh396	3.0GB / 15 дней	3	15	14.1	Malawi 3GB 15Days	t
3749	227	CKH425	mw-ckh425	5.0GB / 30 дней	5	30	21	Malawi 5GB 30Days	t
3750	227	MW-1.0GB-7D-CKH495	mw-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
3751	227	MW-5.0GB-30D-CKH497	mw-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
3752	227	MW-1.0GB-7D-CKH823	mw-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3753	227	MW-5.0GB-30D-CKH825	mw-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3754	227	MW-10.0GB-30D-CKH826	mw-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3755	227	MW-3.0GB-30D-P1XXDOD0C	mw-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
3756	227	MW-3.0GB-30D-PHD8GZ2VN	mw-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3757	227	MW-20.0GB-90D-PG3K0LHBC	mw-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3758	227	MW-1.0GB-365D-PCQXBW5UJ	mw-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3759	227	MW-1.0GB-7D-PHS30M6EZ	mw-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3760	227	MW-1.0GB-365D-PYMC5N31Z	mw-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3761	227	MW-5.0GB-30D-PEW54FVD9	mw-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3762	227	MW-3.0GB-30D-PW6P3DX2G	mw-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3763	227	MW-20.0GB-90D-PB83STJL6	mw-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3764	227	MW-20.0GB-30D-PR3JZMC20	mw-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1353	280	SD-5.0GB-30D-CKH825	sd-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1354	280	SD-10.0GB-30D-CKH826	sd-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1355	280	SD-3.0GB-30D-P1XXDOD0C	sd-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1356	280	SD-3.0GB-30D-PHD8GZ2VN	sd-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1357	280	SD-20.0GB-90D-PG3K0LHBC	sd-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1358	280	SD-1.0GB-365D-PCQXBW5UJ	sd-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1385	282	SE-20.0GB-30D-PHC4X21NC	se-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
1386	282	SE-20.0GB-90D-P5NWWU08G	se-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
1387	282	SE-50.0GB-180D-PE70MYRZ5	se-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
1388	282	SE-1.0GB-1D-PUDV52A3R	se-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
1389	282	SE-1.5GB-1D-P34CJYA6C	se-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
1390	282	SE-1.0GB-7D-PHS30M6EZ	se-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1391	282	SE-1.0GB-365D-PYMC5N31Z	se-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1392	282	SE-5.0GB-30D-PEW54FVD9	se-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1393	282	SE-3.0GB-30D-PW6P3DX2G	se-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1394	282	SE-20.0GB-90D-PB83STJL6	se-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1395	282	SE-20.0GB-30D-PR3JZMC20	se-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1396	282	SE-10.0GB-30D-P34FHRF8J	se-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1397	282	SE-2.0GB-1D-PZ6R8ASH9	se-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
1398	282	SE-3.0GB-1D-PE01DJZS7	se-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
1399	282	SE-0.5GB-1D-P61RQP7ZW	se-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
1400	282	SE-0.3GB-1D-P82Y6VYRL	se-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
1401	283	CH-3.0GB-30D-CKH006	ch-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
1402	283	CH-5.0GB-30D-CKH007	ch-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
1403	283	CKH102	ch-ckh102	3.0GB / 30 дней	3	30	2.3	Switzerland 3GB 30Days	t
1404	283	CKH141	ch-ckh141	5.0GB / 30 дней	5	30	3.4	Switzerland 5GB 30Days	t
1405	283	CKH247	ch-ckh247	1.0GB / 7 дней	1	7	0.9	Switzerland 1GB 7Days	t
1406	283	CKH248	ch-ckh248	3.0GB / 15 дней	3	15	2.2	Switzerland 3GB 15Days	t
1407	283	CKH249	ch-ckh249	10.0GB / 30 дней	10	30	6.1	Switzerland 10GB 30Days	t
1408	283	CH-1.0GB-7D-CKH484	ch-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
1409	283	CH-10.0GB-30D-CKH486	ch-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1410	283	CH-20.0GB-30D-CKH500	ch-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1411	283	CH-6.0GB-15D-AIS002	ch-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1412	283	CKH736	ch-ckh736	20.0GB / 30 дней	20	30	10.6	Switzerland 20GB 30Days	t
1413	283	CH-1.0GB-7D-CKH823	ch-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1414	283	CH-5.0GB-30D-CKH825	ch-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1415	283	CH-10.0GB-30D-CKH826	ch-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1416	283	CH-20.0GB-90D-P7VCE7FKY	ch-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1417	283	CH-50.0GB-180D-PGXJN6W2T	ch-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1418	283	PUOG8W99P	ch-puog8w99p	50.0GB / 180 дней	50	180	22	Switzerland 50GB 180Days	t
1419	283	CH-3.0GB-30D-PHD8GZ2VN	ch-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1420	283	CH-20.0GB-90D-PG3K0LHBC	ch-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1421	283	CH-1.0GB-365D-PCQXBW5UJ	ch-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1422	283	CH-1.0GB-30D-PM1HX6ES9	ch-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
1423	283	CH-3.0GB-30D-PJK6T8JT2	ch-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
1424	283	CH-5.0GB-30D-P87F6RTKY	ch-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
1425	283	CH-1.0GB-7D-PV048NCRG	ch-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
1432	283	CH-1.0GB-7D-PHS30M6EZ	ch-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1433	283	CH-1.0GB-365D-PYMC5N31Z	ch-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1434	283	CH-5.0GB-30D-PEW54FVD9	ch-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1435	283	CH-3.0GB-30D-PW6P3DX2G	ch-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1436	283	CH-20.0GB-90D-PB83STJL6	ch-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1437	283	CH-20.0GB-30D-PR3JZMC20	ch-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1438	283	CH-10.0GB-30D-P34FHRF8J	ch-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1439	283	CH-2.0GB-1D-PZ6R8ASH9	ch-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
1440	283	CH-3.0GB-1D-PE01DJZS7	ch-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3820	229	MV-6.0GB-15D-AIS002	mv-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3821	230	CKH381	ml-ckh381	1.0GB / 7 дней	1	7	7.1	Mali 1GB 7Days	t
1441	283	CH-0.5GB-1D-P61RQP7ZW	ch-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
1442	283	CH-0.3GB-1D-P82Y6VYRL	ch-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2025	150	JC156	bd-jc156	20.0GB / 30 дней	20	30	32	Bangladesh 20GB 30Days	t
2026	150	BD-1.0GB-7D-CKH823	bd-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2027	150	BD-5.0GB-30D-CKH825	bd-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2028	150	BD-10.0GB-30D-CKH826	bd-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2029	150	BD-3.0GB-30D-PHD8GZ2VN	bd-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2030	150	BD-20.0GB-90D-PG3K0LHBC	bd-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2031	150	BD-1.0GB-365D-PCQXBW5UJ	bd-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2072	153	BE-5.0GB-30D-P87F6RTKY	be-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
2073	153	BE-1.0GB-7D-PV048NCRG	be-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
2074	153	BE-10.0GB-30D-P50GVS8GN	be-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
2075	153	BE-20.0GB-30D-PHC4X21NC	be-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
2076	153	BE-20.0GB-90D-P5NWWU08G	be-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
2077	153	BE-50.0GB-180D-PE70MYRZ5	be-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
2078	153	BE-1.0GB-1D-PUDV52A3R	be-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
2079	153	BE-1.5GB-1D-P34CJYA6C	be-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
2080	153	BE-1.0GB-7D-PHS30M6EZ	be-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2081	153	BE-1.0GB-365D-PYMC5N31Z	be-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2082	153	BE-5.0GB-30D-PEW54FVD9	be-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2083	153	BE-3.0GB-30D-PW6P3DX2G	be-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2084	153	BE-20.0GB-90D-PB83STJL6	be-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2085	153	BE-20.0GB-30D-PR3JZMC20	be-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2086	153	BE-10.0GB-30D-P34FHRF8J	be-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2087	153	BE-2.0GB-1D-PZ6R8ASH9	be-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
2088	153	BE-3.0GB-1D-PE01DJZS7	be-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
2089	153	BE-0.5GB-1D-P61RQP7ZW	be-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
2090	153	BE-0.3GB-1D-P82Y6VYRL	be-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
2091	153	PWRT10ZX4	be-pwrt10zx4	1.0GB / 1 дней	1	1	0.85	Belgium 1GB/Day	t
2092	154	BT-6.0GB-15D-AIS002	bt-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
938	12	CKH301	br-ckh301	1.0GB / 7 дней	1	7	2.3	Brazil 1GB 7Days	t
939	12	CKH317	br-ckh317	3.0GB / 15 дней	3	15	5.7	Brazil 3GB 15Days	t
940	12	CKH487	br-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
941	12	CKH488	br-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
942	12	CKH489	br-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
943	12	CKH490	br-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
953	12	BR-1.0GB-365D-PYMC5N31Z	br-pymc5n31z	1.0GB / 365 дней	1	365	19		t
954	12	BR-5.0GB-30D-PEW54FVD9	br-pew54fvd9	5.0GB / 30 дней	5	30	26		t
955	12	BR-3.0GB-30D-PW6P3DX2G	br-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
956	12	BR-20.0GB-90D-PB83STJL6	br-pb83stjl6	20.0GB / 90 дней	20	90	95		t
957	12	BR-20.0GB-30D-PR3JZMC20	br-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
958	12	BR-10.0GB-30D-P34FHRF8J	br-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3880	232	MQ-1.0GB-7D-CKH487	mq-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
3881	232	MQ-3.0GB-15D-CKH488	mq-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
1445	284	TW-1.0GB-7D-CKH823	tw-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1446	284	TW-5.0GB-30D-CKH825	tw-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1447	284	TW-10.0GB-30D-CKH826	tw-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1448	284	TW-3.0GB-30D-PHD8GZ2VN	tw-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1449	284	TW-20.0GB-90D-PG3K0LHBC	tw-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1450	284	TW-1.0GB-365D-PCQXBW5UJ	tw-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1451	284	TW-1.0GB-7D-PHS30M6EZ	tw-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1452	284	TW-1.0GB-365D-PYMC5N31Z	tw-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1453	284	TW-5.0GB-30D-PEW54FVD9	tw-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1454	284	TW-3.0GB-30D-PW6P3DX2G	tw-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1455	284	TW-20.0GB-90D-PB83STJL6	tw-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1456	284	TW-20.0GB-30D-PR3JZMC20	tw-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1457	284	TW-10.0GB-30D-P34FHRF8J	tw-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1458	284	TW-0.5GB-1D-PACK04L3R	tw-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
1459	284	TW-1.0GB-1D-PXJ8HG40S	tw-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
1479	286	TZ-20.0GB-90D-PB83STJL6	tz-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3892	233	MU-1.0GB-7D-PHS30M6EZ	mu-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3901	235	MD-6.0GB-15D-AIS002	md-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3902	235	CKH523	md-ckh523	1.0GB / 7 дней	1	7	1.8	Moldova 1GB 7Days	t
3903	235	CKH647	md-ckh647	3.0GB / 15 дней	3	15	4.6	Moldova 3GB 15Days	t
3904	235	MD-1.0GB-7D-CKH823	md-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3905	235	MD-5.0GB-30D-CKH825	md-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3906	235	MD-10.0GB-30D-CKH826	md-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3907	235	MD-3.0GB-30D-PHD8GZ2VN	md-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3908	235	MD-20.0GB-90D-PG3K0LHBC	md-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3909	235	MD-1.0GB-365D-PCQXBW5UJ	md-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3917	236	MC-6.0GB-15D-AIS002	mc-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3918	236	CKH524	mc-ckh524	1.0GB / 7 дней	1	7	7.1	Monaco 1GB 7Days	t
3919	236	CKH650	mc-ckh650	3.0GB / 15 дней	3	15	17.6	Monaco 3GB 15Days	t
3920	236	CKH651	mc-ckh651	5.0GB / 30 дней	5	30	26	Monaco 5GB 30Days	t
3921	236	MC-1.0GB-7D-CKH823	mc-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3922	236	MC-5.0GB-30D-CKH825	mc-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3923	236	MC-10.0GB-30D-CKH826	mc-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3924	236	MC-3.0GB-30D-PHD8GZ2VN	mc-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3925	236	MC-20.0GB-90D-PG3K0LHBC	mc-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3934	237	MN-6.0GB-8D-AIS001	mn-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3935	237	MN-6.0GB-15D-AIS002	mn-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3936	237	MB004	mn-mb004	1.0GB / 7 дней	1	7	14	Mongolia 1GB 7Days	t
3937	237	MB010	mn-mb010	3.0GB / 15 дней	3	15	34	Mongolia 3GB 15Days	t
3938	238	ME-6.0GB-15D-AIS002	me-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3939	238	CKH1023	me-ckh1023	1.0GB / 7 дней	1	7	2.3	Montenegro 1GB 7Days	t
3940	238	CKH1024	me-ckh1024	3.0GB / 15 дней	3	15	5.7	Montenegro 3GB 15Days	t
3941	238	ME-1.0GB-7D-CKH823	me-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3942	238	ME-5.0GB-30D-CKH825	me-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1480	286	TZ-20.0GB-30D-PR3JZMC20	tz-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
616	15	JC165	th-jc165	1.0GB / 7 дней	1	7	1.8	Asia (7 areas) 1GB 7Days	t
617	15	JC166	th-jc166	3.0GB / 15 дней	3	15	4.6	Asia (7 areas) 3GB 15Days	t
618	15	JC167	th-jc167	5.0GB / 30 дней	5	30	7	Asia (7 areas) 5GB 30Days	t
619	15	JC168	th-jc168	10.0GB / 30 дней	10	30	12.2	Asia (7 areas) 10GB 30Days	t
620	15	JC169	th-jc169	20.0GB / 30 дней	20	30	20	Asia (7 areas) 20GB 30Days	t
622	15	JC178	th-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
623	15	JC179	th-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
624	15	JC180	th-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
625	15	JC181	th-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
626	15	JC182	th-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
3961	240	CKH382	ma-ckh382	1.0GB / 7 дней	1	7	1.5	Morocco 1GB 7Days	t
3962	240	CKH411	ma-ckh411	3.0GB / 15 дней	3	15	3.7	Morocco 3GB 15Days	t
3963	240	MA-1.0GB-7D-CKH495	ma-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
3964	240	MA-5.0GB-30D-CKH497	ma-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
3965	240	MA-1.0GB-7D-CKH823	ma-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3966	240	MA-5.0GB-30D-CKH825	ma-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3967	240	MA-10.0GB-30D-CKH826	ma-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
627	15	JC183	th-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
628	15	TH-3.0GB-30D-PHD8GZ2VN	th-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
629	15	TH-20.0GB-90D-PG3K0LHBC	th-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
630	15	PNJW9PBXH	th-pnjw9pbxh	50.0GB / 180 дней	50	180	32	Thailand 50GB 180Days	t
631	15	P4GNDNA36	th-p4gndna36	50.0GB / 180 дней	50	180	45	Asia (7 areas) 50GB 180Days	t
632	15	TH-1.0GB-365D-PCQXBW5UJ	th-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
633	15	PZ9GTBKFR	th-pz9gtbkfr	0.49GB / 1 дней	0.49	1	0.5	Thailand 500MB/Day	t
634	15	P5V3QF0VA	th-p5v3qf0va	1.0GB / 1 дней	1	1	0.9	Thailand 1GB/Day	t
635	15	PZ8NV3QK9	th-pz8nv3qk9	3.0GB / 30 дней	3	30	3	Singapore & Malaysia & Thailand 3GB 30Days	t
636	15	PYX2W95MR	th-pyx2w95mr	5.0GB / 30 дней	5	30	4.4	Singapore & Malaysia & Thailand 5GB 30Days	t
637	15	PY5TK3XX6	th-py5tk3xx6	10.0GB / 30 дней	10	30	7.6	Singapore & Malaysia & Thailand 10GB 30Days	t
638	15	P9NV1LJN6	th-p9nv1ljn6	20.0GB / 30 дней	20	30	12.9	Singapore & Malaysia & Thailand 20GB 30Days	t
3968	240	CKH829	ma-ckh829	20.0GB / 30 дней	20	30	16.8	Morocco 20GB 30Days	t
3969	240	MA-3.0GB-30D-P1XXDOD0C	ma-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
3986	241	MB043	mz-mb043	1.0GB / 7 дней	1	7	5.7	Mozambique 1GB 7Days	t
3987	241	MB047	mz-mb047	3.0GB / 15 дней	3	15	14.1	Mozambique 3GB 15Days	t
3988	241	MB055	mz-mb055	20.0GB / 30 дней	20	30	63	Mozambique 20GB 30Days	t
3989	242	NR-6.0GB-15D-AIS002	nr-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3990	243	NP-6.0GB-8D-AIS001	np-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3991	243	NP-6.0GB-15D-AIS002	np-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3992	243	MB003	np-mb003	1.0GB / 7 дней	1	7	8.9	Nepal 1GB 7Days	t
3993	243	MB013	np-mb013	3.0GB / 15 дней	3	15	21	Nepal 3GB 15Days	t
3994	244	NL-3.0GB-30D-CKH006	nl-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3995	244	NL-5.0GB-30D-CKH007	nl-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3996	244	CKH009	nl-ckh009	3.0GB / 30 дней	3	30	2.3	Netherlands 3GB 30Days	t
3997	244	CKH010	nl-ckh010	5.0GB / 30 дней	5	30	3.4	Netherlands 5GB 30Days	t
3998	244	CKH233	nl-ckh233	1.0GB / 7 дней	1	7	0.9	Netherlands 1GB 7Days	t
3999	244	CKH234	nl-ckh234	3.0GB / 15 дней	3	15	2.2	Netherlands 3GB 15Days	t
4000	244	CKH235	nl-ckh235	10.0GB / 30 дней	10	30	6.1	Netherlands 10GB 30Days	t
4001	244	NL-1.0GB-7D-CKH484	nl-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
4002	244	NL-10.0GB-30D-CKH486	nl-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
639	15	PZPE5LW98	th-pzpe5lw98	10.0GB / 1 дней	10	1	8	Thailand 10GB/Day	t
640	15	TH-1.0GB-7D-PHS30M6EZ	th-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
641	15	TH-1.0GB-365D-PYMC5N31Z	th-pymc5n31z	1.0GB / 365 дней	1	365	19		t
642	15	TH-5.0GB-30D-PEW54FVD9	th-pew54fvd9	5.0GB / 30 дней	5	30	26		t
643	15	TH-3.0GB-30D-PW6P3DX2G	th-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
644	15	TH-20.0GB-90D-PB83STJL6	th-pb83stjl6	20.0GB / 90 дней	20	90	95		t
645	15	TH-20.0GB-30D-PR3JZMC20	th-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
646	15	TH-10.0GB-30D-P34FHRF8J	th-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
647	15	PACK04L3R	th-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
648	15	PXJ8HG40S	th-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
649	15	PVBKS19B4	th-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
650	15	PM5T3Z4UM	th-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
651	15	P2R7CWSN9	th-p2r7cwsn9	2.0GB / 1 дней	2	1	1.6	Thailand 2GB/Day	t
652	15	PJ0FB89GA	th-pj0fb89ga	3.0GB / 1 дней	3	1	2.4	Thailand 3GB/Day	t
653	15	P0N8SUBG5	th-p0n8subg5	1.0GB / 1 дней	1	1	1.7	Asia (7 areas) 1GB/Day	t
654	15	PX5NT8Z4K	th-px5nt8z4k	0.49GB / 1 дней	0.49	1	0.9	Asia (7 areas) 500MB/Day	t
655	15	PBZUB2S60	th-pbzub2s60	2.0GB / 1 дней	2	1	3	Asia (7 areas) 2GB/Day	t
656	15	PJ2W7KTJ4	th-pj2w7ktj4	5.0GB / 1 дней	5	1	6	Asia (7 areas) 5GB/Day	t
657	15	P86Y3TMFZ	th-p86y3tmfz	1.0GB / 7 дней	1	7	1.1	Singapore & Malaysia & Thailand 1GB 7Days	t
658	15	P71Q4REAB	th-p71q4reab	3.0GB / 15 дней	3	15	2.8	Singapore & Malaysia & Thailand 3GB 15Days	t
659	15	PB9B7RVL0	th-pb9b7rvl0	0.49GB / 1 дней	0.49	1	0.6	Singapore & Malaysia & Thailand 500MB/Day	t
660	15	PS6VQM34Q	th-ps6vqm34q	1.0GB / 1 дней	1	1	1	Singapore & Malaysia & Thailand 1GB/Day	t
661	15	PRPNZ697N	th-prpnz697n	2.0GB / 1 дней	2	1	2	Singapore & Malaysia & Thailand 2GB/Day	t
1494	288	TN-20.0GB-90D-PG3K0LHBC	tn-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1495	288	PXX3PDGRD	tn-pxx3pdgrd	3.0GB / 30 дней	3	30	4.7	Tunisia 3GB 30Days	t
1496	288	TN-1.0GB-365D-PCQXBW5UJ	tn-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1497	288	TN-1.0GB-7D-PHS30M6EZ	tn-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1498	288	TN-1.0GB-365D-PYMC5N31Z	tn-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1499	288	TN-5.0GB-30D-PEW54FVD9	tn-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1500	288	TN-3.0GB-30D-PW6P3DX2G	tn-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1501	288	TN-20.0GB-90D-PB83STJL6	tn-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1502	288	TN-20.0GB-30D-PR3JZMC20	tn-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1503	288	TN-10.0GB-30D-P34FHRF8J	tn-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1504	288	PMV0HAP98	tn-pmv0hap98	1.0GB / 1 дней	1	1	1.7	Tunisia 1GB/Day	t
1505	289	TC-5.0GB-1D-PX18HJ4XW	tc-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1506	289	TC-1.0GB-1D-P8JCL47FC	tc-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
1507	289	TC-0.5GB-1D-PX2WSA7L1	tc-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1508	289	TC-10.0GB-30D-PCHZ59M2J	tc-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1509	289	TC-5.0GB-30D-P7GA02CZP	tc-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1510	289	TC-3.0GB-30D-PQB69VW8U	tc-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1511	289	TC-1.0GB-7D-PUSHF5X80	tc-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1520	291	UG-3.0GB-30D-PHD8GZ2VN	ug-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1521	291	UG-20.0GB-90D-PG3K0LHBC	ug-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1522	291	UG-1.0GB-365D-PCQXBW5UJ	ug-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1523	291	UG-1.0GB-7D-PHS30M6EZ	ug-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1524	291	UG-1.0GB-365D-PYMC5N31Z	ug-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1525	291	UG-5.0GB-30D-PEW54FVD9	ug-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1526	291	UG-3.0GB-30D-PW6P3DX2G	ug-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1527	291	UG-20.0GB-90D-PB83STJL6	ug-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1528	291	UG-20.0GB-30D-PR3JZMC20	ug-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1563	292	UA-20.0GB-90D-PB83STJL6	ua-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1564	292	UA-20.0GB-30D-PR3JZMC20	ua-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
4088	247	CKH383	ne-ckh383	1.0GB / 7 дней	1	7	7.1	Niger 1GB 7Days	t
4089	247	CKH412	ne-ckh412	3.0GB / 15 дней	3	15	17.6	Niger 3GB 15Days	t
4090	247	NE-1.0GB-7D-CKH495	ne-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
4091	247	NE-5.0GB-30D-CKH497	ne-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
4092	247	NE-1.0GB-7D-CKH823	ne-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4106	248	CKH384	ng-ckh384	1.0GB / 7 дней	1	7	4.6	Nigeria 1GB 7Days	t
4107	248	CKH413	ng-ckh413	3.0GB / 15 дней	3	15	11.2	Nigeria 3GB 15Days	t
4108	248	NG-1.0GB-7D-CKH495	ng-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
4109	248	NG-5.0GB-30D-CKH497	ng-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
4110	248	NG-6.0GB-15D-AIS002	ng-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4111	248	NG-1.0GB-7D-CKH823	ng-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4112	248	NG-5.0GB-30D-CKH825	ng-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4113	248	NG-10.0GB-30D-CKH826	ng-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4114	248	NG-3.0GB-30D-P1XXDOD0C	ng-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
4115	248	NG-3.0GB-30D-PHD8GZ2VN	ng-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
4116	248	NG-20.0GB-90D-PG3K0LHBC	ng-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
4117	248	NG-1.0GB-365D-PCQXBW5UJ	ng-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
4118	248	NG-1.0GB-7D-PHS30M6EZ	ng-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
4119	248	NG-1.0GB-365D-PYMC5N31Z	ng-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4120	248	NG-5.0GB-30D-PEW54FVD9	ng-pew54fvd9	5.0GB / 30 дней	5	30	26		t
4121	248	NG-3.0GB-30D-PW6P3DX2G	ng-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1565	292	UA-10.0GB-30D-P34FHRF8J	ua-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1566	292	UA-2.0GB-1D-PZ6R8ASH9	ua-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
1567	292	UA-3.0GB-1D-PE01DJZS7	ua-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
1568	292	UA-0.5GB-1D-P61RQP7ZW	ua-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
1569	292	UA-0.3GB-1D-P82Y6VYRL	ua-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
1570	292	P3AFY29GY	ua-p3afy29gy	1.0GB / 1 дней	1	1	0.65	Ukraine 1GB/Day	t
577	14	AE-5.0GB-30D-CKH825	ae-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
578	14	AE-10.0GB-30D-CKH826	ae-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
579	14	AE-1.0GB-7D-CKH848	ae-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
580	14	AE-5.0GB-30D-CKH850	ae-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
581	14	AE-3.0GB-30D-PHD8GZ2VN	ae-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
582	14	AE-20.0GB-90D-PG3K0LHBC	ae-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
583	14	AE-3.0GB-30D-PNEKXVZKV	ae-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
584	14	AE-1.0GB-365D-PCQXBW5UJ	ae-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
585	14	P0LWCN1S2	ae-p0lwcn1s2	20.0GB / 30 дней	20	30	26.54	United Arab Emirates 20GB 30Days	t
586	14	PQHJ267ZM	ae-pqhj267zm	10.0GB / 30 дней	10	30	14.98	United Arab Emirates 10GB 30Days	t
587	14	AE-1.0GB-7D-PHS30M6EZ	ae-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
588	14	AE-1.0GB-365D-PYMC5N31Z	ae-pymc5n31z	1.0GB / 365 дней	1	365	19		t
589	14	AE-5.0GB-30D-PEW54FVD9	ae-pew54fvd9	5.0GB / 30 дней	5	30	26		t
590	14	AE-3.0GB-30D-PW6P3DX2G	ae-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
591	14	AE-20.0GB-90D-PB83STJL6	ae-pb83stjl6	20.0GB / 90 дней	20	90	95		t
592	14	AE-20.0GB-30D-PR3JZMC20	ae-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
593	14	AE-10.0GB-30D-P34FHRF8J	ae-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
594	14	PLR26GSE7	ae-plr26gse7	10.0GB / 1 дней	10	1	22	Gulf Region 10GB/Day	t
595	14	PLK713DWL	ae-plk713dwl	5.0GB / 1 дней	5	1	10.8	Gulf Region 5GB/Day	t
596	14	P40YDJ9WA	ae-p40ydj9wa	1.0GB / 1 дней	1	1	2.9	Gulf Region 1GB/Day	t
597	14	PW9U86NGE	ae-pw9u86nge	0.49GB / 1 дней	0.49	1	1.8	Gulf Region 500MB/Day	t
598	14	P9DH2MUN5	ae-p9dh2mun5	10.0GB / 30 дней	10	30	22	Gulf Region 10GB 30Days Single Use	t
599	14	PK2BXX9B4	ae-pk2bxx9b4	5.0GB / 30 дней	5	30	10.8	Gulf Region  5GB  30Days Single Use	t
600	14	P8D7Q1CZY	ae-p8d7q1czy	3.0GB / 30 дней	3	30	6.8	Gulf Region  3GB  30Days Single Use	t
601	14	PTJX062PT	ae-ptjx062pt	1.0GB / 7 дней	1	7	2.3	Gulf Region 1GB  7Days Single Use	t
602	14	P6P4JNC5G	ae-p6p4jnc5g	1.0GB / 1 дней	1	1	2	United Arab Emirates 1GB/Day	t
4149	250	NO-3.0GB-30D-CKH006	no-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
4150	250	NO-5.0GB-30D-CKH007	no-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
603	14	PQWC3N4R1	ae-pqwc3n4r1	0.49GB / 1 дней	0.49	1	1.2	United Arab Emirates 500MB/Day	t
604	14	PRQJ9TH03	ae-prqj9th03	2.0GB / 1 дней	2	1	3	United Arab Emirates 2GB/Day	t
605	14	PVA0GD3V7	ae-pva0gd3v7	5.0GB / 1 дней	5	1	6.85	United Arab Emirates 5GB/Day	t
606	14	PBJCBSZU1	ae-pbjcbszu1	50.0GB / 180 дней	50	180	0.01		t
306	2	GB-5.0GB-30D-CKH825	gb-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
307	2	GB-10.0GB-30D-CKH826	gb-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
308	2	P7VCE7FKY	gb-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
309	2	PGXJN6W2T	gb-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
310	2	PLLWT4O6B	gb-pllwt4o6b	50.0GB / 180 дней	50	180	28	United Kingdom 50GB 180Days	t
311	2	GB-3.0GB-30D-PHD8GZ2VN	gb-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
312	2	GB-20.0GB-90D-PG3K0LHBC	gb-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
313	2	GB-1.0GB-365D-PCQXBW5UJ	gb-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
314	2	PF527KUIR	gb-pf527kuir	0.49GB / 1 дней	0.49	1	0.6	United Kingdom 500MB/Day	t
315	2	P0YFEWXGN	gb-p0yfewxgn	1.0GB / 1 дней	1	1	0.8	United Kingdom 1GB/Day	t
316	2	P9XKTG7UW	gb-p9xktg7uw	2.0GB / 1 дней	2	1	1.55	United Kingdom 2GB/Day	t
317	2	PM1HX6ES9	gb-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
318	2	PJK6T8JT2	gb-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
319	2	P87F6RTKY	gb-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
320	2	PV048NCRG	gb-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
321	2	P50GVS8GN	gb-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
322	2	PHC4X21NC	gb-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
323	2	P5NWWU08G	gb-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
324	2	PE70MYRZ5	gb-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
325	2	PUDV52A3R	gb-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
326	2	P34CJYA6C	gb-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
327	2	GB-1.0GB-7D-PHS30M6EZ	gb-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
328	2	GB-1.0GB-365D-PYMC5N31Z	gb-pymc5n31z	1.0GB / 365 дней	1	365	19		t
4214	252	PK-6.0GB-8D-AIS001	pk-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
4215	252	PK-6.0GB-15D-AIS002	pk-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4216	252	JC111	pk-jc111	1.0GB / 7 дней	1	7	1.8	Pakistan 1GB 7Days	t
4217	252	JC129	pk-jc129	3.0GB / 15 дней	3	15	4.6	Pakistan 3GB 15Days	t
4218	252	JC130	pk-jc130	5.0GB / 30 дней	5	30	7	Pakistan 5GB 30Days	t
4219	252	JC152	pk-jc152	10.0GB / 30 дней	10	30	12.2	Pakistan 10GB 30Days	t
4220	252	JC153	pk-jc153	20.0GB / 30 дней	20	30	20	Pakistan 20GB 30Days	t
4221	252	PK-1.0GB-7D-CKH823	pk-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
4222	252	PK-5.0GB-30D-CKH825	pk-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
4223	252	PK-10.0GB-30D-CKH826	pk-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
4224	252	PK-1.0GB-30D-JC177	pk-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
329	2	GB-5.0GB-30D-PEW54FVD9	gb-pew54fvd9	5.0GB / 30 дней	5	30	26		t
330	2	GB-3.0GB-30D-PW6P3DX2G	gb-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
331	2	GB-20.0GB-90D-PB83STJL6	gb-pb83stjl6	20.0GB / 90 дней	20	90	95		t
332	2	GB-20.0GB-30D-PR3JZMC20	gb-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
245	1	CKH491	us-ckh491	1.0GB / 7 дней	1	7	2.3	North America 1GB 7Days	t
246	1	CKH493	us-ckh493	5.0GB / 30 дней	5	30	8.8	North America 5GB 30Days	t
247	1	CKH494	us-ckh494	10.0GB / 30 дней	10	30	15.2	North America 10GB 30Days	t
248	1	CKH823	us-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
249	1	CKH825	us-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
250	1	CKH826	us-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
251	1	PB9HFSUS0	us-pb9hfsus0	3.0GB / 30 дней	3	30	5.9	North America 3GB 30Days	t
252	1	PVF7RTI3Y	us-pvf7rti3y	20.0GB / 90 дней	20	90	27	North America 20GB 90Days	t
253	1	POGTY0THV	us-pogty0thv	50.0GB / 180 дней	50	180	58	North America 50GB 180Days	t
254	1	PHD8GZ2VN	us-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
255	1	PG3K0LHBC	us-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
256	1	PCQXBW5UJ	us-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
275	1	PB83STJL6	us-pb83stjl6	20.0GB / 90 дней	20	90	95		t
276	1	PR3JZMC20	us-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
277	1	P34FHRF8J	us-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
278	1	PLF76MUC5	us-plf76muc5	0.49GB / 1 дней	0.49	1	1.15	North America 500MB/Day	t
279	1	P5N9FP7RL	us-p5n9fp7rl	3.0GB / 1 дней	3	1	5.6	North America 3GB/Day	t
280	1	PZGX3L09J	us-pzgx3l09j	3.0GB / 1 дней	3	1	3.8	United States 3GB/Day	t
281	1	PCD8C1K9R	us-pcd8c1k9r	0.49GB / 1 дней	0.49	1	0.86	United States 500MB/Day	t
282	1	P0VDH4W3H	us-p0vdh4w3h	10.0GB / 1 дней	10	1	12.4	United States 10GB/Day	t
283	1	PVT108ZDN	us-pvt108zdn	10.0GB / 1 дней	10	1	15.1	North America 10GB/Day	t
284	1	P8L7JA0WC	us-p8l7ja0wc	5.0GB / 1 дней	5	1	8.7	North America 5GB/Day	t
285	1	PF2BEFF37	us-pf2beff37	10.0GB / 30 дней	10	30	19	North America 10GB 30Days Single Use	t
286	1	PWPB9E2B6	us-pwpb9e2b6	5.0GB / 30 дней	5	30	10	North America 5GB   30Days Single Use	t
4246	253	PS-6.0GB-15D-AIS002	ps-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4247	254	CKH312	pa-ckh312	1.0GB / 7 дней	1	7	4.6	Panama 1GB 7Days	t
4268	255	PG-6.0GB-15D-AIS002	pg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
4269	256	CKH313	py-ckh313	1.0GB / 7 дней	1	7	4.6	Paraguay 1GB 7Days	t
4270	256	CKH329	py-ckh329	3.0GB / 15 дней	3	15	11.2	Paraguay 3GB 15Days	t
4271	256	PY-1.0GB-7D-CKH487	py-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
4272	256	PY-3.0GB-15D-CKH488	py-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
4297	257	CKH314	pe-ckh314	1.0GB / 7 дней	1	7	5.7	Peru 1GB 7Days	t
4298	257	CKH330	pe-ckh330	3.0GB / 15 дней	3	15	14.1	Peru 3GB 15Days	t
4299	257	PE-1.0GB-7D-CKH487	pe-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
287	1	P2C6DT8XP	us-p2c6dt8xp	3.0GB / 30 дней	3	30	6.6	North America 3GB 30Days Single Use	t
288	1	PB2CS54LH	us-pb2cs54lh	1.0GB / 7 дней	1	7	2.5	North America  1GB 7Days Single Use	t
289	1	PAQ367DAU	us-paq367dau	10.0GB / 30 дней	10	30	5.9	United States 10GB 30Days Single Use	t
290	1	PA0GX5V6R	us-pa0gx5v6r	5.0GB / 30 дней	5	30	3.25	United States 5GB  30Days Single Use	t
291	1	P50J6FMKJ	us-p50j6fmkj	3.0GB / 30 дней	3	30	2.2	United States 3GB  30Days Single Use	t
292	1	PZNVW17M2	us-pznvw17m2	1.0GB / 7 дней	1	7	0.8	United States 1GB  7Days Single Use	t
1571	293	CKH316	uy-ckh316	1.0GB / 7 дней	1	7	4.6	Uruguay 1GB 7Days	t
1572	293	CKH332	uy-ckh332	3.0GB / 15 дней	3	15	11.2	Uruguay 3GB 15Days	t
1573	293	UY-1.0GB-7D-CKH487	uy-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
1574	293	UY-3.0GB-15D-CKH488	uy-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
1575	293	UY-5.0GB-30D-CKH489	uy-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
1576	293	UY-10.0GB-30D-CKH490	uy-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
1577	293	UY-6.0GB-15D-AIS002	uy-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1578	293	UY-1.0GB-7D-CKH823	uy-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1579	293	UY-5.0GB-30D-CKH825	uy-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1580	293	UY-10.0GB-30D-CKH826	uy-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1581	293	UY-3.0GB-30D-P6FNJUAP4	uy-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
1582	293	UY-3.0GB-30D-PHD8GZ2VN	uy-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1583	293	UY-20.0GB-90D-PG3K0LHBC	uy-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1584	293	UY-1.0GB-365D-PCQXBW5UJ	uy-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1585	293	UY-1.0GB-7D-PHS30M6EZ	uy-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1586	293	UY-1.0GB-365D-PYMC5N31Z	uy-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1587	293	UY-5.0GB-30D-PEW54FVD9	uy-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1588	293	UY-3.0GB-30D-PW6P3DX2G	uy-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1589	293	UY-20.0GB-90D-PB83STJL6	uy-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1590	293	UY-20.0GB-30D-PR3JZMC20	uy-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1591	293	UY-10.0GB-30D-P34FHRF8J	uy-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1592	293	UY-5.0GB-1D-PX18HJ4XW	uy-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1593	293	UY-1.0GB-1D-P8JCL47FC	uy-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
1594	293	UY-0.5GB-1D-PX2WSA7L1	uy-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1622	295	JC048	vn-jc048	1.0GB / 7 дней	1	7	1.8	Vietnam 1GB 7Days	t
1623	295	JC049	vn-jc049	3.0GB / 15 дней	3	15	4.6	Vietnam 3GB 15Days	t
1624	295	JC050	vn-jc050	5.0GB / 30 дней	5	30	7	Vietnam 5GB 30Days	t
1625	295	JC051	vn-jc051	10.0GB / 30 дней	10	30	12.2	Vietnam 10GB 30Days	t
1626	295	JC088	vn-jc088	20.0GB / 30 дней	20	30	20	Vietnam 20GB 30Days	t
1627	295	VN-6.0GB-8D-AIS001	vn-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
1628	295	VN-6.0GB-15D-AIS002	vn-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1629	295	VN-1.0GB-7D-CKH823	vn-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1630	295	VN-5.0GB-30D-CKH825	vn-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1631	295	VN-10.0GB-30D-CKH826	vn-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1632	295	VN-1.0GB-7D-JC165	vn-jc165	1.0GB / 7 дней	1	7	1.8	Asia (7 areas) 1GB 7Days	t
1633	295	VN-3.0GB-15D-JC166	vn-jc166	3.0GB / 15 дней	3	15	4.6	Asia (7 areas) 3GB 15Days	t
1634	295	VN-5.0GB-30D-JC167	vn-jc167	5.0GB / 30 дней	5	30	7	Asia (7 areas) 5GB 30Days	t
1635	295	VN-10.0GB-30D-JC168	vn-jc168	10.0GB / 30 дней	10	30	12.2	Asia (7 areas) 10GB 30Days	t
1636	295	VN-20.0GB-30D-JC169	vn-jc169	20.0GB / 30 дней	20	30	20	Asia (7 areas) 20GB 30Days	t
1637	295	VN-1.0GB-30D-JC177	vn-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
1638	295	VN-5.0GB-30D-JC178	vn-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
1656	295	VN-1.0GB-1D-P0N8SUBG5	vn-p0n8subg5	1.0GB / 1 дней	1	1	1.7	Asia (7 areas) 1GB/Day	t
1657	295	VN-0.5GB-1D-PX5NT8Z4K	vn-px5nt8z4k	0.49GB / 1 дней	0.49	1	0.9	Asia (7 areas) 500MB/Day	t
1658	295	VN-2.0GB-1D-PBZUB2S60	vn-pbzub2s60	2.0GB / 1 дней	2	1	3	Asia (7 areas) 2GB/Day	t
1659	295	VN-5.0GB-1D-PJ2W7KTJ4	vn-pj2w7ktj4	5.0GB / 1 дней	5	1	6	Asia (7 areas) 5GB/Day	t
1660	295	PM2K0J3TX	vn-pm2k0j3tx	2.0GB / 1 дней	2	1	2.8	Vietnam 2GB/Day	t
1666	296	VG-5.0GB-30D-P7GA02CZP	vg-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1667	296	VG-3.0GB-30D-PQB69VW8U	vg-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1668	296	VG-1.0GB-7D-PUSHF5X80	vg-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1669	297	CKH285	ye-ckh285	1.0GB / 7 дней	1	7	11.2	Yemen 1GB 7Days	t
1670	297	CKH286	ye-ckh286	3.0GB / 15 дней	3	15	27	Yemen 3GB 15Days	t
1671	297	CKH287	ye-ckh287	5.0GB / 30 дней	5	30	41	Yemen 5GB 30Days	t
1672	297	YE-6.0GB-15D-AIS002	ye-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1673	297	YE-1.0GB-7D-CKH823	ye-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1674	297	YE-5.0GB-30D-CKH825	ye-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1685	298	ZM-1.0GB-7D-CKH823	zm-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1686	298	ZM-5.0GB-30D-CKH825	zm-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1687	298	ZM-10.0GB-30D-CKH826	zm-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1688	298	ZM-3.0GB-30D-P1XXDOD0C	zm-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1689	298	ZM-3.0GB-30D-PHD8GZ2VN	zm-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1711	300	AX-1.0GB-7D-CKH823	ax-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1712	300	AX-5.0GB-30D-CKH825	ax-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1713	300	AX-10.0GB-30D-CKH826	ax-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1714	300	AX-20.0GB-90D-P7VCE7FKY	ax-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1715	300	AX-50.0GB-180D-PGXJN6W2T	ax-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1716	300	AX-3.0GB-30D-PHD8GZ2VN	ax-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1717	300	AX-20.0GB-90D-PG3K0LHBC	ax-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
521	290	TR-3.0GB-30D-CKH006	tr-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
4369	259	PL-3.0GB-30D-CKH006	pl-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
4410	260	PT-3.0GB-30D-CKH006	pt-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
4411	260	PT-5.0GB-30D-CKH007	pt-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
4412	260	CKH980	pt-ckh980	3.0GB / 30 дней	3	30	2.3	Portugal 3GB 30Days	t
4413	260	CKH986	pt-ckh986	5.0GB / 30 дней	5	30	3.4	Portugal 5GB 30Days	t
4414	260	CKH1002	pt-ckh1002	1.0GB / 7 дней	1	7	0.9	Portugal 1GB 7Days	t
4415	260	CKH1003	pt-ckh1003	3.0GB / 15 дней	3	15	2.2	Portugal 3GB 15Days	t
4416	260	CKH1004	pt-ckh1004	10.0GB / 30 дней	10	30	6.1	Portugal 10GB 30Days	t
522	290	TR-5.0GB-30D-CKH007	tr-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
523	290	CKH025	tr-ckh025	3.0GB / 30 дней	3	30	1.8	Turkey 3GB 30Days	t
524	290	CKH265	tr-ckh265	1.0GB / 7 дней	1	7	0.7	Turkey 1GB 7Days	t
525	290	CKH266	tr-ckh266	3.0GB / 15 дней	3	15	1.7	Turkey 3GB 15Days	t
526	290	CKH267	tr-ckh267	5.0GB / 30 дней	5	30	2.7	Turkey 5GB 30Days	t
527	290	CKH268	tr-ckh268	10.0GB / 30 дней	10	30	4.7	Turkey 10GB 30Days	t
528	290	TR-1.0GB-7D-CKH484	tr-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
529	290	TR-10.0GB-30D-CKH486	tr-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
530	290	TR-20.0GB-30D-CKH500	tr-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
531	290	TR-6.0GB-15D-AIS002	tr-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
532	290	CKH738	tr-ckh738	20.0GB / 30 дней	20	30	8.2	Turkey 20GB 30Days	t
533	290	TR-1.0GB-7D-CKH823	tr-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
534	290	TR-5.0GB-30D-CKH825	tr-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
535	290	TR-10.0GB-30D-CKH826	tr-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
536	290	CKH848	tr-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
537	290	CKH850	tr-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
538	290	TR-20.0GB-90D-P7VCE7FKY	tr-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
539	290	TR-50.0GB-180D-PGXJN6W2T	tr-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
540	290	PAV5NMZ28	tr-pav5nmz28	50.0GB / 180 дней	50	180	32	Turkey 50GB 180Days	t
541	290	TR-3.0GB-30D-PHD8GZ2VN	tr-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
542	290	TR-20.0GB-90D-PG3K0LHBC	tr-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
543	290	PNEKXVZKV	tr-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
544	290	TR-1.0GB-365D-PCQXBW5UJ	tr-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
545	290	TR-1.0GB-30D-PM1HX6ES9	tr-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
546	290	TR-3.0GB-30D-PJK6T8JT2	tr-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
547	290	TR-5.0GB-30D-P87F6RTKY	tr-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
548	290	TR-1.0GB-7D-PV048NCRG	tr-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
549	290	TR-10.0GB-30D-P50GVS8GN	tr-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
550	290	TR-20.0GB-30D-PHC4X21NC	tr-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
551	290	TR-20.0GB-90D-P5NWWU08G	tr-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
552	290	TR-50.0GB-180D-PE70MYRZ5	tr-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
553	290	TR-1.0GB-1D-PUDV52A3R	tr-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
554	290	TR-1.5GB-1D-P34CJYA6C	tr-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
555	290	TR-1.0GB-7D-PHS30M6EZ	tr-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
556	290	TR-1.0GB-365D-PYMC5N31Z	tr-pymc5n31z	1.0GB / 365 дней	1	365	19		t
557	290	TR-5.0GB-30D-PEW54FVD9	tr-pew54fvd9	5.0GB / 30 дней	5	30	26		t
558	290	TR-3.0GB-30D-PW6P3DX2G	tr-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
559	290	TR-20.0GB-90D-PB83STJL6	tr-pb83stjl6	20.0GB / 90 дней	20	90	95		t
560	290	TR-20.0GB-30D-PR3JZMC20	tr-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
561	290	TR-10.0GB-30D-P34FHRF8J	tr-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
562	290	TR-2.0GB-1D-PZ6R8ASH9	tr-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
563	290	TR-3.0GB-1D-PE01DJZS7	tr-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
564	290	TR-0.5GB-1D-P61RQP7ZW	tr-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
565	290	TR-0.3GB-1D-P82Y6VYRL	tr-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
566	290	P1G6QKLC2	tr-p1g6qklc2	1.0GB / 1 дней	1	1	0.65	Turkey 1GB/Day	t
567	290	P4PJDQ93V	tr-p4pjdq93v	0.49GB / 1 дней	0.49	1	0.5	Turkey 500MB/Day	t
568	290	PF1K57KAZ	tr-pf1k57kaz	2.0GB / 1 дней	2	1	1.2	Turkey 2GB/Day	t
569	290	P3V2FT7FJ	tr-p3v2ft7fj	5.0GB / 1 дней	5	1	2.4	Turkey 5GB/Day	t
1030	11	RU-6.0GB-15D-AIS002	ru-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1031	11	RU-1.0GB-7D-CKH823	ru-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1032	11	RU-5.0GB-30D-CKH825	ru-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1033	11	RU-10.0GB-30D-CKH826	ru-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1034	11	RU-20.0GB-90D-P7VCE7FKY	ru-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1035	11	RU-50.0GB-180D-PGXJN6W2T	ru-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1036	11	RU-3.0GB-30D-PHD8GZ2VN	ru-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1037	11	RU-20.0GB-90D-PG3K0LHBC	ru-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1038	11	RU-1.0GB-365D-PCQXBW5UJ	ru-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1039	11	RU-1.0GB-7D-PHS30M6EZ	ru-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1040	11	RU-1.0GB-365D-PYMC5N31Z	ru-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1041	11	RU-5.0GB-30D-PEW54FVD9	ru-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1042	11	RU-3.0GB-30D-PW6P3DX2G	ru-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1043	11	RU-20.0GB-90D-PB83STJL6	ru-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1044	11	RU-20.0GB-30D-PR3JZMC20	ru-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1045	11	RU-10.0GB-30D-P34FHRF8J	ru-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1733	139	!RG-20.0GB-30D-CKH500	!rg-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1734	139	!RG-1.0GB-7D-CKH848	!rg-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
4513	263	RO-3.0GB-30D-CKH006	ro-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
4514	263	RO-5.0GB-30D-CKH007	ro-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
4515	263	CKH098	ro-ckh098	3.0GB / 30 дней	3	30	1.8	Romania 3GB 30Days	t
4516	263	CKH137	ro-ckh137	5.0GB / 30 дней	5	30	2.7	Romania 5GB 30Days	t
4517	263	CKH239	ro-ckh239	1.0GB / 7 дней	1	7	0.7	Romania 1GB 7Days	t
4518	263	CKH240	ro-ckh240	3.0GB / 15 дней	3	15	1.7	Romania 3GB 15Days	t
4519	263	CKH241	ro-ckh241	10.0GB / 30 дней	10	30	4.7	Romania 10GB 30Days	t
343	3	CKH994	de-ckh994	3.0GB / 15 дней	3	15	2.2	Germany 3GB 15Days	t
1735	139	!RG-5.0GB-30D-CKH850	!rg-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
1736	139	!RG-1.0GB-7D-JC172	!rg-jc172	1.0GB / 7 дней	1	7	1.5	China (mainland HK Macao) 1GB 7Days	t
1737	139	!RG-3.0GB-15D-JC173	!rg-jc173	3.0GB / 15 дней	3	15	3.7	China (mainland HK Macao) 3GB 15Days	t
1738	139	!RG-5.0GB-30D-JC174	!rg-jc174	5.0GB / 30 дней	5	30	5.7	China (mainland HK Macao) 5GB 30Days	t
1739	139	!RG-10.0GB-30D-JC175	!rg-jc175	10.0GB / 30 дней	10	30	9.9	China (mainland HK Macao) 10GB 30Days	t
1740	139	!RG-20.0GB-30D-JC176	!rg-jc176	20.0GB / 30 дней	20	30	16.8	China (mainland HK Macao) 20GB 30Days	t
1741	139	!RG-1.0GB-7D-JC165	!rg-jc165	1.0GB / 7 дней	1	7	1.8	Asia (7 areas) 1GB 7Days	t
1742	139	!RG-3.0GB-15D-JC166	!rg-jc166	3.0GB / 15 дней	3	15	4.6	Asia (7 areas) 3GB 15Days	t
1743	139	!RG-5.0GB-30D-JC167	!rg-jc167	5.0GB / 30 дней	5	30	7	Asia (7 areas) 5GB 30Days	t
1744	139	!RG-10.0GB-30D-JC168	!rg-jc168	10.0GB / 30 дней	10	30	12.2	Asia (7 areas) 10GB 30Days	t
1745	139	!RG-20.0GB-30D-JC169	!rg-jc169	20.0GB / 30 дней	20	30	20	Asia (7 areas) 20GB 30Days	t
1746	139	!RG-1.0GB-30D-JC177	!rg-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
1747	139	!RG-5.0GB-30D-JC178	!rg-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
1748	139	!RG-3.0GB-15D-JC179	!rg-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
1749	139	!RG-10.0GB-30D-JC180	!rg-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
1750	139	!RG-20.0GB-90D-JC181	!rg-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
1751	139	!RG-50.0GB-180D-JC182	!rg-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
1752	139	!RG-1.0GB-7D-JC183	!rg-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
1753	139	!RG-3.0GB-30D-P6FNJUAP4	!rg-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
1754	139	!RG-3.0GB-30D-PB9HFSUS0	!rg-pb9hfsus0	3.0GB / 30 дней	3	30	5.9	North America 3GB 30Days	t
1755	139	!RG-3.0GB-30D-P1XXDOD0C	!rg-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1756	139	!RG-20.0GB-90D-P7VCE7FKY	!rg-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1781	139	!RG-2.0GB-1D-PZ6R8ASH9	!rg-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
1782	139	!RG-3.0GB-1D-PE01DJZS7	!rg-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
1783	139	!RG-0.5GB-1D-PACK04L3R	!rg-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
1784	139	!RG-1.0GB-1D-PXJ8HG40S	!rg-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
1785	139	!RG-2.0GB-1D-PVBKS19B4	!rg-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
1786	139	!RG-3.0GB-1D-PM5T3Z4UM	!rg-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
1787	139	!RG-0.5GB-1D-PN6QWT0Q4	!rg-pn6qwt0q4	0.49GB / 1 дней	0.49	1	0.9	China (mainland HK Macao) 500MB/Day	t
1788	139	!RG-1.0GB-1D-P78RBUJQ4	!rg-p78rbujq4	1.0GB / 1 дней	1	1	1.6	China (mainland HK Macao) 1GB/Day	t
1789	139	!RG-2.0GB-1D-PY0WGY2C1	!rg-py0wgy2c1	2.0GB / 1 дней	2	1	2.5	China (mainland HK Macao) 2GB/Day	t
1790	139	!RG-3.0GB-1D-PB64TT7WN	!rg-pb64tt7wn	3.0GB / 1 дней	3	1	3.8	China (mainland HK Macao) 3GB/Day	t
1791	139	!RG-0.5GB-1D-P61RQP7ZW	!rg-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
1792	139	!RG-0.3GB-1D-P82Y6VYRL	!rg-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
1793	139	!RG-0.5GB-1D-PLF76MUC5	!rg-plf76muc5	0.49GB / 1 дней	0.49	1	1.15	North America 500MB/Day	t
853	7	CA-1.0GB-7D-CKH491	ca-ckh491	1.0GB / 7 дней	1	7	2.3	North America 1GB 7Days	t
854	7	CA-5.0GB-30D-CKH493	ca-ckh493	5.0GB / 30 дней	5	30	8.8	North America 5GB 30Days	t
855	7	CA-10.0GB-30D-CKH494	ca-ckh494	10.0GB / 30 дней	10	30	15.2	North America 10GB 30Days	t
856	7	CA-6.0GB-15D-AIS002	ca-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
857	7	CKH516	ca-ckh516	1.0GB / 7 дней	1	7	2.3	Canada 1GB 7Days	t
858	7	CKH578	ca-ckh578	3.0GB / 15 дней	3	15	5.7	Canada 3GB 15Days	t
859	7	CKH579	ca-ckh579	5.0GB / 30 дней	5	30	8.8	Canada 5GB 30Days	t
860	7	CKH778	ca-ckh778	10.0GB / 30 дней	10	30	15.2	Canada 10GB 30Days	t
861	7	CKH779	ca-ckh779	20.0GB / 30 дней	20	30	25	Canada 20GB 30Days	t
862	7	CA-1.0GB-7D-CKH823	ca-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
863	7	CA-5.0GB-30D-CKH825	ca-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
864	7	CA-10.0GB-30D-CKH826	ca-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
865	7	CA-3.0GB-30D-PB9HFSUS0	ca-pb9hfsus0	3.0GB / 30 дней	3	30	5.9	North America 3GB 30Days	t
866	7	CA-20.0GB-90D-PVF7RTI3Y	ca-pvf7rti3y	20.0GB / 90 дней	20	90	27	North America 20GB 90Days	t
867	7	CA-50.0GB-180D-POGTY0THV	ca-pogty0thv	50.0GB / 180 дней	50	180	58	North America 50GB 180Days	t
868	7	CA-3.0GB-30D-PHD8GZ2VN	ca-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
869	7	CA-20.0GB-90D-PG3K0LHBC	ca-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
870	7	CA-1.0GB-365D-PCQXBW5UJ	ca-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
871	7	P4SQTPX02	ca-p4sqtpx02	1.0GB / 1 дней	1	1	1.8	Canada 1GB/Day	t
872	7	PDSKSPL0T	ca-pdskspl0t	1.5GB / 1 дней	1.5	1	2.7	Canada 1.5GB/Day	t
873	7	P3BGO3VLL	ca-p3bgo3vll	2.0GB / 1 дней	2	1	3.6	Canada 2GB/Day	t
874	7	CA-1.0GB-1D-PCTEPKHJW	ca-pctepkhjw	1.0GB / 1 дней	1	1	2.2	North America 1GB/Day	t
1794	139	!RG-3.0GB-1D-P5N9FP7RL	!rg-p5n9fp7rl	3.0GB / 1 дней	3	1	5.6	North America 3GB/Day	t
1795	139	!RG-10.0GB-1D-PGP9AZY26	!rg-pgp9azy26	10.0GB / 1 дней	10	1	10.8	Central Asia 10GB/Day	t
1796	139	!RG-5.0GB-1D-P9RS4VV0A	!rg-p9rs4vv0a	5.0GB / 1 дней	5	1	6	Central Asia 5GB/Day	t
1797	139	!RG-1.0GB-1D-PJA28XEA7	!rg-pja28xea7	1.0GB / 1 дней	1	1	1.4	Central Asia 1GB/Day	t
1798	139	!RG-0.5GB-1D-P712EDLGB	!rg-p712edlgb	0.49GB / 1 дней	0.49	1	0.6	Central Asia 500MB/Day	t
1799	139	!RG-10.0GB-1D-PLR26GSE7	!rg-plr26gse7	10.0GB / 1 дней	10	1	22	Gulf Region 10GB/Day	t
1800	139	!RG-5.0GB-1D-PLK713DWL	!rg-plk713dwl	5.0GB / 1 дней	5	1	10.8	Gulf Region 5GB/Day	t
1801	139	!RG-1.0GB-1D-P40YDJ9WA	!rg-p40ydj9wa	1.0GB / 1 дней	1	1	2.9	Gulf Region 1GB/Day	t
1802	139	!RG-0.5GB-1D-PW9U86NGE	!rg-pw9u86nge	0.49GB / 1 дней	0.49	1	1.8	Gulf Region 500MB/Day	t
1803	139	!RG-5.0GB-1D-PX18HJ4XW	!rg-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
1804	139	!RG-1.0GB-1D-P8JCL47FC	!rg-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
1805	139	!RG-0.5GB-1D-PX2WSA7L1	!rg-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1806	139	!RG-10.0GB-1D-PVT108ZDN	!rg-pvt108zdn	10.0GB / 1 дней	10	1	15.1	North America 10GB/Day	t
1807	139	!RG-5.0GB-1D-P8L7JA0WC	!rg-p8l7ja0wc	5.0GB / 1 дней	5	1	8.7	North America 5GB/Day	t
1808	139	!RG-10.0GB-30D-PF2BEFF37	!rg-pf2beff37	10.0GB / 30 дней	10	30	19	North America 10GB 30Days Single Use	t
1809	139	!RG-5.0GB-30D-PWPB9E2B6	!rg-pwpb9e2b6	5.0GB / 30 дней	5	30	10	North America 5GB   30Days Single Use	t
1810	139	!RG-3.0GB-30D-P2C6DT8XP	!rg-p2c6dt8xp	3.0GB / 30 дней	3	30	6.6	North America 3GB 30Days Single Use	t
1811	139	!RG-1.0GB-7D-PB2CS54LH	!rg-pb2cs54lh	1.0GB / 7 дней	1	7	2.5	North America  1GB 7Days Single Use	t
1812	139	!RG-10.0GB-30D-P9DH2MUN5	!rg-p9dh2mun5	10.0GB / 30 дней	10	30	22	Gulf Region 10GB 30Days Single Use	t
1813	139	!RG-5.0GB-30D-PK2BXX9B4	!rg-pk2bxx9b4	5.0GB / 30 дней	5	30	10.8	Gulf Region  5GB  30Days Single Use	t
1814	139	!RG-3.0GB-30D-P8D7Q1CZY	!rg-p8d7q1czy	3.0GB / 30 дней	3	30	6.8	Gulf Region  3GB  30Days Single Use	t
1815	139	!RG-1.0GB-7D-PTJX062PT	!rg-ptjx062pt	1.0GB / 7 дней	1	7	2.3	Gulf Region 1GB  7Days Single Use	t
1816	139	!RG-10.0GB-30D-PCHZ59M2J	!rg-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1817	139	!RG-5.0GB-30D-P7GA02CZP	!rg-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1818	139	!RG-3.0GB-30D-PQB69VW8U	!rg-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1819	139	!RG-1.0GB-7D-PUSHF5X80	!rg-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1827	139	!RG-1.0GB-1D-PS6VQM34Q	!rg-ps6vqm34q	1.0GB / 1 дней	1	1	1	Singapore & Malaysia & Thailand 1GB/Day	t
1828	139	!RG-2.0GB-1D-PRPNZ697N	!rg-prpnz697n	2.0GB / 1 дней	2	1	2	Singapore & Malaysia & Thailand 2GB/Day	t
1829	139	!RG-1.0GB-7D-P4XU0X3CX	!rg-p4xu0x3cx	1.0GB / 7 дней	1	7	2.3	China mainland & Japan & South Korea 1GB 7Days	t
1830	139	!RG-3.0GB-15D-P9Q0XP8HU	!rg-p9q0xp8hu	3.0GB / 15 дней	3	15	5.7	China mainland & Japan & South Korea 3GB 15Days	t
1831	139	!RG-3.0GB-30D-P64BPV0PR	!rg-p64bpv0pr	3.0GB / 30 дней	3	30	5.9	China mainland & Japan & South Korea 3GB 30Days	t
1832	139	!RG-5.0GB-30D-P5KZF2WY6	!rg-p5kzf2wy6	5.0GB / 30 дней	5	30	8.8	China mainland & Japan & South Korea 5GB 30Days	t
1833	139	!RG-10.0GB-30D-P5JHQ39EE	!rg-p5jhq39ee	10.0GB / 30 дней	10	30	15.2	China mainland & Japan & South Korea 10GB 30Days	t
1834	139	!RG-20.0GB-30D-P93F7ZCSY	!rg-p93f7zcsy	20.0GB / 30 дней	20	30	25	China mainland & Japan & South Korea 20GB 30Days	t
1835	139	!RG-0.5GB-1D-PD4EBQ08R	!rg-pd4ebq08r	0.49GB / 1 дней	0.49	1	1.2	China mainland & Japan & South Korea 500MB/Day	t
1836	139	!RG-1.0GB-1D-P8SU7BG1W	!rg-p8su7bg1w	1.0GB / 1 дней	1	1	2.2	China mainland & Japan & South Korea 1GB/Day	t
1837	139	!RG-2.0GB-1D-P1Z74ZBVM	!rg-p1z74zbvm	2.0GB / 1 дней	2	1	4.3	China mainland & Japan & South Korea 2GB/Day	t
1838	140	AF-6.0GB-15D-AIS002	af-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1840	141	CKH525	al-ckh525	1.0GB / 7 дней	1	7	2.9	Albania 1GB 7Days	t
1841	141	CKH549	al-ckh549	5.0GB / 30 дней	5	30	11	Albania 5GB 30Days	t
1842	141	AL-1.0GB-7D-CKH823	al-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1843	141	AL-5.0GB-30D-CKH825	al-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
710	10	JC052	cn-jc052	1.0GB / 7 дней	1	7	0.7	China 1GB 7Days	t
711	10	JC053	cn-jc053	3.0GB / 15 дней	3	15	1.7	China 3GB 15Days	t
712	10	JC054	cn-jc054	5.0GB / 30 дней	5	30	2.7	China 5GB 30Days	t
713	10	JC055	cn-jc055	10.0GB / 30 дней	10	30	4.7	China 10GB 30Days	t
714	10	JC090	cn-jc090	20.0GB / 30 дней	20	30	8.2	China 20GB 30Days	t
715	10	CN-6.0GB-8D-AIS001	cn-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
716	10	CN-6.0GB-15D-AIS002	cn-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
717	10	CN-1.0GB-7D-CKH823	cn-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
718	10	CN-5.0GB-30D-CKH825	cn-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
719	10	CN-10.0GB-30D-CKH826	cn-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
720	10	JC172	cn-jc172	1.0GB / 7 дней	1	7	1.5	China (mainland HK Macao) 1GB 7Days	t
1844	141	AL-10.0GB-30D-CKH826	al-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1845	141	PL5JS8GQQ	al-pl5js8gqq	3.0GB / 30 дней	3	30	7.3	Albania 3GB 30Days	t
1846	141	AL-3.0GB-30D-PHD8GZ2VN	al-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1847	141	AL-20.0GB-90D-PG3K0LHBC	al-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1848	141	AL-1.0GB-365D-PCQXBW5UJ	al-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1849	141	AL-1.0GB-7D-PHS30M6EZ	al-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1867	142	PWI9OQIY7	dz-pwi9oqiy7	3.0GB / 30 дней	3	30	3		t
959	12	PX18HJ4XW	br-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
960	12	P8JCL47FC	br-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
961	12	PX2WSA7L1	br-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
962	12	PUQ2TP57A	br-puq2tp57a	5.0GB / 1 дней	5	1	8.7	Brazil 5GB/Day	t
963	12	PT5G8VBW7	br-pt5g8vbw7	1.0GB / 1 дней	1	1	2.2	Brazil 1GB/Day	t
964	12	P74QTP3AR	br-p74qtp3ar	0.49GB / 1 дней	0.49	1	1.1	Brazil 500MB/Day	t
965	12	PCHZ59M2J	br-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
966	12	P7GA02CZP	br-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
968	12	PUSHF5X80	br-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
969	12	P2QDY5WD1	br-p2qdy5wd1	10.0GB / 30 дней	10	30	22.8	Brazil 10GB 30Days Single Use	t
970	12	PVYS147BB	br-pvys147bb	5.0GB / 30 дней	5	30	12.5	Brazil 5GB 30Days Single Use	t
971	12	P4J9BRTA3	br-p4j9brta3	3.0GB / 30 дней	3	30	7.5	Brazil 3GB 30Days Single Use	t
972	12	P7QUD52XF	br-p7qud52xf	1.0GB / 7 дней	1	7	2.8	Brazil 1GB 7Days Single Use	t
2094	155	CKH298	bo-ckh298	3.0GB / 15 дней	3	15	16.8	Bolivia 3GB 15Days	t
2095	155	BO-1.0GB-7D-CKH487	bo-ckh487	1.0GB / 7 дней	1	7	5.7	South America 1GB 7Days	t
2096	155	BO-3.0GB-15D-CKH488	bo-ckh488	3.0GB / 15 дней	3	15	14.1	South America 3GB 15Days	t
2097	155	BO-5.0GB-30D-CKH489	bo-ckh489	5.0GB / 30 дней	5	30	21	South America 5GB 30Days	t
2098	155	BO-10.0GB-30D-CKH490	bo-ckh490	10.0GB / 30 дней	10	30	37	South America 10GB 30Days	t
2099	155	BO-6.0GB-15D-AIS002	bo-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
2100	155	BO-1.0GB-7D-CKH823	bo-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
2101	155	BO-5.0GB-30D-CKH825	bo-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
2102	155	BO-10.0GB-30D-CKH826	bo-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
2103	155	CKH831	bo-ckh831	20.0GB / 30 дней	20	30	99	Bolivia 20GB 30Days	t
2104	155	BO-3.0GB-30D-P6FNJUAP4	bo-p6fnjuap4	3.0GB / 30 дней	3	30	14.4	South America 3GB 30Days	t
2105	155	BO-3.0GB-30D-PHD8GZ2VN	bo-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
2106	155	BO-20.0GB-90D-PG3K0LHBC	bo-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
2107	155	BO-1.0GB-365D-PCQXBW5UJ	bo-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
2108	155	BO-1.0GB-7D-PHS30M6EZ	bo-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
2109	155	BO-1.0GB-365D-PYMC5N31Z	bo-pymc5n31z	1.0GB / 365 дней	1	365	19		t
2110	155	BO-5.0GB-30D-PEW54FVD9	bo-pew54fvd9	5.0GB / 30 дней	5	30	26		t
2111	155	BO-3.0GB-30D-PW6P3DX2G	bo-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
2112	155	BO-20.0GB-90D-PB83STJL6	bo-pb83stjl6	20.0GB / 90 дней	20	90	95		t
2113	155	BO-20.0GB-30D-PR3JZMC20	bo-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
2114	155	BO-10.0GB-30D-P34FHRF8J	bo-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
2115	155	BO-5.0GB-1D-PX18HJ4XW	bo-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
2116	155	BO-1.0GB-1D-P8JCL47FC	bo-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
2117	155	BO-0.5GB-1D-PX2WSA7L1	bo-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
384	4	FR-3.0GB-30D-CKH006	fr-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
385	4	FR-5.0GB-30D-CKH007	fr-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
386	4	CKH977	fr-ckh977	3.0GB / 30 дней	3	30	2.3	France 3GB 30Days	t
387	4	CKH983	fr-ckh983	5.0GB / 30 дней	5	30	3.4	France 5GB 30Days	t
388	4	CKH990	fr-ckh990	1.0GB / 7 дней	1	7	0.9	France 1GB 7Days	t
389	4	CKH991	fr-ckh991	3.0GB / 15 дней	3	15	2.2	France 3GB 15Days	t
390	4	CKH992	fr-ckh992	10.0GB / 30 дней	10	30	6.1	France 10GB 30Days	t
391	4	FR-1.0GB-7D-CKH484	fr-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
392	4	FR-10.0GB-30D-CKH486	fr-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
338	3	DE-3.0GB-30D-CKH006	de-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
339	3	DE-5.0GB-30D-CKH007	de-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
340	3	CKH978	de-ckh978	3.0GB / 30 дней	3	30	2.3	Germany 3GB 30Days	t
341	3	CKH984	de-ckh984	5.0GB / 30 дней	5	30	3.4	Germany 5GB 30Days	t
342	3	CKH993	de-ckh993	1.0GB / 7 дней	1	7	0.9	Germany 1GB 7Days	t
2118	155	BO-10.0GB-30D-PCHZ59M2J	bo-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
436	5	CKH229	it-ckh229	10.0GB / 30 дней	10	30	6.1	Italy 10GB 30Days	t
437	5	IT-1.0GB-7D-CKH484	it-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
438	5	IT-10.0GB-30D-CKH486	it-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
439	5	IT-20.0GB-30D-CKH500	it-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
440	5	IT-6.0GB-15D-AIS002	it-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
441	5	CKH504	it-ckh504	20.0GB / 30 дней	20	30	10.6	Italy 20GB 30Days	t
442	5	IT-1.0GB-7D-CKH823	it-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
443	5	IT-5.0GB-30D-CKH825	it-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
444	5	IT-10.0GB-30D-CKH826	it-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1911	146	CKH030	am-ckh030	3.0GB / 30 дней	3	30	14.4	Armenia 3GB 30Days	t
1912	146	AM-6.0GB-15D-AIS002	am-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1913	146	CKH514	am-ckh514	1.0GB / 7 дней	1	7	5.7	Armenia 1GB 7Days	t
1914	146	CKH555	am-ckh555	3.0GB / 15 дней	3	15	14.1	Armenia 3GB 15Days	t
1915	146	CKH776	am-ckh776	20.0GB / 30 дней	20	30	0.01	Armenia 20GB 30Days	t
1916	146	AM-1.0GB-7D-CKH823	am-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1917	146	AM-5.0GB-30D-CKH825	am-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1918	146	AM-10.0GB-30D-CKH826	am-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1919	146	AM-1.0GB-7D-CKH848	am-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
1920	146	AM-5.0GB-30D-CKH850	am-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
1921	146	AM-3.0GB-30D-PHD8GZ2VN	am-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1922	146	AM-20.0GB-90D-PG3K0LHBC	am-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1923	146	AM-3.0GB-30D-PNEKXVZKV	am-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
1924	146	AM-1.0GB-365D-PCQXBW5UJ	am-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1925	146	AM-1.0GB-7D-PHS30M6EZ	am-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1926	146	AM-1.0GB-365D-PYMC5N31Z	am-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1927	146	AM-5.0GB-30D-PEW54FVD9	am-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1928	146	AM-3.0GB-30D-PW6P3DX2G	am-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1929	146	AM-20.0GB-90D-PB83STJL6	am-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1930	146	AM-20.0GB-30D-PR3JZMC20	am-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1931	146	AM-10.0GB-30D-P34FHRF8J	am-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1046	13	JC060	in-jc060	1.0GB / 7 дней	1	7	2.9	India 1GB 7Days	t
1047	13	JC061	in-jc061	3.0GB / 15 дней	3	15	7.2	India 3GB 15Days	t
1048	13	JC062	in-jc062	5.0GB / 30 дней	5	30	11	India 5GB 30Days	t
1049	13	IN-6.0GB-8D-AIS001	in-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
1050	13	IN-6.0GB-15D-AIS002	in-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1051	13	JC140	in-jc140	10.0GB / 30 дней	10	30	19	India 10GB 30Days	t
1052	13	JC141	in-jc141	20.0GB / 30 дней	20	30	32	India 20GB 30Days	t
1053	13	IN-1.0GB-7D-CKH823	in-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1054	13	IN-5.0GB-30D-CKH825	in-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1055	13	IN-10.0GB-30D-CKH826	in-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1056	13	IN-1.0GB-30D-JC177	in-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
1057	13	IN-5.0GB-30D-JC178	in-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
1058	13	IN-3.0GB-15D-JC179	in-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
1059	13	IN-10.0GB-30D-JC180	in-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
1060	13	IN-20.0GB-90D-JC181	in-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
1061	13	IN-50.0GB-180D-JC182	in-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
1062	13	IN-1.0GB-7D-JC183	in-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
1063	13	IN-3.0GB-30D-PHD8GZ2VN	in-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1064	13	IN-20.0GB-90D-PG3K0LHBC	in-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1065	13	IN-1.0GB-365D-PCQXBW5UJ	in-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1066	13	PGS3HB984	in-pgs3hb984	0.49GB / 1 дней	0.49	1	1.2	India 500MB/Day	t
820	8	JC018	au-jc018	1.0GB / 7 дней	1	7	0.7	Australia 1GB 7Days	t
821	8	JC019	au-jc019	3.0GB / 15 дней	3	15	1.7	Australia 3GB 15Days	t
822	8	JC020	au-jc020	5.0GB / 30 дней	5	30	2.7	Australia 5GB 30Days	t
823	8	AU-6.0GB-8D-AIS001	au-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
824	8	AU-6.0GB-15D-AIS002	au-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
825	8	JC101	au-jc101	10.0GB / 30 дней	10	30	4.7	Australia 10GB 30Days	t
826	8	JC102	au-jc102	20.0GB / 30 дней	20	30	8.2	Australia 20GB 30Days	t
827	8	AU-1.0GB-7D-CKH823	au-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
828	8	AU-5.0GB-30D-CKH825	au-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3428	216	PD97RF0HS	kr-pd97rf0hs	2.0GB / 1 дней	2	1	1.6	South Korea 2GB/Day	t
3429	216	P8Z0SR4YM	kr-p8z0sr4ym	3.0GB / 1 дней	3	1	2.4	South Korea 3GB/Day	t
3430	216	PX9TSB16T	kr-px9tsb16t	5.0GB / 1 дней	5	1	3.9		t
3431	216	P2XI9YHJG	kr-p2xi9yhjg	10.0GB / 1 дней	10	1	8		t
3432	216	KR-1.0GB-7D-P4XU0X3CX	kr-p4xu0x3cx	1.0GB / 7 дней	1	7	2.3	China mainland & Japan & South Korea 1GB 7Days	t
3433	216	KR-3.0GB-15D-P9Q0XP8HU	kr-p9q0xp8hu	3.0GB / 15 дней	3	15	5.7	China mainland & Japan & South Korea 3GB 15Days	t
3434	216	KR-3.0GB-30D-P64BPV0PR	kr-p64bpv0pr	3.0GB / 30 дней	3	30	5.9	China mainland & Japan & South Korea 3GB 30Days	t
3435	216	KR-5.0GB-30D-P5KZF2WY6	kr-p5kzf2wy6	5.0GB / 30 дней	5	30	8.8	China mainland & Japan & South Korea 5GB 30Days	t
3436	216	KR-10.0GB-30D-P5JHQ39EE	kr-p5jhq39ee	10.0GB / 30 дней	10	30	15.2	China mainland & Japan & South Korea 10GB 30Days	t
3437	216	KR-20.0GB-30D-P93F7ZCSY	kr-p93f7zcsy	20.0GB / 30 дней	20	30	25	China mainland & Japan & South Korea 20GB 30Days	t
3438	216	KR-0.5GB-1D-PD4EBQ08R	kr-pd4ebq08r	0.49GB / 1 дней	0.49	1	1.2	China mainland & Japan & South Korea 500MB/Day	t
3439	216	KR-1.0GB-1D-P8SU7BG1W	kr-p8su7bg1w	1.0GB / 1 дней	1	1	2.2	China mainland & Japan & South Korea 1GB/Day	t
3440	216	KR-2.0GB-1D-P1Z74ZBVM	kr-p1z74zbvm	2.0GB / 1 дней	2	1	4.3	China mainland & Japan & South Korea 2GB/Day	t
3441	217	CKH027	kw-ckh027	3.0GB / 30 дней	3	30	5.9	Kuwait 3GB 30Days	t
3442	217	KW-6.0GB-8D-AIS001	kw-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3443	217	KW-6.0GB-15D-AIS002	kw-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3444	217	CKH512	kw-ckh512	1.0GB / 7 дней	1	7	2.3	Kuwait 1GB 7Days	t
3445	217	CKH628	kw-ckh628	3.0GB / 15 дней	3	15	5.7	Kuwait 3GB 15Days	t
3446	217	CKH629	kw-ckh629	5.0GB / 30 дней	5	30	8.8	Kuwait 5GB 30Days	t
3447	217	CKH748	kw-ckh748	20.0GB / 30 дней	20	30	25	Kuwait 20GB 30Days	t
3448	217	KW-1.0GB-7D-CKH823	kw-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3449	217	KW-5.0GB-30D-CKH825	kw-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3450	217	KW-10.0GB-30D-CKH826	kw-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3451	217	KW-1.0GB-7D-CKH848	kw-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
3452	217	KW-5.0GB-30D-CKH850	kw-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
3453	217	KW-1.0GB-30D-JC177	kw-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
3454	217	KW-5.0GB-30D-JC178	kw-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
3455	217	KW-3.0GB-15D-JC179	kw-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
3456	217	KW-10.0GB-30D-JC180	kw-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
3457	217	KW-20.0GB-90D-JC181	kw-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
673	9	JP-5.0GB-30D-JC178	jp-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
674	9	JP-3.0GB-15D-JC179	jp-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
675	9	JP-10.0GB-30D-JC180	jp-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
676	9	JP-20.0GB-90D-JC181	jp-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
677	9	JP-50.0GB-180D-JC182	jp-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
678	9	JP-1.0GB-7D-JC183	jp-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
679	9	JP-3.0GB-30D-PHD8GZ2VN	jp-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
680	9	JP-20.0GB-90D-PG3K0LHBC	jp-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
681	9	PL4E7JOWX	jp-pl4e7jowx	50.0GB / 180 дней	50	180	28	Japan 50GB 180Days	t
682	9	JP-1.0GB-365D-PCQXBW5UJ	jp-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
683	9	P9JS074W4	jp-p9js074w4	0.49GB / 1 дней	0.49	1	0.5	Japan 500MB/Day	t
684	9	P9TF1FXDA	jp-p9tf1fxda	1.0GB / 1 дней	1	1	1	Japan 1GB/Day	t
685	9	PPWBVT0BF	jp-ppwbvt0bf	2.0GB / 1 дней	2	1	2	Japan 2GB/Day	t
686	9	P2AJZD4YX	jp-p2ajzd4yx	3.0GB / 30 дней	3	30	1.8	Japan 3GB 30Days	t
687	9	JP-1.0GB-7D-PHS30M6EZ	jp-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
688	9	JP-1.0GB-365D-PYMC5N31Z	jp-pymc5n31z	1.0GB / 365 дней	1	365	19		t
689	9	JP-5.0GB-30D-PEW54FVD9	jp-pew54fvd9	5.0GB / 30 дней	5	30	26		t
690	9	JP-3.0GB-30D-PW6P3DX2G	jp-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
691	9	JP-20.0GB-90D-PB83STJL6	jp-pb83stjl6	20.0GB / 90 дней	20	90	95		t
692	9	JP-20.0GB-30D-PR3JZMC20	jp-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
693	9	JP-10.0GB-30D-P34FHRF8J	jp-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
694	9	JP-0.5GB-1D-PACK04L3R	jp-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
695	9	JP-1.0GB-1D-PXJ8HG40S	jp-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
696	9	JP-2.0GB-1D-PVBKS19B4	jp-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
697	9	JP-3.0GB-1D-PM5T3Z4UM	jp-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
698	9	P0GTZA81N	jp-p0gtza81n	3.0GB / 1 дней	3	1	2.2	Japan 3GB/Day	t
699	9	PFFM6ED75	jp-pffm6ed75	5.0GB / 1 дней	5	1	4.4		t
700	9	PGURVYHQ1	jp-pgurvyhq1	10.0GB / 1 дней	10	1	7.3		t
3458	217	KW-50.0GB-180D-JC182	kw-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
3459	217	KW-1.0GB-7D-JC183	kw-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
3460	217	KW-3.0GB-30D-PHD8GZ2VN	kw-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3461	217	KW-20.0GB-90D-PG3K0LHBC	kw-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3462	217	KW-3.0GB-30D-PNEKXVZKV	kw-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
3463	217	KW-1.0GB-365D-PCQXBW5UJ	kw-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3464	217	KW-1.0GB-7D-PHS30M6EZ	kw-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3465	217	KW-1.0GB-365D-PYMC5N31Z	kw-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3466	217	KW-5.0GB-30D-PEW54FVD9	kw-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3467	217	KW-3.0GB-30D-PW6P3DX2G	kw-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3468	217	KW-20.0GB-90D-PB83STJL6	kw-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3469	217	KW-20.0GB-30D-PR3JZMC20	kw-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1078	264	CKH423	re-ckh423	5.0GB / 30 дней	5	30	11	Reunion 5GB 30Days	t
1079	264	RE-1.0GB-7D-CKH495	re-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1080	264	RE-5.0GB-30D-CKH497	re-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1081	264	RE-6.0GB-15D-AIS002	re-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1082	264	RE-1.0GB-7D-CKH823	re-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1083	264	RE-5.0GB-30D-CKH825	re-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1084	264	RE-10.0GB-30D-CKH826	re-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1085	264	RE-3.0GB-30D-P1XXDOD0C	re-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1086	264	RE-3.0GB-30D-PHD8GZ2VN	re-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1087	264	RE-20.0GB-90D-PG3K0LHBC	re-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1130	270	SA-10.0GB-30D-CKH826	sa-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1131	270	SA-1.0GB-7D-CKH848	sa-ckh848	1.0GB / 7 дней	1	7	7	Middle East 1GB 7Days	t
1132	270	SA-5.0GB-30D-CKH850	sa-ckh850	5.0GB / 30 дней	5	30	26	Middle East 5GB 30Days	t
1133	270	SA-1.0GB-30D-JC177	sa-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
1134	270	SA-5.0GB-30D-JC178	sa-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
1135	270	SA-3.0GB-15D-JC179	sa-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
1136	270	SA-10.0GB-30D-JC180	sa-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
1137	270	SA-20.0GB-90D-JC181	sa-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
1138	270	SA-50.0GB-180D-JC182	sa-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
1139	270	SA-1.0GB-7D-JC183	sa-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
1140	270	SA-3.0GB-30D-PHD8GZ2VN	sa-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1141	270	SA-20.0GB-90D-PG3K0LHBC	sa-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1142	270	SA-3.0GB-30D-PNEKXVZKV	sa-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
1143	270	SA-1.0GB-365D-PCQXBW5UJ	sa-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1144	270	SA-1.0GB-7D-PHS30M6EZ	sa-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1190	272	RS-5.0GB-30D-CKH825	rs-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1191	272	RS-10.0GB-30D-CKH826	rs-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1192	272	RS-20.0GB-90D-P7VCE7FKY	rs-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1193	272	RS-50.0GB-180D-PGXJN6W2T	rs-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3479	218	KG-6.0GB-15D-AIS002	kg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3480	218	CKH755	kg-ckh755	1.0GB / 7 дней	1	7	2.3	Kyrgyzstan 1GB 7Days	t
3481	218	CKH756	kg-ckh756	3.0GB / 15 дней	3	15	5.9	Kyrgyzstan 3GB 15Days	t
3482	218	CKH759	kg-ckh759	20.0GB / 30 дней	20	30	39	Kyrgyzstan 20GB 30Days	t
3483	218	KG-1.0GB-7D-CKH823	kg-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3484	218	KG-5.0GB-30D-CKH825	kg-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3485	218	KG-10.0GB-30D-CKH826	kg-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3486	218	KG-3.0GB-30D-PHD8GZ2VN	kg-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3487	218	KG-20.0GB-90D-PG3K0LHBC	kg-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3511	220	LV-20.0GB-30D-CKH500	lv-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
3512	220	LV-6.0GB-15D-AIS002	lv-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3513	220	CKH702	lv-ckh702	20.0GB / 30 дней	20	30	10.6	Latvia 20GB 30Days	t
3514	220	LV-1.0GB-7D-CKH823	lv-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3515	220	LV-5.0GB-30D-CKH825	lv-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3516	220	LV-10.0GB-30D-CKH826	lv-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3517	220	LV-20.0GB-90D-P7VCE7FKY	lv-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3518	220	LV-50.0GB-180D-PGXJN6W2T	lv-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3519	220	PUS1LIQUY	lv-pus1liquy	50.0GB / 180 дней	50	180	30	Latvia 50GB 180Days	t
3520	220	LV-3.0GB-30D-PHD8GZ2VN	lv-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3521	220	LV-20.0GB-90D-PG3K0LHBC	lv-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3530	220	LV-50.0GB-180D-PE70MYRZ5	lv-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
3531	220	LV-1.0GB-1D-PUDV52A3R	lv-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3532	220	LV-1.5GB-1D-P34CJYA6C	lv-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3533	220	LV-1.0GB-7D-PHS30M6EZ	lv-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3534	220	LV-1.0GB-365D-PYMC5N31Z	lv-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3535	220	LV-5.0GB-30D-PEW54FVD9	lv-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3536	220	LV-3.0GB-30D-PW6P3DX2G	lv-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3537	220	LV-20.0GB-90D-PB83STJL6	lv-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3538	220	LV-20.0GB-30D-PR3JZMC20	lv-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3539	220	LV-10.0GB-30D-P34FHRF8J	lv-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3540	220	LV-2.0GB-1D-PZ6R8ASH9	lv-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
3541	220	LV-3.0GB-1D-PE01DJZS7	lv-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3542	220	LV-0.5GB-1D-P61RQP7ZW	lv-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
3543	220	LV-0.3GB-1D-P82Y6VYRL	lv-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
3544	221	CKH380	lr-ckh380	1.0GB / 7 дней	1	7	5.7	Liberia 1GB 7Days	t
3545	221	CKH409	lr-ckh409	3.0GB / 15 дней	3	15	14.1	Liberia 3GB 15Days	t
3546	221	CKH438	lr-ckh438	5.0GB / 30 дней	5	30	21	Liberia 5GB 30Days	t
3547	221	LR-1.0GB-7D-CKH495	lr-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
3548	221	LR-5.0GB-30D-CKH497	lr-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
3549	221	LR-1.0GB-7D-CKH823	lr-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3550	221	LR-5.0GB-30D-CKH825	lr-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3551	221	LR-10.0GB-30D-CKH826	lr-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1217	273	SC-1.0GB-7D-PHS30M6EZ	sc-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1218	273	SC-1.0GB-365D-PYMC5N31Z	sc-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1219	273	SC-5.0GB-30D-PEW54FVD9	sc-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1220	273	SC-3.0GB-30D-PW6P3DX2G	sc-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1221	273	SC-20.0GB-90D-PB83STJL6	sc-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1222	273	SC-20.0GB-30D-PR3JZMC20	sc-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1223	273	SC-10.0GB-30D-P34FHRF8J	sc-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
778	274	SG-10.0GB-30D-JC168	sg-jc168	10.0GB / 30 дней	10	30	12.2	Asia (7 areas) 10GB 30Days	t
779	274	SG-20.0GB-30D-JC169	sg-jc169	20.0GB / 30 дней	20	30	20	Asia (7 areas) 20GB 30Days	t
780	274	SG-1.0GB-30D-JC177	sg-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
781	274	SG-5.0GB-30D-JC178	sg-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
782	274	SG-3.0GB-15D-JC179	sg-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
783	274	SG-10.0GB-30D-JC180	sg-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
784	274	SG-20.0GB-90D-JC181	sg-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
785	274	SG-50.0GB-180D-JC182	sg-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
786	274	SG-1.0GB-7D-JC183	sg-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
3552	221	LR-3.0GB-30D-P1XXDOD0C	lr-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
3553	221	LR-3.0GB-30D-PHD8GZ2VN	lr-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3554	221	LR-20.0GB-90D-PG3K0LHBC	lr-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3555	221	LR-1.0GB-365D-PCQXBW5UJ	lr-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3556	221	LR-1.0GB-7D-PHS30M6EZ	lr-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3557	221	LR-1.0GB-365D-PYMC5N31Z	lr-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3558	221	LR-5.0GB-30D-PEW54FVD9	lr-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3559	221	LR-3.0GB-30D-PW6P3DX2G	lr-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3579	222	LI-1.0GB-365D-PCQXBW5UJ	li-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3592	222	LI-5.0GB-30D-PEW54FVD9	li-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3593	222	LI-3.0GB-30D-PW6P3DX2G	li-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3594	222	LI-20.0GB-90D-PB83STJL6	li-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3595	222	LI-20.0GB-30D-PR3JZMC20	li-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3596	222	LI-10.0GB-30D-P34FHRF8J	li-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3597	222	LI-2.0GB-1D-PZ6R8ASH9	li-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
3598	222	LI-3.0GB-1D-PE01DJZS7	li-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3599	222	LI-0.5GB-1D-P61RQP7ZW	li-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
3600	222	LI-0.3GB-1D-P82Y6VYRL	li-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
3601	223	LT-3.0GB-30D-CKH006	lt-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3602	223	LT-5.0GB-30D-CKH007	lt-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3603	223	CKH093	lt-ckh093	3.0GB / 30 дней	3	30	2.3	Lithuania 3GB 30Days	t
3604	223	CKH132	lt-ckh132	5.0GB / 30 дней	5	30	3.4	Lithuania 5GB 30Days	t
3605	223	CKH184	lt-ckh184	1.0GB / 7 дней	1	7	0.9	Lithuania 1GB 7Days	t
3606	223	CKH185	lt-ckh185	3.0GB / 15 дней	3	15	2.2	Lithuania 3GB 15Days	t
3607	223	CKH186	lt-ckh186	10.0GB / 30 дней	10	30	9.9	Lithuania 10GB 30Days	t
3608	223	LT-1.0GB-7D-CKH484	lt-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3609	223	LT-10.0GB-30D-CKH486	lt-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1243	275	SK-20.0GB-90D-PG3K0LHBC	sk-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1283	276	PCMQJGTVB	si-pcmqjgtvb	50.0GB / 180 дней	50	180	30	Slovenia 50GB 180Days	t
1284	276	SI-3.0GB-30D-PHD8GZ2VN	si-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1285	276	SI-20.0GB-90D-PG3K0LHBC	si-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1286	276	SI-1.0GB-365D-PCQXBW5UJ	si-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1287	276	SI-1.0GB-30D-PM1HX6ES9	si-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
1288	276	SI-3.0GB-30D-PJK6T8JT2	si-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
1289	276	SI-5.0GB-30D-P87F6RTKY	si-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
1290	276	SI-1.0GB-7D-PV048NCRG	si-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
1291	276	SI-10.0GB-30D-P50GVS8GN	si-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
1292	276	SI-20.0GB-30D-PHC4X21NC	si-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
1293	276	SI-20.0GB-90D-P5NWWU08G	si-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
1294	276	SI-50.0GB-180D-PE70MYRZ5	si-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
1295	276	SI-1.0GB-1D-PUDV52A3R	si-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
1296	276	SI-1.5GB-1D-P34CJYA6C	si-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
1297	276	SI-1.0GB-7D-PHS30M6EZ	si-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1298	276	SI-1.0GB-365D-PYMC5N31Z	si-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1299	276	SI-5.0GB-30D-PEW54FVD9	si-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1300	276	SI-3.0GB-30D-PW6P3DX2G	si-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1301	276	SI-20.0GB-90D-PB83STJL6	si-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1302	276	SI-20.0GB-30D-PR3JZMC20	si-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1303	276	SI-10.0GB-30D-P34FHRF8J	si-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1304	276	SI-2.0GB-1D-PZ6R8ASH9	si-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
999	278	MB026	za-mb026	1.0GB / 7 дней	1	7	3.6	South Africa 1GB 7Days	t
1000	278	MB036	za-mb036	5.0GB / 30 дней	5	30	13.6	South Africa 5GB 30Days	t
1001	278	MB041	za-mb041	10.0GB / 30 дней	10	30	23	South Africa 10GB 30Days	t
1002	278	ZA-1.0GB-7D-CKH495	za-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
1003	278	ZA-5.0GB-30D-CKH497	za-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1004	278	ZA-6.0GB-15D-AIS002	za-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1005	278	ZA-1.0GB-7D-CKH823	za-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1006	278	ZA-5.0GB-30D-CKH825	za-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1007	278	ZA-10.0GB-30D-CKH826	za-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3610	223	LT-20.0GB-30D-CKH500	lt-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
3611	223	LT-6.0GB-15D-AIS002	lt-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3612	223	CKH704	lt-ckh704	20.0GB / 30 дней	20	30	16.8	Lithuania 20GB 30Days	t
3613	223	LT-1.0GB-7D-CKH823	lt-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3614	223	LT-5.0GB-30D-CKH825	lt-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3615	223	LT-10.0GB-30D-CKH826	lt-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3636	223	LT-20.0GB-90D-PB83STJL6	lt-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3637	223	LT-20.0GB-30D-PR3JZMC20	lt-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3638	223	LT-10.0GB-30D-P34FHRF8J	lt-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3639	223	LT-2.0GB-1D-PZ6R8ASH9	lt-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
3640	223	LT-3.0GB-1D-PE01DJZS7	lt-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3641	223	LT-0.5GB-1D-P61RQP7ZW	lt-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
3642	223	LT-0.3GB-1D-P82Y6VYRL	lt-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
3654	224	CKH716	lu-ckh716	20.0GB / 30 дней	20	30	10.6	Luxembourg 20GB 30Days	t
3655	224	LU-1.0GB-7D-CKH823	lu-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3656	224	LU-5.0GB-30D-CKH825	lu-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3657	224	LU-10.0GB-30D-CKH826	lu-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3658	224	LU-20.0GB-90D-P7VCE7FKY	lu-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3659	224	LU-50.0GB-180D-PGXJN6W2T	lu-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3660	224	PQIWDILIV	lu-pqiwdiliv	50.0GB / 180 дней	50	180	30	Luxembourg 50GB 180Days	t
3661	224	LU-3.0GB-30D-PHD8GZ2VN	lu-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3662	224	LU-20.0GB-90D-PG3K0LHBC	lu-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3663	224	LU-1.0GB-365D-PCQXBW5UJ	lu-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3664	224	LU-1.0GB-30D-PM1HX6ES9	lu-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
3665	224	LU-3.0GB-30D-PJK6T8JT2	lu-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
3666	224	LU-5.0GB-30D-P87F6RTKY	lu-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
3667	224	LU-1.0GB-7D-PV048NCRG	lu-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
3668	224	LU-10.0GB-30D-P50GVS8GN	lu-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
3669	224	LU-20.0GB-30D-PHC4X21NC	lu-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
3670	224	LU-20.0GB-90D-P5NWWU08G	lu-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
3671	224	LU-50.0GB-180D-PE70MYRZ5	lu-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
3672	224	LU-1.0GB-1D-PUDV52A3R	lu-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3673	224	LU-1.5GB-1D-P34CJYA6C	lu-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3674	224	LU-1.0GB-7D-PHS30M6EZ	lu-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3675	224	LU-1.0GB-365D-PYMC5N31Z	lu-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3676	224	LU-5.0GB-30D-PEW54FVD9	lu-pew54fvd9	5.0GB / 30 дней	5	30	26		t
484	6	ES-20.0GB-30D-CKH500	es-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
485	6	ES-6.0GB-15D-AIS002	es-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
486	6	CKH506	es-ckh506	10.0GB / 30 дней	10	30	6.1	Spain 10GB 30Days	t
487	6	CKH507	es-ckh507	20.0GB / 30 дней	20	30	10.6	Spain 20GB 30Days	t
488	6	ES-1.0GB-7D-CKH823	es-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1310	279	JC043	lk-jc043	3.0GB / 15 дней	3	15	4.8	Sri Lanka 3GB 15Days	t
1311	279	JC044	lk-jc044	5.0GB / 30 дней	5	30	7.7	Sri Lanka 5GB 30Days	t
1312	279	JC085	lk-jc085	10.0GB / 30 дней	10	30	15.4	Sri Lanka 10GB 30Days	t
1313	279	JC086	lk-jc086	20.0GB / 30 дней	20	30	28	Sri Lanka 20GB 30Days	t
1314	279	LK-6.0GB-8D-AIS001	lk-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
1315	279	LK-6.0GB-15D-AIS002	lk-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1316	279	LK-1.0GB-7D-CKH823	lk-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1317	279	LK-5.0GB-30D-CKH825	lk-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1318	279	LK-10.0GB-30D-CKH826	lk-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1319	279	LK-1.0GB-30D-JC177	lk-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
1320	279	LK-5.0GB-30D-JC178	lk-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
1321	279	LK-3.0GB-15D-JC179	lk-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
1322	279	LK-10.0GB-30D-JC180	lk-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
1323	279	LK-20.0GB-90D-JC181	lk-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
1324	279	LK-50.0GB-180D-JC182	lk-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
1325	279	LK-1.0GB-7D-JC183	lk-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
1326	279	LK-3.0GB-30D-PHD8GZ2VN	lk-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3677	224	LU-3.0GB-30D-PW6P3DX2G	lu-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3678	224	LU-20.0GB-90D-PB83STJL6	lu-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3679	224	LU-20.0GB-30D-PR3JZMC20	lu-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3680	224	LU-10.0GB-30D-P34FHRF8J	lu-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3681	224	LU-2.0GB-1D-PZ6R8ASH9	lu-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
3682	224	LU-3.0GB-1D-PE01DJZS7	lu-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3683	224	LU-0.5GB-1D-P61RQP7ZW	lu-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
3684	224	LU-0.3GB-1D-P82Y6VYRL	lu-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
3685	225	JC010	mo-jc010	3.0GB / 30 дней	3	30	1.8	Macao 3GB 30Days	t
3686	225	JC011	mo-jc011	5.0GB / 30 дней	5	30	2.7	Macao 5GB 30Days	t
3687	225	JC024	mo-jc024	1.0GB / 7 дней	1	7	0.7	Macao 1GB 7Days	t
3688	225	JC025	mo-jc025	3.0GB / 15 дней	3	15	1.7	Macao 3GB 15Days	t
3689	225	JC026	mo-jc026	10.0GB / 30 дней	10	30	4.7	Macao 10GB 30Days	t
3690	225	MO-6.0GB-8D-AIS001	mo-ais001	6.0GB / 8 дней	6	8	11	Asia-Pacific 6GB 8Days	t
3691	225	MO-6.0GB-15D-AIS002	mo-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3692	225	JC106	mo-jc106	20.0GB / 30 дней	20	30	8.2	Macao 20GB 30Days	t
3693	225	MO-1.0GB-7D-CKH823	mo-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3694	225	MO-5.0GB-30D-CKH825	mo-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3695	225	MO-10.0GB-30D-CKH826	mo-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3696	225	MO-1.0GB-7D-JC172	mo-jc172	1.0GB / 7 дней	1	7	1.5	China (mainland HK Macao) 1GB 7Days	t
3697	225	MO-3.0GB-15D-JC173	mo-jc173	3.0GB / 15 дней	3	15	3.7	China (mainland HK Macao) 3GB 15Days	t
3698	225	MO-5.0GB-30D-JC174	mo-jc174	5.0GB / 30 дней	5	30	5.7	China (mainland HK Macao) 5GB 30Days	t
3699	225	MO-10.0GB-30D-JC175	mo-jc175	10.0GB / 30 дней	10	30	9.9	China (mainland HK Macao) 10GB 30Days	t
3700	225	MO-20.0GB-30D-JC176	mo-jc176	20.0GB / 30 дней	20	30	16.8	China (mainland HK Macao) 20GB 30Days	t
3701	225	MO-1.0GB-30D-JC177	mo-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
3702	225	MO-5.0GB-30D-JC178	mo-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
3703	225	MO-3.0GB-15D-JC179	mo-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
3704	225	MO-10.0GB-30D-JC180	mo-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
3705	225	MO-20.0GB-90D-JC181	mo-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
3720	225	MO-0.5GB-1D-PACK04L3R	mo-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
3721	225	MO-1.0GB-1D-PXJ8HG40S	mo-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
3722	225	MO-2.0GB-1D-PVBKS19B4	mo-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
3723	225	MO-3.0GB-1D-PM5T3Z4UM	mo-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
3724	225	MO-0.5GB-1D-PN6QWT0Q4	mo-pn6qwt0q4	0.49GB / 1 дней	0.49	1	0.9	China (mainland HK Macao) 500MB/Day	t
1368	282	SE-10.0GB-30D-CKH486	se-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
1369	282	SE-20.0GB-30D-CKH500	se-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
1370	282	SE-6.0GB-15D-AIS002	se-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1371	282	CKH734	se-ckh734	20.0GB / 30 дней	20	30	10.6	Sweden 20GB 30Days	t
1372	282	SE-1.0GB-7D-CKH823	se-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1373	282	SE-5.0GB-30D-CKH825	se-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1374	282	SE-10.0GB-30D-CKH826	se-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1375	282	SE-20.0GB-90D-P7VCE7FKY	se-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
1376	282	SE-50.0GB-180D-PGXJN6W2T	se-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
1377	282	SE-3.0GB-30D-PHD8GZ2VN	se-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1378	282	SE-20.0GB-90D-PG3K0LHBC	se-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1379	282	SE-1.0GB-365D-PCQXBW5UJ	se-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1380	282	SE-1.0GB-30D-PM1HX6ES9	se-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
1381	282	SE-3.0GB-30D-PJK6T8JT2	se-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
1382	282	SE-5.0GB-30D-P87F6RTKY	se-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
1383	282	SE-1.0GB-7D-PV048NCRG	se-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
1384	282	SE-10.0GB-30D-P50GVS8GN	se-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
1426	283	CH-10.0GB-30D-P50GVS8GN	ch-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
1427	283	CH-20.0GB-30D-PHC4X21NC	ch-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
1428	283	CH-20.0GB-90D-P5NWWU08G	ch-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
1429	283	CH-50.0GB-180D-PE70MYRZ5	ch-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
1430	283	CH-1.0GB-1D-PUDV52A3R	ch-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
1431	283	CH-1.5GB-1D-P34CJYA6C	ch-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3725	225	MO-1.0GB-1D-P78RBUJQ4	mo-p78rbujq4	1.0GB / 1 дней	1	1	1.6	China (mainland HK Macao) 1GB/Day	t
3726	225	MO-2.0GB-1D-PY0WGY2C1	mo-py0wgy2c1	2.0GB / 1 дней	2	1	2.5	China (mainland HK Macao) 2GB/Day	t
3727	225	MO-3.0GB-1D-PB64TT7WN	mo-pb64tt7wn	3.0GB / 1 дней	3	1	3.8	China (mainland HK Macao) 3GB/Day	t
3728	226	CKH366	mg-ckh366	1.0GB / 7 дней	1	7	4.6	Madagascar 1GB 7Days	t
3729	226	CKH395	mg-ckh395	3.0GB / 15 дней	3	15	11.2	Madagascar 3GB 15Days	t
3730	226	MG-1.0GB-7D-CKH495	mg-ckh495	1.0GB / 7 дней	1	7	5.7	Africa 1GB 7Days	t
3731	226	MG-5.0GB-30D-CKH497	mg-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
3732	226	MG-6.0GB-15D-AIS002	mg-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3733	226	MG-1.0GB-7D-CKH823	mg-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3734	226	MG-5.0GB-30D-CKH825	mg-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3735	226	MG-10.0GB-30D-CKH826	mg-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3736	226	MG-3.0GB-30D-P1XXDOD0C	mg-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
3737	226	MG-3.0GB-30D-PHD8GZ2VN	mg-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3738	226	MG-20.0GB-90D-PG3K0LHBC	mg-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3739	226	MG-1.0GB-365D-PCQXBW5UJ	mg-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3740	226	MG-1.0GB-7D-PHS30M6EZ	mg-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3741	226	MG-1.0GB-365D-PYMC5N31Z	mg-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3742	226	MG-5.0GB-30D-PEW54FVD9	mg-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3743	226	MG-3.0GB-30D-PW6P3DX2G	mg-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3744	226	MG-20.0GB-90D-PB83STJL6	mg-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3745	226	MG-20.0GB-30D-PR3JZMC20	mg-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3746	226	MG-10.0GB-30D-P34FHRF8J	mg-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3766	228	JC027	my-jc027	1.0GB / 7 дней	1	7	0.7	Malaysia 1GB 7Days	t
3773	228	MY-1.0GB-7D-CKH823	my-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3774	228	MY-5.0GB-30D-CKH825	my-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3775	228	MY-10.0GB-30D-CKH826	my-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3776	228	MY-1.0GB-7D-JC165	my-jc165	1.0GB / 7 дней	1	7	1.8	Asia (7 areas) 1GB 7Days	t
3777	228	MY-3.0GB-15D-JC166	my-jc166	3.0GB / 15 дней	3	15	4.6	Asia (7 areas) 3GB 15Days	t
3778	228	MY-5.0GB-30D-JC167	my-jc167	5.0GB / 30 дней	5	30	7	Asia (7 areas) 5GB 30Days	t
3779	228	MY-10.0GB-30D-JC168	my-jc168	10.0GB / 30 дней	10	30	12.2	Asia (7 areas) 10GB 30Days	t
3780	228	MY-20.0GB-30D-JC169	my-jc169	20.0GB / 30 дней	20	30	20	Asia (7 areas) 20GB 30Days	t
3781	228	MY-1.0GB-30D-JC177	my-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
3782	228	MY-5.0GB-30D-JC178	my-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
3783	228	MY-3.0GB-15D-JC179	my-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
3784	228	MY-10.0GB-30D-JC180	my-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
3785	228	MY-20.0GB-90D-JC181	my-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
3786	228	MY-50.0GB-180D-JC182	my-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
3787	228	MY-1.0GB-7D-JC183	my-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
3788	228	MY-3.0GB-30D-PHD8GZ2VN	my-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3789	228	MY-20.0GB-90D-PG3K0LHBC	my-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3790	228	PBAGTADCE	my-pbagtadce	50.0GB / 180 дней	50	180	28	Malaysia 50GB 180Days	t
3791	228	MY-50.0GB-180D-P4GNDNA36	my-p4gndna36	50.0GB / 180 дней	50	180	45	Asia (7 areas) 50GB 180Days	t
3792	228	MY-1.0GB-365D-PCQXBW5UJ	my-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3793	228	PAN6REMMI	my-pan6remmi	0.49GB / 1 дней	0.49	1	0.5	Malaysia 500MB/Day	t
3794	228	P4UTFE9WB	my-p4utfe9wb	1.0GB / 1 дней	1	1	0.9	Malaysia 1GB/Day	t
3795	228	POLZ7NLE0	my-polz7nle0	2.0GB / 1 дней	2	1	1.7	Malaysia 2GB/Day	t
1460	284	TW-2.0GB-1D-PVBKS19B4	tw-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
1461	284	TW-3.0GB-1D-PM5T3Z4UM	tw-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
1481	286	TZ-10.0GB-30D-P34FHRF8J	tz-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
607	15	JC013	th-jc013	3.0GB / 30 дней	3	30	1.8	Thailand 3GB 30Days	t
608	15	JC014	th-jc014	5.0GB / 30 дней	5	30	2.7	Thailand 5GB 30Days	t
609	15	JC045	th-jc045	1.0GB / 7 дней	1	7	0.7	Thailand 1GB 7Days	t
610	15	JC046	th-jc046	3.0GB / 15 дней	3	15	1.7	Thailand 3GB 15Days	t
611	15	JC047	th-jc047	10.0GB / 30 дней	10	30	4.7	Thailand 10GB 30Days	t
612	15	JC080	th-jc080	20.0GB / 30 дней	20	30	8.2	Thailand 20GB 30Days	t
613	15	TH-1.0GB-7D-CKH823	th-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
614	15	TH-5.0GB-30D-CKH825	th-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
615	15	TH-10.0GB-30D-CKH826	th-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
621	15	JC177	th-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
3796	228	MY-3.0GB-30D-PZ8NV3QK9	my-pz8nv3qk9	3.0GB / 30 дней	3	30	3	Singapore & Malaysia & Thailand 3GB 30Days	t
3797	228	MY-5.0GB-30D-PYX2W95MR	my-pyx2w95mr	5.0GB / 30 дней	5	30	4.4	Singapore & Malaysia & Thailand 5GB 30Days	t
3798	228	MY-10.0GB-30D-PY5TK3XX6	my-py5tk3xx6	10.0GB / 30 дней	10	30	7.6	Singapore & Malaysia & Thailand 10GB 30Days	t
3799	228	MY-20.0GB-30D-P9NV1LJN6	my-p9nv1ljn6	20.0GB / 30 дней	20	30	12.9	Singapore & Malaysia & Thailand 20GB 30Days	t
3800	228	MY-1.0GB-7D-PHS30M6EZ	my-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3801	228	MY-1.0GB-365D-PYMC5N31Z	my-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3802	228	MY-5.0GB-30D-PEW54FVD9	my-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3803	228	MY-3.0GB-30D-PW6P3DX2G	my-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3804	228	MY-20.0GB-90D-PB83STJL6	my-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3805	228	MY-20.0GB-30D-PR3JZMC20	my-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3806	228	MY-10.0GB-30D-P34FHRF8J	my-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3807	228	MY-0.5GB-1D-PACK04L3R	my-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
3808	228	MY-1.0GB-1D-PXJ8HG40S	my-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
3809	228	MY-2.0GB-1D-PVBKS19B4	my-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
3810	228	MY-3.0GB-1D-PM5T3Z4UM	my-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
3811	228	MY-1.0GB-1D-P0N8SUBG5	my-p0n8subg5	1.0GB / 1 дней	1	1	1.7	Asia (7 areas) 1GB/Day	t
3812	228	MY-0.5GB-1D-PX5NT8Z4K	my-px5nt8z4k	0.49GB / 1 дней	0.49	1	0.9	Asia (7 areas) 500MB/Day	t
3813	228	MY-2.0GB-1D-PBZUB2S60	my-pbzub2s60	2.0GB / 1 дней	2	1	3	Asia (7 areas) 2GB/Day	t
3814	228	MY-5.0GB-1D-PJ2W7KTJ4	my-pj2w7ktj4	5.0GB / 1 дней	5	1	6	Asia (7 areas) 5GB/Day	t
3815	228	MY-1.0GB-7D-P86Y3TMFZ	my-p86y3tmfz	1.0GB / 7 дней	1	7	1.1	Singapore & Malaysia & Thailand 1GB 7Days	t
3816	228	MY-3.0GB-15D-P71Q4REAB	my-p71q4reab	3.0GB / 15 дней	3	15	2.8	Singapore & Malaysia & Thailand 3GB 15Days	t
3817	228	MY-0.5GB-1D-PB9B7RVL0	my-pb9b7rvl0	0.49GB / 1 дней	0.49	1	0.6	Singapore & Malaysia & Thailand 500MB/Day	t
3818	228	MY-1.0GB-1D-PS6VQM34Q	my-ps6vqm34q	1.0GB / 1 дней	1	1	1	Singapore & Malaysia & Thailand 1GB/Day	t
1487	288	TN-5.0GB-30D-CKH497	tn-ckh497	5.0GB / 30 дней	5	30	21	Africa 5GB 30Days	t
1488	288	TN-6.0GB-15D-AIS002	tn-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
1489	288	TN-1.0GB-7D-CKH823	tn-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1490	288	TN-5.0GB-30D-CKH825	tn-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1491	288	TN-10.0GB-30D-CKH826	tn-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1492	288	TN-3.0GB-30D-P1XXDOD0C	tn-p1xxdod0c	3.0GB / 30 дней	3	30	14.4	Africa 3GB 30Days	t
1493	288	TN-3.0GB-30D-PHD8GZ2VN	tn-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1529	291	UG-10.0GB-30D-P34FHRF8J	ug-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1546	292	UA-3.0GB-30D-PHD8GZ2VN	ua-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1547	292	UA-20.0GB-90D-PG3K0LHBC	ua-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1548	292	UA-1.0GB-365D-PCQXBW5UJ	ua-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1549	292	UA-1.0GB-30D-PM1HX6ES9	ua-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
1550	292	UA-3.0GB-30D-PJK6T8JT2	ua-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
1551	292	UA-5.0GB-30D-P87F6RTKY	ua-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
1552	292	UA-1.0GB-7D-PV048NCRG	ua-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
1553	292	UA-10.0GB-30D-P50GVS8GN	ua-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
1554	292	UA-20.0GB-30D-PHC4X21NC	ua-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
1555	292	UA-20.0GB-90D-P5NWWU08G	ua-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
1556	292	UA-50.0GB-180D-PE70MYRZ5	ua-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
1557	292	UA-1.0GB-1D-PUDV52A3R	ua-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
1558	292	UA-1.5GB-1D-P34CJYA6C	ua-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
1559	292	UA-1.0GB-7D-PHS30M6EZ	ua-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1560	292	UA-1.0GB-365D-PYMC5N31Z	ua-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1561	292	UA-5.0GB-30D-PEW54FVD9	ua-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1562	292	UA-3.0GB-30D-PW6P3DX2G	ua-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
570	14	CKH031	ae-ckh031	3.0GB / 30 дней	3	30	5.27	United Arab Emirates 3GB 30Days	t
571	14	AE-6.0GB-15D-AIS002	ae-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
572	14	CKH527	ae-ckh527	1.0GB / 7 дней	1	7	2.2	United Arab Emirates 1GB 7Days	t
573	14	CKH692	ae-ckh692	3.0GB / 15 дней	3	15	5.27	United Arab Emirates 3GB 15Days	t
574	14	CKH693	ae-ckh693	5.0GB / 30 дней	5	30	8.39	United Arab Emirates 5GB 30Days	t
575	14	CKH694	ae-ckh694	10.0GB / 60 дней	10	60	14.98	United Arab Emirates 10GB 60Days	t
576	14	AE-1.0GB-7D-CKH823	ae-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3819	228	MY-2.0GB-1D-PRPNZ697N	my-prpnz697n	2.0GB / 1 дней	2	1	2	Singapore & Malaysia & Thailand 2GB/Day	t
3822	230	CKH410	ml-ckh410	3.0GB / 15 дней	3	15	17.6	Mali 3GB 15Days	t
3831	230	ML-1.0GB-365D-PCQXBW5UJ	ml-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3832	230	ML-1.0GB-7D-PHS30M6EZ	ml-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3833	230	ML-1.0GB-365D-PYMC5N31Z	ml-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3834	230	ML-5.0GB-30D-PEW54FVD9	ml-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3835	230	ML-3.0GB-30D-PW6P3DX2G	ml-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3836	230	ML-20.0GB-90D-PB83STJL6	ml-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3837	230	ML-20.0GB-30D-PR3JZMC20	ml-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3838	230	ML-10.0GB-30D-P34FHRF8J	ml-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3839	231	MT-3.0GB-30D-CKH006	mt-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
3840	231	MT-5.0GB-30D-CKH007	mt-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
3841	231	CKH095	mt-ckh095	3.0GB / 30 дней	3	30	3.8	Malta 3GB 30Days	t
3842	231	CKH134	mt-ckh134	5.0GB / 30 дней	5	30	5.7	Malta 5GB 30Days	t
3843	231	CKH187	mt-ckh187	1.0GB / 7 дней	1	7	1.5	Malta 1GB 7Days	t
3844	231	CKH188	mt-ckh188	3.0GB / 15 дней	3	15	3.7	Malta 3GB 15Days	t
3845	231	CKH189	mt-ckh189	10.0GB / 30 дней	10	30	9.9	Malta 10GB 30Days	t
3846	231	MT-1.0GB-7D-CKH484	mt-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3847	231	MT-10.0GB-30D-CKH486	mt-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
3848	231	MT-20.0GB-30D-CKH500	mt-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
3849	231	MT-6.0GB-15D-AIS002	mt-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3850	231	CKH706	mt-ckh706	20.0GB / 30 дней	20	30	16.8	Malta 20GB 30Days	t
3851	231	MT-1.0GB-7D-CKH823	mt-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3852	231	MT-5.0GB-30D-CKH825	mt-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
293	2	CKH006	gb-ckh006	3.0GB / 30 дней	3	30	7.3	Europe 3GB 30Days	t
294	2	CKH007	gb-ckh007	5.0GB / 30 дней	5	30	11	Europe 5GB 30Days	t
295	2	CKH104	gb-ckh104	3.0GB / 30 дней	3	30	2.3	United Kingdom 3GB 30Days	t
296	2	CKH143	gb-ckh143	5.0GB / 30 дней	5	30	3.4	United Kingdom 5GB 30Days	t
297	2	CKH253	gb-ckh253	1.0GB / 7 дней	1	7	0.9	United Kingdom 1GB 7Days	t
298	2	CKH254	gb-ckh254	3.0GB / 15 дней	3	15	2.2	United Kingdom 3GB 15Days	t
299	2	CKH255	gb-ckh255	10.0GB / 30 дней	10	30	6.1	United Kingdom 10GB 30Days	t
300	2	CKH484	gb-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
301	2	CKH486	gb-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
302	2	CKH500	gb-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
303	2	AIS002	gb-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
304	2	CKH509	gb-ckh509	20.0GB / 30 дней	20	30	10.6	United Kingdom 20GB 30Days	t
305	2	GB-1.0GB-7D-CKH823	gb-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
333	2	GB-10.0GB-30D-P34FHRF8J	gb-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
334	2	PZ6R8ASH9	gb-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
335	2	PE01DJZS7	gb-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
336	2	P61RQP7ZW	gb-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
337	2	P82Y6VYRL	gb-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
257	1	P1HAXMKHP	us-p1haxmkhp	20.0GB / 90 дней	20	90	10.8	United States 20GB 90Days	t
258	1	P3ICIKSE8	us-p3icikse8	50.0GB / 180 дней	50	180	35	United States 50GB 180Days	t
259	1	PCRKRUHIL	us-pcrkruhil	10.0GB / 30 дней	10	30	6.1	United States 10GB 30Days	t
260	1	PGDINBJBY	us-pgdinbjby	3.0GB / 15 дней	3	15	2.2	United States 3GB 15Days	t
261	1	PHAJHEAYP	us-phajheayp	1.0GB / 7 дней	1	7	0.9	United States 1GB 7Days	t
262	1	PKJNMJIIU	us-pkjnmjiiu	5.0GB / 30 дней	5	30	3.4	United States 5GB 30Days	t
263	1	PKY3WHPRZ	us-pky3whprz	3.0GB / 30 дней	3	30	2.3	United States 3GB 30Days	t
264	1	P5NHFJKUS	us-p5nhfjkus	1.0GB / 1 дней	1	1	1.3	United States 1GB/Day	t
265	1	P7KMNQCEM	us-p7kmnqcem	1.5GB / 1 дней	1.5	1	1.6	United States 1.5GB/Day	t
266	1	P2D1OQDLK	us-p2d1oqdlk	2.0GB / 1 дней	2	1	2.3	United States 2GB/Day	t
267	1	PCTEPKHJW	us-pctepkhjw	1.0GB / 1 дней	1	1	2.2	North America 1GB/Day	t
268	1	P5SQ1FXCQ	us-p5sq1fxcq	1.5GB / 1 дней	1.5	1	3.2	North America 1.5GB/Day	t
269	1	PWTRNZF6E	us-pwtrnzf6e	2.0GB / 1 дней	2	1	4.3	North America 2GB/Day	t
270	1	PWTE0W1Q4	us-pwte0w1q4	1.0GB / 30 дней	1	30	2.5	North America 1GB 30Days	t
271	1	PHS30M6EZ	us-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
272	1	PYMC5N31Z	us-pymc5n31z	1.0GB / 365 дней	1	365	19		t
273	1	PEW54FVD9	us-pew54fvd9	5.0GB / 30 дней	5	30	26		t
274	1	PW6P3DX2G	us-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3853	231	MT-10.0GB-30D-CKH826	mt-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3854	231	MT-20.0GB-90D-P7VCE7FKY	mt-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3862	231	MT-1.0GB-7D-PV048NCRG	mt-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
3863	231	MT-10.0GB-30D-P50GVS8GN	mt-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
3864	231	MT-20.0GB-30D-PHC4X21NC	mt-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
3865	231	MT-20.0GB-90D-P5NWWU08G	mt-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
3866	231	MT-50.0GB-180D-PE70MYRZ5	mt-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
3867	231	MT-1.0GB-1D-PUDV52A3R	mt-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3868	231	MT-1.5GB-1D-P34CJYA6C	mt-p34cjya6c	1.5GB / 1 дней	1.5	1	2.2	Europe(30+ areas) 1.5GB/Day	t
3870	231	MT-1.0GB-365D-PYMC5N31Z	mt-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3871	231	MT-5.0GB-30D-PEW54FVD9	mt-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3872	231	MT-3.0GB-30D-PW6P3DX2G	mt-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3873	231	MT-20.0GB-90D-PB83STJL6	mt-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3874	231	MT-20.0GB-30D-PR3JZMC20	mt-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3875	231	MT-10.0GB-30D-P34FHRF8J	mt-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3876	231	MT-2.0GB-1D-PZ6R8ASH9	mt-pz6r8ash9	2.0GB / 1 дней	2	1	2.9		t
3877	231	MT-3.0GB-1D-PE01DJZS7	mt-pe01djzs7	3.0GB / 1 дней	3	1	4.4		t
3878	231	MT-0.5GB-1D-P61RQP7ZW	mt-p61rqp7zw	0.49GB / 1 дней	0.49	1	0.8	Europe(30+ areas) 500MB/Day	t
1595	293	UY-10.0GB-30D-PCHZ59M2J	uy-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1596	293	UY-5.0GB-30D-P7GA02CZP	uy-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
1597	293	UY-3.0GB-30D-PQB69VW8U	uy-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
1598	293	UY-1.0GB-7D-PUSHF5X80	uy-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
1605	294	UZ-5.0GB-30D-CKH825	uz-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
1606	294	UZ-10.0GB-30D-CKH826	uz-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1607	294	PCHMVSA0P	uz-pchmvsa0p	3.0GB / 30 дней	3	30	3.8	Uzbekistan 3GB 30Days	t
1608	294	UZ-3.0GB-30D-PHD8GZ2VN	uz-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1609	294	UZ-20.0GB-90D-PG3K0LHBC	uz-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1610	294	UZ-1.0GB-365D-PCQXBW5UJ	uz-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1611	294	UZ-1.0GB-7D-PHS30M6EZ	uz-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
1612	294	UZ-1.0GB-365D-PYMC5N31Z	uz-pymc5n31z	1.0GB / 365 дней	1	365	19		t
1613	294	UZ-5.0GB-30D-PEW54FVD9	uz-pew54fvd9	5.0GB / 30 дней	5	30	26		t
1614	294	UZ-3.0GB-30D-PW6P3DX2G	uz-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
1615	294	UZ-20.0GB-90D-PB83STJL6	uz-pb83stjl6	20.0GB / 90 дней	20	90	95		t
1616	294	UZ-20.0GB-30D-PR3JZMC20	uz-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
1617	294	UZ-10.0GB-30D-P34FHRF8J	uz-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
1618	294	UZ-10.0GB-1D-PGP9AZY26	uz-pgp9azy26	10.0GB / 1 дней	10	1	10.8	Central Asia 10GB/Day	t
1619	294	UZ-5.0GB-1D-P9RS4VV0A	uz-p9rs4vv0a	5.0GB / 1 дней	5	1	6	Central Asia 5GB/Day	t
1620	294	UZ-1.0GB-1D-PJA28XEA7	uz-pja28xea7	1.0GB / 1 дней	1	1	1.4	Central Asia 1GB/Day	t
1621	294	UZ-0.5GB-1D-P712EDLGB	uz-p712edlgb	0.49GB / 1 дней	0.49	1	0.6	Central Asia 500MB/Day	t
1639	295	VN-3.0GB-15D-JC179	vn-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
1640	295	VN-10.0GB-30D-JC180	vn-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
1641	295	VN-20.0GB-90D-JC181	vn-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
1642	295	VN-50.0GB-180D-JC182	vn-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
1643	295	VN-1.0GB-7D-JC183	vn-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
1644	295	VN-3.0GB-30D-PHD8GZ2VN	vn-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1645	295	VN-20.0GB-90D-PG3K0LHBC	vn-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1646	295	PU3OJKPFD	vn-pu3ojkpfd	50.0GB / 180 дней	50	180	45	Vietnam 50GB 180Days	t
1647	295	VN-50.0GB-180D-P4GNDNA36	vn-p4gndna36	50.0GB / 180 дней	50	180	45	Asia (7 areas) 50GB 180Days	t
1648	295	VN-1.0GB-365D-PCQXBW5UJ	vn-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
1649	295	PT2J1Y4JX	vn-pt2j1y4jx	1.0GB / 1 дней	1	1	1.46	Vietnam 1GB/Day	t
1650	295	VN-0.5GB-1D-PACK04L3R	vn-pack04l3r	0.49GB / 1 дней	0.49	1	2.5	Asia (12 areas) 500MB/Day	t
1651	295	VN-1.0GB-1D-PXJ8HG40S	vn-pxj8hg40s	1.0GB / 1 дней	1	1	4	Asia (12 areas) 1GB/Day	t
1652	295	VN-2.0GB-1D-PVBKS19B4	vn-pvbks19b4	2.0GB / 1 дней	2	1	7.5	Asia (12 areas) 2GB/Day	t
1653	295	VN-3.0GB-1D-PM5T3Z4UM	vn-pm5t3z4um	3.0GB / 1 дней	3	1	10.7	Asia (12 areas) 3GB/Day	t
1654	295	PUHL77M18	vn-puhl77m18	10.0GB / 1 дней	10	1	13.6		t
1655	295	PTS4IGND3	vn-pts4ignd3	0.49GB / 1 дней	0.49	1	0.58		t
3059	202	HU-1.0GB-7D-CKH484	hu-ckh484	1.0GB / 7 дней	1	7	2.9	Europe 1GB 7Days	t
3060	202	HU-10.0GB-30D-CKH486	hu-ckh486	10.0GB / 30 дней	10	30	19	Europe 10GB 30Days	t
3061	202	HU-20.0GB-30D-CKH500	hu-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
3062	202	HU-6.0GB-15D-AIS002	hu-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3063	202	CKH545	hu-ckh545	20.0GB / 30 дней	20	30	10.6	Hungary 20GB 30Days	t
3064	202	HU-1.0GB-7D-CKH823	hu-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
1664	296	VG-0.5GB-1D-PX2WSA7L1	vg-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
1665	296	VG-10.0GB-30D-PCHZ59M2J	vg-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
1675	297	YE-10.0GB-30D-CKH826	ye-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
1676	297	YE-3.0GB-30D-PHD8GZ2VN	ye-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
1677	297	YE-20.0GB-90D-PG3K0LHBC	ye-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
1678	297	YE-1.0GB-365D-PCQXBW5UJ	ye-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3065	202	HU-5.0GB-30D-CKH825	hu-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3115	203	IS-1.0GB-30D-PM1HX6ES9	is-pm1hx6es9	1.0GB / 30 дней	1	30	1	Europe(30+ areas) 1GB 30Days	t
3116	203	IS-3.0GB-30D-PJK6T8JT2	is-pjk6t8jt2	3.0GB / 30 дней	3	30	3.8	Europe(30+ areas) 3GB 30Days	t
3117	203	IS-5.0GB-30D-P87F6RTKY	is-p87f6rtky	5.0GB / 30 дней	5	30	5.7	Europe(30+ areas) 5GB 30Days	t
3118	203	IS-1.0GB-7D-PV048NCRG	is-pv048ncrg	1.0GB / 7 дней	1	7	1.5	Europe(30+ areas) 1GB 7Days	t
3119	203	IS-10.0GB-30D-P50GVS8GN	is-p50gvs8gn	10.0GB / 30 дней	10	30	9.9	Europe(30+ areas) 10GB 30Days	t
3120	203	IS-20.0GB-30D-PHC4X21NC	is-phc4x21nc	20.0GB / 30 дней	20	30	16.8	Europe(30+ areas) 20GB 30Days	t
3121	203	IS-20.0GB-90D-P5NWWU08G	is-p5nwwu08g	20.0GB / 90 дней	20	90	17.3	Europe(30+ areas) 20GB 90Days	t
3122	203	IS-50.0GB-180D-PE70MYRZ5	is-pe70myrz5	50.0GB / 180 дней	50	180	36.5	Europe(30+ areas) 50GB 180Days	t
3123	203	IS-1.0GB-1D-PUDV52A3R	is-pudv52a3r	1.0GB / 1 дней	1	1	1.5	Europe(30+ areas) 1GB/Day	t
3879	231	MT-0.3GB-1D-P82Y6VYRL	mt-p82y6vyrl	0.29GB / 1 дней	0.29	1	0.45	Europe(30+ areas) 300MB/Day	t
3891	233	MU-6.0GB-15D-AIS002	mu-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3893	233	MU-1.0GB-365D-PYMC5N31Z	mu-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3894	233	MU-5.0GB-30D-PEW54FVD9	mu-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3895	233	MU-3.0GB-30D-PW6P3DX2G	mu-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3896	233	MU-20.0GB-90D-PB83STJL6	mu-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3897	233	MU-20.0GB-30D-PR3JZMC20	mu-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3898	233	MU-10.0GB-30D-P34FHRF8J	mu-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3899	233	PLHCEBQDV	mu-plhcebqdv	2.0GB / 1 дней	2	1	5.4		t
3900	233	PKXERFUDN	mu-pkxerfudn	1.0GB / 1 дней	1	1	4.9		t
935	234	MX-5.0GB-30D-PWPB9E2B6	mx-pwpb9e2b6	5.0GB / 30 дней	5	30	10	North America 5GB   30Days Single Use	t
936	234	MX-3.0GB-30D-P2C6DT8XP	mx-p2c6dt8xp	3.0GB / 30 дней	3	30	6.6	North America 3GB 30Days Single Use	t
937	234	MX-1.0GB-7D-PB2CS54LH	mx-pb2cs54lh	1.0GB / 7 дней	1	7	2.5	North America  1GB 7Days Single Use	t
3926	236	MC-1.0GB-365D-PCQXBW5UJ	mc-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3927	236	MC-1.0GB-7D-PHS30M6EZ	mc-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3928	236	MC-1.0GB-365D-PYMC5N31Z	mc-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3929	236	MC-5.0GB-30D-PEW54FVD9	mc-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3930	236	MC-3.0GB-30D-PW6P3DX2G	mc-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3931	236	MC-20.0GB-90D-PB83STJL6	mc-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3954	239	MS-5.0GB-1D-PX18HJ4XW	ms-px18hj4xw	5.0GB / 1 дней	5	1	35	Caribbean (20+ areas) 5GB/Day	t
3955	239	MS-1.0GB-1D-P8JCL47FC	ms-p8jcl47fc	1.0GB / 1 дней	1	1	6.8	Caribbean (20+ areas) 1GB/Day	t
3956	239	MS-0.5GB-1D-PX2WSA7L1	ms-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
3957	239	MS-10.0GB-30D-PCHZ59M2J	ms-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
3958	239	MS-5.0GB-30D-P7GA02CZP	ms-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
3248	208	IM-20.0GB-30D-CKH500	im-ckh500	20.0GB / 30 дней	20	30	32	Europe 20GB 30Days	t
3249	208	IM-6.0GB-15D-AIS002	im-ais002	6.0GB / 15 дней	6	15	25	Global138 6GB 15Days	t
3250	208	CKH745	im-ckh745	20.0GB / 30 дней	20	30	12.9	Isle of Man 20GB 30Days	t
3251	208	IM-1.0GB-7D-CKH823	im-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3252	208	IM-5.0GB-30D-CKH825	im-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3253	208	IM-10.0GB-30D-CKH826	im-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3254	208	IM-20.0GB-90D-P7VCE7FKY	im-p7vce7fky	20.0GB / 90 дней	20	90	34	Europe 20GB 90Days	t
3255	208	IM-50.0GB-180D-PGXJN6W2T	im-pgxjn6w2t	50.0GB / 180 дней	50	180	78	Europe 50GB 180Days	t
3256	208	IM-3.0GB-30D-PHD8GZ2VN	im-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3257	208	IM-20.0GB-90D-PG3K0LHBC	im-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3258	208	IM-1.0GB-365D-PCQXBW5UJ	im-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3278	209	IL-1.0GB-7D-JC183	il-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
3279	209	PWCDVUQGM	il-pwcdvuqgm	50.0GB / 180 дней	50	180	37	Israel 50GB 180Days	t
3280	209	IL-3.0GB-30D-PHD8GZ2VN	il-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3281	209	IL-20.0GB-90D-PG3K0LHBC	il-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3282	209	IL-3.0GB-30D-PNEKXVZKV	il-pnekxvzkv	3.0GB / 30 дней	3	30	17.9	Middle East 3GB 30Days	t
3283	209	IL-1.0GB-365D-PCQXBW5UJ	il-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3284	209	IL-1.0GB-7D-PHS30M6EZ	il-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3285	209	IL-1.0GB-365D-PYMC5N31Z	il-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3286	209	IL-5.0GB-30D-PEW54FVD9	il-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3287	209	IL-3.0GB-30D-PW6P3DX2G	il-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3288	209	IL-20.0GB-90D-PB83STJL6	il-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3289	209	IL-20.0GB-30D-PR3JZMC20	il-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3290	209	IL-10.0GB-30D-P34FHRF8J	il-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3291	209	P6EUQ8HV5	il-p6euq8hv5	0.49GB / 1 дней	0.49	1	1.85	Israel 500MB/Day	t
3292	209	P83SJWZ7Z	il-p83sjwz7z	1.0GB / 1 дней	1	1	2.9	Israel 1GB/Day	t
3293	209	PQSCDP235	il-pqscdp235	2.0GB / 1 дней	2	1	5.4	Israel 2GB/Day	t
3294	209	PYCQ2P3E1	il-pycq2p3e1	3.0GB / 1 дней	3	1	8	Israel 3GB/Day	t
3297	210	JM-0.5GB-1D-PX2WSA7L1	jm-px2wsa7l1	0.49GB / 1 дней	0.49	1	3	Caribbean (20+ areas) 500MB/Day	t
3298	210	JM-10.0GB-30D-PCHZ59M2J	jm-pchz59m2j	10.0GB / 30 дней	10	30	44.9	Caribbean (20+ areas) 10GB 30Days Single Use	t
3299	210	JM-5.0GB-30D-P7GA02CZP	jm-p7ga02czp	5.0GB / 30 дней	5	30	26.9	Caribbean (20+ areas) 5GB 30Days Single Use	t
3300	210	JM-3.0GB-30D-PQB69VW8U	jm-pqb69vw8u	3.0GB / 30 дней	3	30	14.9	Caribbean (20+ areas) 3GB 30Days Single Use	t
3301	210	JM-1.0GB-7D-PUSHF5X80	jm-pushf5x80	1.0GB / 7 дней	1	7	5.9	Caribbean (20+ areas) 1GB 7Days Single Use	t
829	8	AU-10.0GB-30D-CKH826	au-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
830	8	AU-1.0GB-30D-JC177	au-jc177	1.0GB / 30 дней	1	30	3.7	Asia-20 1GB 30 Days	t
831	8	AU-5.0GB-30D-JC178	au-jc178	5.0GB / 30 дней	5	30	13.6	Asia-20 5GB 30 Days	t
832	8	AU-3.0GB-15D-JC179	au-jc179	3.0GB / 15 дней	3	15	8.9	Asia-20 3GB 15Days	t
833	8	AU-10.0GB-30D-JC180	au-jc180	10.0GB / 30 дней	10	30	23	Asia-20 10GB 30Days	t
834	8	AU-20.0GB-90D-JC181	au-jc181	20.0GB / 90 дней	20	90	42	Asia-20 20GB 90 Days	t
835	8	AU-50.0GB-180D-JC182	au-jc182	50.0GB / 180 дней	50	180	89	Asia-20 50GB 180 Days	t
836	8	AU-1.0GB-7D-JC183	au-jc183	1.0GB / 7 дней	1	7	3.6	Asia-20 1GB 7 Days	t
837	8	AU-3.0GB-30D-PHD8GZ2VN	au-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
838	8	AU-20.0GB-90D-PG3K0LHBC	au-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
839	8	POU9P9TSZ	au-pou9p9tsz	50.0GB / 180 дней	50	180	28	Australia 50GB 180Days	t
840	8	AU-1.0GB-365D-PCQXBW5UJ	au-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
841	8	PBLAOUJHR	au-pblaoujhr	0.49GB / 1 дней	0.49	1	0.5	Australia 500MB/Day	t
842	8	PKAECJYPB	au-pkaecjypb	1.0GB / 1 дней	1	1	1	Australia 1GB/Day	t
843	8	AU-1.0GB-7D-PHS30M6EZ	au-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
844	8	AU-1.0GB-365D-PYMC5N31Z	au-pymc5n31z	1.0GB / 365 дней	1	365	19		t
845	8	AU-5.0GB-30D-PEW54FVD9	au-pew54fvd9	5.0GB / 30 дней	5	30	26		t
846	8	AU-3.0GB-30D-PW6P3DX2G	au-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
847	8	AU-20.0GB-90D-PB83STJL6	au-pb83stjl6	20.0GB / 90 дней	20	90	95		t
848	8	AU-20.0GB-30D-PR3JZMC20	au-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
849	8	AU-10.0GB-30D-P34FHRF8J	au-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
850	8	PRUQ8T3B2	au-pruq8t3b2	2.0GB / 1 дней	2	1	2	Australia 2GB/Day	t
851	8	P4GHU52FZ	au-p4ghu52fz	3.0GB / 1 дней	3	1	2.85	Australia 3GB/Day	t
852	8	PWV71AAT5	au-pwv71aat5	10.0GB / 1 дней	10	1	9.3	Australia 10GB/Day	t
3340	212	JO-5.0GB-30D-PEW54FVD9	jo-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3341	212	JO-3.0GB-30D-PW6P3DX2G	jo-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3342	212	JO-20.0GB-90D-PB83STJL6	jo-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3343	212	JO-20.0GB-30D-PR3JZMC20	jo-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3344	212	JO-10.0GB-30D-P34FHRF8J	jo-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
3352	213	KZ-1.0GB-7D-CKH823	kz-ckh823	1.0GB / 7 дней	1	7	17.5	Global139 1GB 7Days	t
3353	213	KZ-5.0GB-30D-CKH825	kz-ckh825	5.0GB / 30 дней	5	30	65	Global139 5GB 30Days	t
3354	213	KZ-10.0GB-30D-CKH826	kz-ckh826	10.0GB / 30 дней	10	30	0.01	Global139 10GB 30Days	t
3355	213	KZ-3.0GB-30D-PHD8GZ2VN	kz-phd8gz2vn	3.0GB / 30 дней	3	30	43	Global139 3GB 30Days	t
3356	213	KZ-20.0GB-90D-PG3K0LHBC	kz-pg3k0lhbc	20.0GB / 90 дней	20	90	0.02	Global139 20GB 90Days	t
3357	213	KZ-1.0GB-365D-PCQXBW5UJ	kz-pcqxbw5uj	1.0GB / 365 дней	1	365	38	Global139 1GB 365Days	t
3358	213	KZ-1.0GB-7D-PHS30M6EZ	kz-phs30m6ez	1.0GB / 7 дней	1	7	7.1		t
3359	213	KZ-1.0GB-365D-PYMC5N31Z	kz-pymc5n31z	1.0GB / 365 дней	1	365	19		t
3360	213	KZ-5.0GB-30D-PEW54FVD9	kz-pew54fvd9	5.0GB / 30 дней	5	30	26		t
3361	213	KZ-3.0GB-30D-PW6P3DX2G	kz-pw6p3dx2g	3.0GB / 30 дней	3	30	17.9		t
3362	213	KZ-20.0GB-90D-PB83STJL6	kz-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3386	214	KE-20.0GB-90D-PB83STJL6	ke-pb83stjl6	20.0GB / 90 дней	20	90	95		t
3387	214	KE-20.0GB-30D-PR3JZMC20	ke-pr3jzmc20	20.0GB / 30 дней	20	30	79		t
3388	214	KE-10.0GB-30D-P34FHRF8J	ke-p34fhrf8j	10.0GB / 30 дней	10	30	46		t
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_messages (id, ticket_id, sender_type, text, created_at) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, user_id, subject, message, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, telegram_id, username, first_name, last_name, language_code, is_admin, created_at, updated_at) FROM stdin;
1	855277058	topotun85	Vadim	Black	ru	f	2025-03-06 20:58:09.453313	2025-03-06 20:58:09.45332
\.


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.countries_id_seq', 300, true);


--
-- Name: esims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.esims_id_seq', 4, true);


--
-- Name: faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faqs_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 86, true);


--
-- Name: packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packages_id_seq', 4554, true);


--
-- Name: support_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_messages_id_seq', 1, false);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: countries countries_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_code_key UNIQUE (code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: esims esims_order_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.esims
    ADD CONSTRAINT esims_order_id_key UNIQUE (order_id);


--
-- Name: esims esims_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.esims
    ADD CONSTRAINT esims_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_no_key UNIQUE (order_no);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_transaction_id_key UNIQUE (transaction_id);


--
-- Name: packages packages_package_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_package_code_key UNIQUE (package_code);


--
-- Name: packages packages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_pkey PRIMARY KEY (id);


--
-- Name: packages packages_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_slug_key UNIQUE (slug);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: esims esims_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.esims
    ADD CONSTRAINT esims_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: orders orders_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages(id);


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: packages packages_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: support_messages support_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

